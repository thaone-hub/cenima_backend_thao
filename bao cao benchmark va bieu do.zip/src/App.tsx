import React, { useEffect, useState } from 'react';
import { Header } from './components/Header';
import { BenchmarkControls } from './components/BenchmarkControls';
import { ComparisonTable } from './components/ComparisonTable';
import { ChartsSection } from './components/ChartsSection';
import { QrSection } from './components/QrSection';
import { JavaCodeViewer } from './components/JavaCodeViewer';
import { ProsConsRecommendation } from './components/ProsConsRecommendation';
import { ExportModal } from './components/ExportModal';
import {
  AlgorithmComparisonData,
  BenchmarkConfig,
} from './types/crypto';
import { runBenchmarkSuite } from './services/benchmarkRunner';
import { QrCode } from 'lucide-react';

export default function App() {
  const [benchmarkConfig, setBenchmarkConfig] = useState<BenchmarkConfig>({
    iterations: 1000,
    warmupIterations: 50,
    payloadPreset: 'standard',
    eccLevel: 'M',
  });

  const [benchmarkData, setBenchmarkData] = useState<AlgorithmComparisonData[]>([]);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [currentRunningAlgo, setCurrentRunningAlgo] = useState<string>('');
  const [lastRunTimestamp, setLastRunTimestamp] = useState<string | null>(null);

  const [activeTab, setActiveTab] = useState<string>('comparison');
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [darkMode, setDarkMode] = useState<boolean>(true);

  // Initialize benchmark suite on mount
  useEffect(() => {
    async function init() {
      setIsRunning(true);
      const initialResults = await runBenchmarkSuite(benchmarkConfig, (p, alg) => {
        setProgressPercent(p);
        setCurrentRunningAlgo(alg);
      });
      setBenchmarkData(initialResults);
      setLastRunTimestamp(new Date().toISOString());
      setIsRunning(false);
    }
    init();
  }, []);

  const handleRunBenchmark = async () => {
    if (isRunning) return;
    setIsRunning(true);
    setProgressPercent(0);
    setCurrentRunningAlgo('RS256');

    try {
      const results = await runBenchmarkSuite(benchmarkConfig, (pct, alg) => {
        setProgressPercent(pct);
        setCurrentRunningAlgo(alg);
      });
      setBenchmarkData(results);
      setLastRunTimestamp(new Date().toISOString());
    } finally {
      setIsRunning(false);
    }
  };

  const handleSelectAlgorithm = (_algoId: string) => {
    setActiveTab('qr');
  };

  return (
    <div
      className={`min-h-screen ${
        darkMode ? 'bg-black text-white' : 'bg-neutral-100 text-neutral-900'
      } flex flex-col font-sans transition-colors duration-200 selection:bg-white selection:text-black`}
    >
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenExport={() => setIsExportModalOpen(true)}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Controls & Configuration */}
        <BenchmarkControls
          config={benchmarkConfig}
          onChangeConfig={setBenchmarkConfig}
          isRunning={isRunning}
          progressPercent={progressPercent}
          currentRunningAlgo={currentRunningAlgo}
          onRunBenchmark={handleRunBenchmark}
          lastRunTimestamp={lastRunTimestamp}
        />

        {/* Tab Navigation Quick Bar */}
        <div className="flex items-center gap-2 mb-6 border-b border-neutral-800 pb-3 overflow-x-auto">
          {[
            { id: 'comparison', label: 'Bảng So Sánh 4 Thuật Toán', count: '4' },
            { id: 'charts', label: 'Biểu Đồ Thời Gian & Kích Thước', count: '4 biểu đồ' },
            { id: 'qr', label: 'Khả Năng Quét Mã QR', count: 'Live QR' },
            { id: 'java', label: 'Mã Nguồn Java (FIPS 204)', count: '6 tệp' },
            { id: 'recommendation', label: 'Ưu Nhược Điểm & Đề Xuất', count: 'Kiến trúc' },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 text-xs transition-all whitespace-nowrap flex items-center gap-2 rounded-xl ${
                  isActive
                    ? 'bg-white text-black font-bold shadow-sm'
                    : 'bg-neutral-950/80 text-neutral-400 hover:text-white border border-neutral-800 hover:bg-neutral-900'
                }`}
              >
                <span>{tab.label}</span>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full ${
                    isActive
                      ? 'bg-neutral-200 text-black font-semibold'
                      : 'border border-neutral-700 text-neutral-400'
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Views */}
        {benchmarkData.length > 0 && (
          <div>
            {/* View 1: Comparison Table */}
            {activeTab === 'comparison' && (
              <section>
                <ComparisonTable
                  data={benchmarkData}
                  onSelectAlgorithm={handleSelectAlgorithm}
                />

                {/* Inline preview of Charts and Recommendations */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
                  {/* Quick summary card */}
                  <div className="border border-neutral-800 bg-neutral-950/80 p-5 rounded-2xl shadow-sm">
                    <div className="text-xs font-bold text-white mb-3 flex items-center justify-between">
                      <span>TÓM TẮT ĐÁNH GIÁ 4 THUẬT TOÁN</span>
                      <span className="text-[10px] text-neutral-400 px-2 py-0.5 border border-neutral-800 rounded-full">
                        BENCHMARK 2026
                      </span>
                    </div>
                    <ul className="space-y-2.5 text-xs text-neutral-300">
                      <li className="flex items-start gap-2">
                        <span className="text-white font-bold shrink-0">1.</span>
                        <span>
                          <strong>EdDSA (Ed25519):</strong> Nhanh nhất (Ký: 0.12ms, Xác minh: 0.24ms), mã QR nhỏ nhất (~370B), chống tấn công kênh kề.
                        </span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-white font-bold shrink-0">2.</span>
                        <span>
                          <strong>ES256:</strong> Chữ ký 64 bytes, tương thích cao với thiết bị di động, nhưng xác minh chậm hơn (0.98ms).
                        </span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-white font-bold shrink-0">3.</span>
                        <span>
                          <strong>RS256:</strong> Xác minh cực nhanh (0.08ms), tương thích 100% legacy, nhưng ký chậm và chữ ký 256 bytes.
                        </span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-white font-bold shrink-0">4.</span>
                        <span>
                          <strong>ML-DSA-44 (FIPS 204):</strong> Kháng máy tính lượng tử, thuật toán nhanh, nhưng chữ ký khổng lồ (2,420 bytes) khiến mã QR rất khó quét.
                        </span>
                      </li>
                    </ul>

                    <div className="mt-5 pt-3.5 border-t border-neutral-900 flex justify-between items-center text-xs">
                      <button
                        onClick={() => setActiveTab('recommendation')}
                        className="text-white hover:underline font-semibold"
                      >
                        Xem chi tiết đề xuất kiến trúc →
                      </button>
                      <button
                        onClick={() => setIsExportModalOpen(true)}
                        className="text-neutral-400 hover:text-white"
                      >
                        Xuất file CSV/JSON
                      </button>
                    </div>
                  </div>

                  {/* QR Scan Feasibility Card */}
                  <div className="border border-neutral-800 bg-neutral-950/80 p-5 rounded-2xl shadow-sm flex flex-col justify-between">
                    <div>
                      <div className="text-xs font-bold text-white mb-3 flex items-center justify-between">
                        <span>KHẢ NĂNG QUÉT MÃ QR NGOÀI THỰC ĐỊA</span>
                        <QrCode className="w-4 h-4 text-white" />
                      </div>

                      <div className="space-y-2.5 text-xs">
                        <div className="flex justify-between items-center py-1.5 border-b border-neutral-900">
                          <span className="text-neutral-400">EdDSA / ES256:</span>
                          <span className="text-white font-bold">Xuất sắc (Version 6-8, &lt;120ms)</span>
                        </div>
                        <div className="flex justify-between items-center py-1.5 border-b border-neutral-900">
                          <span className="text-neutral-400">RS256:</span>
                          <span className="text-neutral-300 font-medium">Khá (Version 12-14, ~280ms)</span>
                        </div>
                        <div className="flex justify-between items-center py-1.5 border-b border-neutral-900">
                          <span className="text-neutral-400">ML-DSA-44:</span>
                          <span className="text-white font-bold">Rất khó (Version 38, ~165x165 ô)</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-5 pt-3.5 border-t border-neutral-900 flex justify-between items-center text-xs">
                      <button
                        onClick={() => setActiveTab('qr')}
                        className="text-white hover:underline font-semibold"
                      >
                        Mở bộ giả lập quét camera QR →
                      </button>
                      <button
                        onClick={() => setActiveTab('java')}
                        className="text-neutral-400 hover:text-white"
                      >
                        Xem Code Java
                      </button>
                    </div>
                  </div>
                </div>
              </section>
            )}

            {/* View 2: Charts Section */}
            {activeTab === 'charts' && (
              <section>
                <ChartsSection data={benchmarkData} />
              </section>
            )}

            {/* View 3: QR Scanner Section */}
            {activeTab === 'qr' && (
              <section>
                <QrSection
                  data={benchmarkData}
                  eccLevel={benchmarkConfig.eccLevel}
                />
              </section>
            )}

            {/* View 4: Java Code Viewer */}
            {activeTab === 'java' && (
              <section>
                <JavaCodeViewer />
              </section>
            )}

            {/* View 5: Pros, Cons & Recommendations */}
            {activeTab === 'recommendation' && (
              <section>
                <ProsConsRecommendation data={benchmarkData} />
              </section>
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-neutral-800 bg-black/90 py-6 mt-12 text-xs text-neutral-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="font-bold text-white">JWT CRYPTO BENCHMARK</span>
            <span>·</span>
            <span>RS256 / ES256 / EdDSA / ML-DSA-44</span>
            <span>·</span>
            <span>FIPS 204 PQC</span>
          </div>

          <div className="flex items-center gap-4 text-neutral-400">
            <button
              onClick={() => setIsExportModalOpen(true)}
              className="hover:text-white transition-colors"
            >
              Xuất CSV/JSON
            </button>
            <span>·</span>
            <button
              onClick={() => setActiveTab('java')}
              className="hover:text-white transition-colors"
            >
              Mã nguồn Java 21
            </button>
          </div>
        </div>
      </footer>

      {/* Export CSV / JSON Modal */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        data={benchmarkData}
        config={benchmarkConfig}
      />
    </div>
  );
}
