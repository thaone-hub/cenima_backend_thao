import React from 'react';
import { Play, RotateCw, Settings2, ShieldCheck, Zap } from 'lucide-react';
import { BenchmarkConfig, PayloadSizePreset, QrEccLevel } from '../types/crypto';
import { PAYLOAD_PRESETS } from '../services/benchmarkRunner';

interface BenchmarkControlsProps {
  config: BenchmarkConfig;
  onChangeConfig: (newConfig: BenchmarkConfig) => void;
  isRunning: boolean;
  progressPercent: number;
  currentRunningAlgo: string;
  onRunBenchmark: () => void;
  lastRunTimestamp: string | null;
}

export const BenchmarkControls: React.FC<BenchmarkControlsProps> = ({
  config,
  onChangeConfig,
  isRunning,
  progressPercent,
  currentRunningAlgo,
  onRunBenchmark,
  lastRunTimestamp,
}) => {
  return (
    <div className="border border-neutral-800 bg-neutral-950/80 p-5 sm:p-6 mb-6 rounded-2xl shadow-sm">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
              BÁO CÁO BENCHMARK 4 THUẬT TOÁN JWT
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-neutral-400">
            RS256 · ES256 (P-256) · EdDSA (Ed25519) · ML-DSA-44 (NIST FIPS 204 Hậu Lượng Tử)
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onRunBenchmark}
            disabled={isRunning}
            className={`flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-bold tracking-wide uppercase transition-all rounded-xl shrink-0 shadow-sm ${
              isRunning
                ? 'bg-neutral-800 text-neutral-400 cursor-not-allowed border border-neutral-700'
                : 'bg-white text-black hover:bg-neutral-200 border border-white hover:scale-[1.01]'
            }`}
          >
            {isRunning ? (
              <>
                <RotateCw className="w-4 h-4 animate-spin text-white" />
                <span>Đang chạy ({progressPercent}%) - {currentRunningAlgo}</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-black" />
                <span>Chạy lại Benchmark</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Progress bar when running */}
      {isRunning && (
        <div className="mt-4">
          <div className="flex justify-between text-xs text-neutral-400 mb-1.5">
            <span>Tiến trình kiểm thử: {currentRunningAlgo}</span>
            <span className="tabular-nums font-semibold text-white">{progressPercent}%</span>
          </div>
          <div className="w-full h-2 bg-neutral-900 rounded-full overflow-hidden p-0.5 border border-neutral-800">
            <div
              className="h-full bg-white rounded-full transition-all duration-150"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      )}

      {/* Configuration bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-4 pt-2">
        {/* Iterations */}
        <div>
          <label className="block text-xs text-neutral-400 mb-1.5 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-neutral-400" />
            <span>Số lần lặp kiểm thử (Iterations)</span>
          </label>
          <select
            value={config.iterations}
            disabled={isRunning}
            onChange={(e) =>
              onChangeConfig({ ...config, iterations: Number(e.target.value) })
            }
            className="w-full bg-black/90 border border-neutral-700 hover:border-neutral-500 text-white text-xs px-3 py-2.5 rounded-xl focus:outline-none focus:border-white transition-colors cursor-pointer"
          >
            <option value="100">100 lần (Khởi động nhanh)</option>
            <option value="500">500 lần (Độ ổn định cao)</option>
            <option value="1000">1,000 lần (Khuyến nghị chuẩn)</option>
            <option value="5000">5,000 lần (Độ chính xác sâu JMH)</option>
          </select>
        </div>

        {/* Payload Size Preset */}
        <div>
          <label className="block text-xs text-neutral-400 mb-1.5 flex items-center gap-1.5">
            <Settings2 className="w-3.5 h-3.5 text-neutral-400" />
            <span>Kích thước Payload JWT</span>
          </label>
          <select
            value={config.payloadPreset}
            disabled={isRunning}
            onChange={(e) =>
              onChangeConfig({
                ...config,
                payloadPreset: e.target.value as PayloadSizePreset,
              })
            }
            className="w-full bg-black/90 border border-neutral-700 hover:border-neutral-500 text-white text-xs px-3 py-2.5 rounded-xl focus:outline-none focus:border-white transition-colors cursor-pointer"
          >
            <option value="compact">Gọn nhẹ (~120 Bytes - Auth ID)</option>
            <option value="standard">Tiêu chuẩn (~350 Bytes - OIDC Profile)</option>
            <option value="enterprise">Doanh nghiệp (~980 Bytes - Scopes & Role)</option>
          </select>
        </div>

        {/* QR Error Correction Level */}
        <div>
          <label className="block text-xs text-neutral-400 mb-1.5 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-neutral-400" />
            <span>Mức sửa lỗi mã QR (ECC)</span>
          </label>
          <select
            value={config.eccLevel}
            disabled={isRunning}
            onChange={(e) =>
              onChangeConfig({
                ...config,
                eccLevel: e.target.value as QrEccLevel,
              })
            }
            className="w-full bg-black/90 border border-neutral-700 hover:border-neutral-500 text-white text-xs px-3 py-2.5 rounded-xl focus:outline-none focus:border-white transition-colors cursor-pointer"
          >
            <option value="L">Mức L (Low ~7% phục hồi - Sức chứa tối đa)</option>
            <option value="M">Mức M (Medium ~15% - Chuẩn thực tế)</option>
            <option value="Q">Mức Q (Quartile ~25% - Thẻ in bề mặt)</option>
            <option value="H">Mức H (High ~30% - Chống mờ xước)</option>
          </select>
        </div>

        {/* Execution Metadata info */}
        <div className="flex flex-col justify-end">
          <div className="text-xs text-neutral-400 border border-neutral-800 p-2.5 bg-black/80 rounded-xl">
            <div>
              Môi trường:{' '}
              <span className="text-neutral-200 font-semibold">Java 21 / OpenJDK + WebCrypto</span>
            </div>
            <div>
              Cập nhật:{' '}
              <span className="text-neutral-200 tabular-nums">
                {lastRunTimestamp ? new Date(lastRunTimestamp).toLocaleTimeString('vi-VN') : 'Mặc định'}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-3 text-xs text-neutral-500 font-mono flex items-center gap-2">
        <span>Chi tiết Payload hiện tại:</span>
        <span className="text-neutral-400">
          {PAYLOAD_PRESETS[config.payloadPreset].name} — {PAYLOAD_PRESETS[config.payloadPreset].description}
        </span>
      </div>
    </div>
  );
};
