import React, { useState } from 'react';
import { AlgorithmComparisonData } from '../types/crypto';
import { BarChart3, Clock, Database, Layers, Sparkles } from 'lucide-react';

interface ChartsSectionProps {
  data: AlgorithmComparisonData[];
}

export const ChartsSection: React.FC<ChartsSectionProps> = ({ data }) => {
  const [activeChartTab, setActiveChartTab] = useState<'latency' | 'size' | 'throughput' | 'qr'>('latency');
  const [useLogScale, setUseLogScale] = useState<boolean>(false);

  // Maximum values for scaling
  const maxSignTime = Math.max(...data.map((d) => d.benchmark.signTimeAvgMs));
  const maxVerifyTime = Math.max(...data.map((d) => d.benchmark.verifyTimeAvgMs));
  const maxTime = Math.max(maxSignTime, maxVerifyTime);

  const maxTotalBytes = Math.max(...data.map((d) => d.jwt.totalTokenBytes));
  const maxOps = Math.max(
    ...data.map((d) => Math.max(d.benchmark.signOpsPerSec, d.benchmark.verifyOpsPerSec))
  );

  return (
    <div className="border border-neutral-800 bg-neutral-950/80 p-5 sm:p-6 mb-8 rounded-2xl shadow-sm">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-white" />
            <span>BIỂU ĐỒ TRỰC QUAN HÓA HIỆU NĂNG & KÍCH THƯỚC</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            So sánh thời gian ký/xác minh (ms), kích thước JWT (bytes), thông lượng ops/s và mật độ QR
          </p>
        </div>

        {/* Chart Selector Buttons */}
        <div className="flex items-center gap-1.5 bg-black/80 p-1.5 border border-neutral-800 rounded-2xl overflow-x-auto">
          <button
            onClick={() => setActiveChartTab('latency')}
            className={`px-3.5 py-1.5 text-xs rounded-xl transition-all whitespace-nowrap ${
              activeChartTab === 'latency'
                ? 'bg-white text-black font-bold shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900/60'
            }`}
          >
            Thời gian Ký / Xác minh
          </button>
          <button
            onClick={() => setActiveChartTab('size')}
            className={`px-3.5 py-1.5 text-xs rounded-xl transition-all whitespace-nowrap ${
              activeChartTab === 'size'
                ? 'bg-white text-black font-bold shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900/60'
            }`}
          >
            Kích thước JWT
          </button>
          <button
            onClick={() => setActiveChartTab('throughput')}
            className={`px-3.5 py-1.5 text-xs rounded-xl transition-all whitespace-nowrap ${
              activeChartTab === 'throughput'
                ? 'bg-white text-black font-bold shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900/60'
            }`}
          >
            Thông lượng (Ops/s)
          </button>
          <button
            onClick={() => setActiveChartTab('qr')}
            className={`px-3.5 py-1.5 text-xs rounded-xl transition-all whitespace-nowrap ${
              activeChartTab === 'qr'
                ? 'bg-white text-black font-bold shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900/60'
            }`}
          >
            Mật độ Mã QR
          </button>
        </div>
      </div>

      {/* Chart 1: Latency (Sign vs Verify) */}
      {activeChartTab === 'latency' && (
        <div className="pt-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4 text-xs font-mono">
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 bg-white border border-white" />
                <span className="text-white">Thời gian ký (Signing ms)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 bg-neutral-700 border border-neutral-500" />
                <span className="text-neutral-300">Thời gian xác minh (Verify ms)</span>
              </div>
            </div>

            <button
              onClick={() => setUseLogScale(!useLogScale)}
              className="text-xs font-mono border border-neutral-800 hover:border-neutral-600 px-2.5 py-1 text-neutral-400 hover:text-white transition-colors"
            >
              Thang đo: {useLogScale ? 'Logarithmic (Log)' : 'Tuyến tính (Linear)'}
            </button>
          </div>

          <div className="space-y-6">
            {data.map((item) => {
              const signVal = item.benchmark.signTimeAvgMs;
              const verifyVal = item.benchmark.verifyTimeAvgMs;

              // Scale calculation
              let signPct = (signVal / maxTime) * 100;
              let verifyPct = (verifyVal / maxTime) * 100;

              if (useLogScale) {
                // Log scale mapping
                signPct = Math.max(5, (Math.log10(signVal + 0.01) + 2) * 28);
                verifyPct = Math.max(5, (Math.log10(verifyVal + 0.01) + 2) * 28);
              }

              return (
                <div key={item.info.id} className="border-b border-neutral-900 pb-4">
                  <div className="flex justify-between items-center text-xs mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{item.info.name}</span>
                      <span className="text-neutral-400">({item.info.standard})</span>
                      {item.info.quantumResistant && (
                        <span className="text-[10px] px-2 py-0.5 border border-white/60 text-white rounded-full bg-neutral-900">
                          HẬU LƯỢNG TỬ
                        </span>
                      )}
                    </div>
                    <div className="text-neutral-400 tabular-nums">
                      Ký: <strong className="text-white">{signVal} ms</strong> · Xác minh:{' '}
                      <strong className="text-white">{verifyVal} ms</strong>
                    </div>
                  </div>

                  {/* Sign bar */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <span className="w-16 text-[11px] text-neutral-400 text-right shrink-0">
                        Sign
                      </span>
                      <div className="flex-1 bg-black/90 h-5 border border-neutral-800 rounded-full p-0.5 relative overflow-hidden">
                        <div
                          className="h-full bg-white rounded-full transition-all duration-300 flex items-center justify-end pr-2 text-black text-[10px] font-bold"
                          style={{ width: `${Math.min(100, Math.max(3, signPct))}%` }}
                        >
                          {signPct > 15 && `${signVal} ms`}
                        </div>
                      </div>
                    </div>

                    {/* Verify bar */}
                    <div className="flex items-center gap-3">
                      <span className="w-16 text-[11px] text-neutral-400 text-right shrink-0">
                        Verify
                      </span>
                      <div className="flex-1 bg-black/90 h-5 border border-neutral-800 rounded-full p-0.5 relative overflow-hidden">
                        <div
                          className="h-full bg-neutral-500 rounded-full transition-all duration-300 flex items-center justify-end pr-2 text-white text-[10px] font-bold"
                          style={{ width: `${Math.min(100, Math.max(3, verifyPct))}%` }}
                        >
                          {verifyPct > 15 && `${verifyVal} ms`}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-4 p-4 bg-black/80 border border-neutral-800 text-xs text-neutral-400 rounded-xl">
            <strong>Nhận xét hiệu năng:</strong>{' '}
            <span className="text-neutral-300">
              <strong>EdDSA (Ed25519)</strong> là thuật toán nhanh nhất toàn diện (Ký: 0.12ms, Xác minh: 0.24ms).{' '}
              <strong>RS256</strong> xác minh cực nhanh (0.08ms) nhưng ký chậm nhất (1.48ms).{' '}
              <strong>ML-DSA-44</strong> có tốc độ tính toán rất ấn tượng (Ký: 0.38ms, Xác minh: 0.16ms) nhờ phép biến đổi số học NTT đa thức trên vành mạng tinh thể.
            </span>
          </div>
        </div>
      )}

      {/* Chart 2: JWT Token Size Breakdown */}
      {activeChartTab === 'size' && (
        <div className="pt-6">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4 text-xs">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 bg-neutral-800 border border-neutral-600 rounded-md" />
                <span className="text-neutral-300">Header Base64</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 bg-neutral-500 border border-neutral-400 rounded-md" />
                <span className="text-neutral-300">Payload Base64</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 bg-white border border-white rounded-md" />
                <span className="text-white font-semibold">Chữ ký Signature Base64</span>
              </div>
            </div>
            <span className="text-neutral-400">Đơn vị: Bytes trong chuỗi JWT hoàn chỉnh</span>
          </div>

          <div className="space-y-6">
            {data.map((item) => {
              const total = item.jwt.totalTokenBytes;
              const sigB64Length = item.jwt.encodedSignature.length;
              const headerB64Length = item.jwt.encodedHeader.length;
              const payloadB64Length = item.jwt.encodedPayload.length;

              return (
                <div key={item.info.id} className="border-b border-neutral-900 pb-4">
                  <div className="flex justify-between items-center text-xs mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{item.info.name}</span>
                      <span className="text-neutral-400">
                        Chữ ký thô: {item.info.signatureBytes.toLocaleString()} B · Khóa Public:{' '}
                        {item.info.publicKeyBytes.toLocaleString()} B
                      </span>
                    </div>
                    <div className="text-sm font-bold text-white tabular-nums">
                      {total.toLocaleString()} Bytes ({total > 1500 ? 'RẤT LỚN' : 'GỌN NHẸ'})
                    </div>
                  </div>

                  {/* Stacked bar */}
                  <div className="w-full bg-black/90 h-7 border border-neutral-800 rounded-xl relative flex overflow-hidden p-0.5">
                    {/* Header */}
                    <div
                      className="h-full bg-neutral-800 rounded-l-lg border-r border-neutral-950 flex items-center justify-center text-[10px] text-neutral-300"
                      style={{ width: `${(headerB64Length / maxTotalBytes) * 100}%` }}
                      title={`Header: ${headerB64Length} bytes`}
                    >
                      {headerB64Length > 40 && `${headerB64Length}B`}
                    </div>

                    {/* Payload */}
                    <div
                      className="h-full bg-neutral-600 border-r border-neutral-950 flex items-center justify-center text-[10px] text-white"
                      style={{ width: `${(payloadB64Length / maxTotalBytes) * 100}%` }}
                      title={`Payload: ${payloadB64Length} bytes`}
                    >
                      {payloadB64Length > 60 && `${payloadB64Length}B`}
                    </div>

                    {/* Signature */}
                    <div
                      className="h-full bg-white rounded-r-lg flex items-center justify-center text-[10px] font-bold text-black"
                      style={{ width: `${(sigB64Length / maxTotalBytes) * 100}%` }}
                      title={`Signature: ${sigB64Length} bytes`}
                    >
                      {sigB64Length > 80 && `Chữ ký: ${sigB64Length}B`}
                    </div>
                  </div>

                  <div className="flex justify-between items-center text-[11px] text-neutral-500 mt-1">
                    <span>
                      Tỷ lệ chữ ký trong Token: {Math.round((sigB64Length / total) * 100)}%
                    </span>
                    <span>
                      So với EdDSA: {(total / data.find((d) => d.info.id === 'EdDSA')!.jwt.totalTokenBytes).toFixed(1)}x
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-4 p-4 bg-black/80 border border-neutral-800 text-xs text-neutral-400 rounded-xl">
            <strong>Phân tích kích thước:</strong>{' '}
            <span className="text-neutral-300">
              Chữ ký của <strong>ML-DSA-44 (FIPS 204)</strong> chiếm tới 2,420 bytes (mã hóa Base64URL thành ~3,228 ký tự), khiến toàn bộ chuỗi JWT vượt ngưỡng 3.7 KB. Trong khi đó, <strong>EdDSA</strong> và <strong>ES256</strong> chỉ tốn 64 bytes chữ ký (~86 ký tự Base64), giữ toàn bộ token ở mức ~370-390 bytes.
            </span>
          </div>
        </div>
      )}

      {/* Chart 3: Throughput (Ops/sec) */}
      {activeChartTab === 'throughput' && (
        <div className="pt-6">
          <div className="flex items-center justify-between mb-4 text-xs">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 bg-white border border-white rounded-md" />
                <span className="text-white">Throughput Ký (Sign ops/s)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 bg-neutral-600 border border-neutral-400 rounded-md" />
                <span className="text-neutral-300">Throughput Xác minh (Verify ops/s)</span>
              </div>
            </div>
            <span className="text-neutral-400">Càng cao càng tốt</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {data.map((item) => (
              <div
                key={item.info.id}
                className="border border-neutral-800 bg-black/90 p-4 rounded-2xl flex flex-col justify-between shadow-sm"
              >
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-bold text-white text-base">{item.info.name}</span>
                    <span className="text-[10px] text-neutral-400 px-2 py-0.5 border border-neutral-800 rounded-full">
                      {item.info.standard}
                    </span>
                  </div>

                  <div className="space-y-3 mt-4">
                    <div>
                      <div className="text-[11px] text-neutral-400 flex justify-between">
                        <span>Signing</span>
                        <strong className="text-white tabular-nums">
                          {item.benchmark.signOpsPerSec.toLocaleString()} ops/s
                        </strong>
                      </div>
                      <div className="w-full bg-neutral-900 h-2 mt-1.5 border border-neutral-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-white rounded-full"
                          style={{
                            width: `${(item.benchmark.signOpsPerSec / maxOps) * 100}%`,
                          }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="text-[11px] text-neutral-400 flex justify-between">
                        <span>Verification</span>
                        <strong className="text-white tabular-nums">
                          {item.benchmark.verifyOpsPerSec.toLocaleString()} ops/s
                        </strong>
                      </div>
                      <div className="w-full bg-neutral-900 h-2 mt-1.5 border border-neutral-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-neutral-500 rounded-full"
                          style={{
                            width: `${(item.benchmark.verifyOpsPerSec / maxOps) * 100}%`,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-5 pt-3 border-t border-neutral-900 text-[11px] text-neutral-400">
                  Tải CPU: <span className="text-white font-semibold">{item.benchmark.cpuOverheadRating}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Chart 4: QR Module Matrix */}
      {activeChartTab === 'qr' && (
        <div className="pt-6">
          <div className="flex items-center justify-between mb-4 text-xs">
            <span className="text-white font-semibold">
              Mật độ ô mã QR (Modules NxN) vs Điểm khả năng quét (0-100)
            </span>
            <span className="text-neutral-400">Chuẩn QR Code Model 2</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {data.map((item) => (
              <div
                key={item.info.id}
                className="border border-neutral-800 bg-black/90 p-4 rounded-2xl flex flex-col justify-between shadow-sm"
              >
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-bold text-white text-base">{item.info.name}</span>
                    <span className="text-xs text-white border border-white/60 px-2 py-0.5 rounded-full">
                      v{item.qr.qrVersion}
                    </span>
                  </div>
                  <div className="text-xs text-neutral-400">
                    Kích thước: {item.qr.modules} x {item.qr.modules} ô ({item.qr.moduleDensity.toLocaleString()} modules)
                  </div>

                  <div className="mt-4 space-y-2">
                    <div>
                      <div className="flex justify-between text-xs">
                        <span className="text-neutral-400">Điểm quét (Readability):</span>
                        <strong className="text-white tabular-nums">{item.qr.readabilityScore}/100</strong>
                      </div>
                      <div className="w-full bg-neutral-900 h-2 mt-1.5 border border-neutral-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-white rounded-full"
                          style={{ width: `${item.qr.readabilityScore}%` }}
                        />
                      </div>
                    </div>

                    <div className="text-xs text-neutral-400 pt-2 border-t border-neutral-900 space-y-1">
                      <div>Thời gian quét: <strong className="text-white">{item.qr.estimatedScanTimeMs} ms</strong></div>
                      <div>In tối thiểu: <strong className="text-white">≥ {item.qr.recommendedMinPrintSizeCm} cm</strong></div>
                      <div>Khả năng: <strong className="text-white">{item.qr.mobileCameraCompatibility}</strong></div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-2.5 border-t border-neutral-850 text-[11px] text-neutral-400 leading-relaxed">
                  {item.qr.feasibilityNotes}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
