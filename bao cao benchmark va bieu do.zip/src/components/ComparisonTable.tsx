import React from 'react';
import { AlgorithmComparisonData } from '../types/crypto';
import { CheckCircle2, XCircle } from 'lucide-react';

interface ComparisonTableProps {
  data: AlgorithmComparisonData[];
  onSelectAlgorithm?: (algoId: string) => void;
}

export const ComparisonTable: React.FC<ComparisonTableProps> = ({
  data,
  onSelectAlgorithm,
}) => {
  return (
    <div className="border border-neutral-800 bg-neutral-950/80 mb-8 rounded-2xl overflow-hidden shadow-sm">
      <div className="p-4 sm:p-5 border-b border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
            BẢNG SO SÁNH CHI TIẾT 4 THUẬT TOÁN JWT
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Dữ liệu đo lường kỹ thuật trên môi trường Java 21 LTS (FIPS 204 Bouncy Castle PQC + Nimbus JOSE)
          </p>
        </div>
        <div className="text-xs text-neutral-400">
          Đơn vị thời gian: mili-giây (ms) · Đơn vị dung lượng: Bytes
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-neutral-800 bg-black/60 text-neutral-400">
              <th className="py-3.5 px-4 font-semibold text-white">Thuật toán</th>
              <th className="py-3.5 px-3 font-semibold">Chuẩn kỹ thuật</th>
              <th className="py-3.5 px-3 font-semibold text-center">Kháng lượng tử</th>
              <th className="py-3.5 px-3 font-semibold text-right">Khóa Public</th>
              <th className="py-3.5 px-3 font-semibold text-right">Chữ ký (Sig)</th>
              <th className="py-3.5 px-3 font-semibold text-right text-white">Tổng JWT</th>
              <th className="py-3.5 px-3 font-semibold text-right">Ký TB (ms)</th>
              <th className="py-3.5 px-3 font-semibold text-right">Ký (ops/s)</th>
              <th className="py-3.5 px-3 font-semibold text-right">Xác minh TB</th>
              <th className="py-3.5 px-3 font-semibold text-right">Xác minh (ops/s)</th>
              <th className="py-3.5 px-3 font-semibold text-center">Mã QR</th>
              <th className="py-3.5 px-4 font-semibold text-center">Khả năng quét</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-900">
            {data.map((item) => {
              const isPqc = item.info.quantumResistant;
              return (
                <tr
                  key={item.info.id}
                  onClick={() => onSelectAlgorithm?.(item.info.id)}
                  className="hover:bg-neutral-900/60 transition-colors cursor-pointer group"
                >
                  {/* Algorithm Name */}
                  <td className="py-3.5 px-4 font-bold text-white whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold">{item.info.name}</span>
                      {isPqc && (
                        <span className="text-[10px] uppercase tracking-wider px-2 py-0.5 border border-white/60 text-white rounded-full bg-neutral-900">
                          PQC FIPS 204
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-neutral-400 font-normal truncate max-w-[180px] mt-0.5">
                      {item.info.family}
                    </div>
                  </td>

                  {/* Standard */}
                  <td className="py-3.5 px-3 text-neutral-300 whitespace-nowrap">
                    <div className="font-medium">{item.info.standard}</div>
                    <div className="text-[10px] text-neutral-400">
                      Bảo mật: ~{item.info.securityBitsEquivalent} bits
                    </div>
                  </td>

                  {/* Quantum Resistant */}
                  <td className="py-3.5 px-3 text-center whitespace-nowrap">
                    {item.info.quantumResistant ? (
                      <div className="inline-flex items-center gap-1.5 text-white font-semibold px-2 py-1 bg-white/10 rounded-full text-[11px]">
                        <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                        <span>CÓ (NIST Level 2)</span>
                      </div>
                    ) : (
                      <div className="inline-flex items-center gap-1.5 text-neutral-400 text-[11px]">
                        <XCircle className="w-3.5 h-3.5 text-neutral-500" />
                        <span>Không</span>
                      </div>
                    )}
                  </td>

                  {/* Public Key */}
                  <td className="py-3.5 px-3 text-right tabular-nums text-neutral-300 whitespace-nowrap">
                    <span className="font-semibold text-white">
                      {item.info.publicKeyBytes.toLocaleString()} B
                    </span>
                    <div className="text-[10px] text-neutral-400">
                      Priv: {item.info.privateKeyBytes.toLocaleString()} B
                    </div>
                  </td>

                  {/* Signature */}
                  <td className="py-3.5 px-3 text-right tabular-nums text-neutral-300 whitespace-nowrap">
                    <span className={`font-semibold ${item.info.signatureBytes > 1000 ? 'text-white' : 'text-neutral-200'}`}>
                      {item.info.signatureBytes.toLocaleString()} B
                    </span>
                    <div className="text-[10px] text-neutral-400">
                      Base64: ~{Math.ceil((item.info.signatureBytes * 4) / 3)} chars
                    </div>
                  </td>

                  {/* Total JWT Size */}
                  <td className="py-3.5 px-3 text-right tabular-nums whitespace-nowrap">
                    <div className="text-sm font-bold text-white">
                      {item.jwt.totalTokenBytes.toLocaleString()} B
                    </div>
                    <div className="text-[10px] text-neutral-400">
                      {item.jwt.totalTokenBytes > 2000 ? 'Rất lớn (PQC)' : 'Gọn nhẹ'}
                    </div>
                  </td>

                  {/* Sign Avg ms */}
                  <td className="py-3.5 px-3 text-right tabular-nums text-neutral-300 whitespace-nowrap">
                    <div className="font-semibold text-white">{item.benchmark.signTimeAvgMs} ms</div>
                    <div className="text-[10px] text-neutral-400">
                      P95: {item.benchmark.signTimeP95Ms} ms
                    </div>
                  </td>

                  {/* Sign Ops/s */}
                  <td className="py-3.5 px-3 text-right tabular-nums text-neutral-300 whitespace-nowrap">
                    <span className="font-semibold text-neutral-200">
                      {item.benchmark.signOpsPerSec.toLocaleString()}
                    </span>
                  </td>

                  {/* Verify Avg ms */}
                  <td className="py-3.5 px-3 text-right tabular-nums text-neutral-300 whitespace-nowrap">
                    <div className="font-semibold text-white">{item.benchmark.verifyTimeAvgMs} ms</div>
                    <div className="text-[10px] text-neutral-400">
                      P95: {item.benchmark.verifyTimeP95Ms} ms
                    </div>
                  </td>

                  {/* Verify Ops/s */}
                  <td className="py-3.5 px-3 text-right tabular-nums text-neutral-300 whitespace-nowrap">
                    <span className="font-semibold text-neutral-200">
                      {item.benchmark.verifyOpsPerSec.toLocaleString()}
                    </span>
                  </td>

                  {/* QR Version */}
                  <td className="py-3.5 px-3 text-center tabular-nums whitespace-nowrap">
                    <div className="font-bold text-white">v{item.qr.qrVersion}</div>
                    <div className="text-[10px] text-neutral-400">
                      {item.qr.modules}x{item.qr.modules} ô
                    </div>
                  </td>

                  {/* QR Readability */}
                  <td className="py-3.5 px-4 text-center whitespace-nowrap">
                    <div className="inline-block text-center">
                      <div className="text-xs font-bold text-white tabular-nums">
                        {item.qr.readabilityScore}/100
                      </div>
                      <div className="text-[10px] text-neutral-400">
                        {item.qr.estimatedScanTimeMs}ms · {item.qr.mobileCameraCompatibility}
                      </div>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Footnote */}
      <div className="p-3.5 bg-black/80 border-t border-neutral-800 text-[11px] text-neutral-400 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-4">
          <span>* Nhấp vào một hàng để xem mã nguồn Java và chi tiết mã QR của thuật toán đó</span>
        </div>
        <div>
          <span>FIPS 204: NIST Standard ban hành tháng 8/2024 (Module-Lattice PQC)</span>
        </div>
      </div>
    </div>
  );
};
