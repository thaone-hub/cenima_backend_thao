import React, { useState } from 'react';
import { AlgorithmComparisonData, BenchmarkConfig } from '../types/crypto';
import {
  generateCsvReport,
  generateJsonReport,
  generateMarkdownReport,
  downloadFile,
} from '../services/exportService';
import { Check, Copy, Download, FileSpreadsheet, FileText, X } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: AlgorithmComparisonData[];
  config: BenchmarkConfig;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  data,
  config,
}) => {
  const [exportType, setExportType] = useState<'csv' | 'json' | 'markdown'>('csv');
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const csvContent = generateCsvReport(data, config);
  const jsonContent = generateJsonReport(data, config);
  const markdownContent = generateMarkdownReport(data, config);

  const currentContent =
    exportType === 'csv'
      ? csvContent
      : exportType === 'json'
      ? jsonContent
      : markdownContent;

  const currentFilename =
    exportType === 'csv'
      ? `jwt_benchmark_${Date.now()}.csv`
      : exportType === 'json'
      ? `jwt_benchmark_${Date.now()}.json`
      : `jwt_benchmark_report_${Date.now()}.md`;

  const currentMime =
    exportType === 'csv'
      ? 'text/csv;charset=utf-8;'
      : exportType === 'json'
      ? 'application/json;charset=utf-8;'
      : 'text/markdown;charset=utf-8;';

  const handleDownload = () => {
    downloadFile(currentContent, currentFilename, currentMime);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(currentContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="border border-neutral-800 bg-neutral-950 max-w-4xl w-full max-h-[90vh] flex flex-col rounded-3xl shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-neutral-800 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
              <Download className="w-5 h-5 text-white" />
              <span>XUẤT DỮ LIỆU BÁO CÁO BENCHMARK (CSV / JSON)</span>
            </h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              Tải về dữ liệu thô, bảng số liệu kỹ thuật hoặc báo cáo Markdown để chia sẻ
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white transition-colors rounded-full hover:bg-neutral-900"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Export Type Tabs */}
        <div className="flex items-center gap-2 px-5 sm:px-6 pt-3 pb-2 border-b border-neutral-850 bg-black/40">
          <button
            onClick={() => setExportType('csv')}
            className={`px-4 py-2 text-xs rounded-xl flex items-center gap-2 transition-all ${
              exportType === 'csv'
                ? 'bg-white text-black font-bold shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900/60'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Định dạng CSV (.csv)</span>
          </button>

          <button
            onClick={() => setExportType('json')}
            className={`px-4 py-2 text-xs rounded-xl flex items-center gap-2 transition-all ${
              exportType === 'json'
                ? 'bg-white text-black font-bold shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900/60'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Định dạng JSON (.json)</span>
          </button>

          <button
            onClick={() => setExportType('markdown')}
            className={`px-4 py-2 text-xs rounded-xl flex items-center gap-2 transition-all ${
              exportType === 'markdown'
                ? 'bg-white text-black font-bold shadow-sm'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-900/60'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Báo cáo Markdown (.md)</span>
          </button>
        </div>

        {/* Content Preview */}
        <div className="flex-1 p-5 sm:p-6 overflow-y-auto bg-neutral-950">
          <div className="flex justify-between items-center text-xs text-neutral-400 mb-2">
            <span>
              Xem trước nội dung xuất ({currentContent.length.toLocaleString()} ký tự):
            </span>
            <span className="text-neutral-500 font-semibold">{currentFilename}</span>
          </div>

          <div className="border border-neutral-800 bg-black/95 p-4 text-xs text-neutral-300 rounded-2xl max-h-[360px] overflow-x-auto whitespace-pre leading-relaxed select-all shadow-inner">
            {currentContent}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-5 border-t border-neutral-800 bg-black/80 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-neutral-400">
            Dữ liệu bao gồm thông số 4 thuật toán: RS256, ES256, EdDSA, ML-DSA-44.
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleCopy}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs rounded-xl border border-neutral-700 hover:border-neutral-400 text-white transition-colors bg-neutral-900/80 hover:bg-neutral-800"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Đã sao chép!' : 'Sao chép nội dung'}</span>
            </button>

            <button
              onClick={handleDownload}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-5 py-2 text-xs rounded-xl bg-white text-black font-bold hover:bg-neutral-200 transition-colors shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Tải tệp ngay</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
