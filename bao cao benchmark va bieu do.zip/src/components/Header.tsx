import React from 'react';
import { Download, FileCode, Moon, Sun } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenExport: () => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenExport,
  darkMode,
  setDarkMode,
}) => {
  const navItems = [
    { id: 'comparison', label: 'Bảng So Sánh' },
    { id: 'charts', label: 'Biểu Đồ Hiệu Năng' },
    { id: 'qr', label: 'Khả Năng Quét QR' },
    { id: 'java', label: 'Mã Nguồn Java' },
    { id: 'recommendation', label: 'Ưu Nhược & Đề Xuất' },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-neutral-800 bg-black/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-6">
        {/* Zone 1: Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-8 h-8 rounded-xl border border-white/80 flex items-center justify-center font-bold text-sm tracking-tight bg-white text-black shadow-sm">
            JWT
          </div>
          <span className="font-bold text-base tracking-tight text-white whitespace-nowrap">
            CRYPTO BENCHMARK
          </span>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-1.5 bg-neutral-900/60 p-1 rounded-2xl border border-neutral-800">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-3.5 py-1.5 text-xs rounded-xl transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-white text-black font-bold shadow-sm'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setActiveTab('java')}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-xl border border-neutral-700 hover:border-neutral-400 text-neutral-300 hover:text-white transition-colors bg-neutral-900/80"
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Code Java</span>
          </button>

          <button
            onClick={onOpenExport}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs rounded-xl bg-white text-black font-semibold hover:bg-neutral-200 transition-colors shadow-sm"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Xuất CSV / JSON</span>
          </button>

          <button
            onClick={() => setDarkMode(!darkMode)}
            title="Đổi giao diện đơn sắc"
            className="p-1.5 rounded-xl border border-neutral-800 hover:border-neutral-600 text-neutral-400 hover:text-white transition-colors bg-neutral-900/60"
          >
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </header>
  );
};
