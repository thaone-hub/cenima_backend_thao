import React, { useState } from 'react';
import { JAVA_CODE_SNIPPETS, JavaCodeSnippet } from '../data/javaCodeTemplates';
import { Check, Copy, Download, FileCode, Terminal } from 'lucide-react';
import { downloadFile } from '../services/exportService';

export const JavaCodeViewer: React.FC = () => {
  const [activeSnippetId, setActiveSnippetId] = useState<string>('mldsa44');
  const [copied, setCopied] = useState<boolean>(false);

  const activeSnippet =
    JAVA_CODE_SNIPPETS.find((s) => s.id === activeSnippetId) || JAVA_CODE_SNIPPETS[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(activeSnippet.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const mime = activeSnippet.filename.endsWith('.xml')
      ? 'application/xml'
      : 'text/x-java-source';
    downloadFile(activeSnippet.code, activeSnippet.filename, mime);
  };

  return (
    <div className="border border-neutral-800 bg-neutral-950/80 p-5 sm:p-6 mb-8 rounded-2xl shadow-sm">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-neutral-800">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-2">
            <FileCode className="w-5 h-5 text-white" />
            <span>MÃ NGUỒN JAVA CHUẨN SẢN XUẤT (JAVA 17 / 21 LTS)</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Triển khai chuẩn RS256, ES256, EdDSA (RFC 8037) và ML-DSA-44 Hậu lượng tử (NIST FIPS 204 Bouncy Castle)
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs rounded-xl border border-neutral-700 hover:border-neutral-400 text-white transition-colors bg-neutral-900/80"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Đã chép mã!' : 'Sao chép Code'}</span>
          </button>

          <button
            onClick={handleDownload}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs rounded-xl bg-white text-black font-semibold hover:bg-neutral-200 transition-colors shadow-sm"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Tải tệp ({activeSnippet.filename})</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto py-3 border-b border-neutral-850">
        {JAVA_CODE_SNIPPETS.map((snippet) => (
          <button
            key={snippet.id}
            onClick={() => setActiveSnippetId(snippet.id)}
            className={`px-3.5 py-1.5 text-xs rounded-xl transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeSnippetId === snippet.id
                ? 'bg-white text-black font-bold shadow-sm'
                : 'text-neutral-400 hover:text-white bg-black/80 border border-neutral-800 hover:bg-neutral-900'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>{snippet.title}</span>
          </button>
        ))}
      </div>

      {/* Code Snippet Info */}
      <div className="py-2.5 px-4 bg-black/80 border border-neutral-900 mt-3 flex items-center justify-between text-xs text-neutral-400 rounded-xl">
        <span>
          Tệp: <strong className="text-white">{activeSnippet.filename}</strong> — {activeSnippet.description}
        </span>
        <span className="text-neutral-500 hidden sm:inline">
          {activeSnippet.code.split('\n').length} dòng
        </span>
      </div>

      {/* Code Display Container with line numbers */}
      <div className="mt-3 border border-neutral-800 bg-black/95 rounded-2xl overflow-hidden max-h-[540px] text-xs leading-relaxed relative shadow-inner">
        <pre className="p-4 text-neutral-300 overflow-x-auto">
          <code>
            {activeSnippet.code.split('\n').map((line, idx) => (
              <div key={idx} className="flex hover:bg-neutral-900/60 rounded px-1">
                <span className="w-10 text-neutral-600 select-none text-right pr-4 shrink-0 tabular-nums">
                  {idx + 1}
                </span>
                <span className="whitespace-pre">{line}</span>
              </div>
            ))}
          </code>
        </pre>
      </div>

      {/* Execution Instructions */}
      <div className="mt-4 p-4 border border-neutral-800 bg-black/80 rounded-2xl">
        <div className="flex items-center gap-2 text-xs font-bold text-white mb-2">
          <Terminal className="w-4 h-4 text-white" />
          <span>HƯỚNG DẪN BIÊN DỊCH VÀ CHẠY BENCHMARK BẰNG MAVEN / JMH</span>
        </div>
        <div className="text-xs text-neutral-400 space-y-1.5">
          <p>
            1. Cài đặt JDK 21 LTS: <code className="text-neutral-200 bg-neutral-900 px-1.5 py-0.5 rounded">java -version</code>
          </p>
          <p>
            2. Thêm dependency Bouncy Castle PQC 1.78.1 trở lên để có lớp{' '}
            <code className="text-neutral-200 bg-neutral-900 px-1.5 py-0.5 rounded">org.bouncycastle.pqc.crypto.mldsa.MLDSASigner</code>.
          </p>
          <p>
            3. Chạy kiểm thử vi mô JMH từ dòng lệnh:{' '}
            <code className="text-white bg-neutral-900 px-2 py-0.5 border border-neutral-800 rounded-lg">
              mvn clean package && java -jar target/benchmarks.jar -wi 3 -i 5 -f 1
            </code>
          </p>
        </div>
      </div>
    </div>
  );
};
