import React from 'react';
import { AlgorithmComparisonData } from '../types/crypto';
import { Check, Compass, HelpCircle, Layers, Lightbulb, Shield, ThumbsUp, X } from 'lucide-react';

interface ProsConsRecommendationProps {
  data: AlgorithmComparisonData[];
}

export const ProsConsRecommendation: React.FC<ProsConsRecommendationProps> = ({ data }) => {
  return (
    <div className="border border-neutral-800 bg-neutral-950/80 p-5 sm:p-6 mb-8 rounded-2xl shadow-sm">
      {/* Header */}
      <div className="pb-4 border-b border-neutral-800 mb-6">
        <h2 className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-2">
          <Compass className="w-5 h-5 text-white" />
          <span>SO SÁNH ƯU NHƯỢC ĐIỂM & ĐỀ XUẤT LỰA CHỌN THUẬT TOÁN</span>
        </h2>
        <p className="text-xs text-neutral-400 mt-0.5">
          Phân tích chuyên sâu về mặt mật mã học, kiến trúc hệ thống và khả năng ứng dụng thực tế
        </p>
      </div>

      {/* 4 Algorithms Pros & Cons Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {data.map((item) => (
          <div
            key={item.info.id}
            className="border border-neutral-800 bg-black/90 p-5 rounded-2xl flex flex-col justify-between shadow-sm hover:border-neutral-700 transition-colors"
          >
            <div>
              {/* Header */}
              <div className="flex items-center justify-between pb-3.5 border-b border-neutral-900 mb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-white">{item.info.name}</span>
                    <span className="text-[10px] text-neutral-400 px-2 py-0.5 border border-neutral-800 rounded-full">
                      {item.info.family}
                    </span>
                  </div>
                  <div className="text-xs text-neutral-400 mt-1">
                    {item.info.standard} · An toàn: ~{item.info.securityBitsEquivalent} bits
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-xs text-white font-bold">
                    Kháng lượng tử: {item.info.quantumResistant ? 'CÓ (FIPS 204)' : 'KHÔNG'}
                  </div>
                  <div className="text-[10px] text-neutral-400 mt-0.5">
                    Kích thước JWT: {item.jwt.totalTokenBytes} Bytes
                  </div>
                </div>
              </div>

              {/* Pros */}
              <div className="mb-4">
                <div className="text-xs font-bold text-white mb-2 flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-white" />
                  <span>ƯU ĐIỂM NỔI BẬT</span>
                </div>
                <ul className="space-y-1.5">
                  {item.pros.map((pro, idx) => (
                    <li key={idx} className="text-xs text-neutral-300 flex items-start gap-2">
                      <span className="text-neutral-500 select-none shrink-0">+</span>
                      <span>{pro}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Cons */}
              <div className="mb-4">
                <div className="text-xs font-bold text-neutral-400 mb-2 flex items-center gap-1.5">
                  <X className="w-4 h-4 text-neutral-400" />
                  <span>NHƯỢC ĐIỂM & HẠN CHẾ</span>
                </div>
                <ul className="space-y-1.5">
                  {item.cons.map((con, idx) => (
                    <li key={idx} className="text-xs text-neutral-400 flex items-start gap-2">
                      <span className="text-neutral-600 select-none shrink-0">-</span>
                      <span>{con}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Recommended for */}
            <div className="pt-3 border-t border-neutral-900 mt-2">
              <div className="text-[11px] text-neutral-400 mb-1">
                Ứng dụng đề xuất:
              </div>
              <div className="text-xs text-white leading-relaxed">
                {item.recommendedUseCases.join(' · ')}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Final Recommendation & Architectural Decision Matrix */}
      <div className="border border-neutral-800 bg-black/90 p-5 sm:p-6 rounded-2xl shadow-sm">
        <div className="flex items-center gap-2 mb-4 pb-3 border-b border-neutral-800">
          <Lightbulb className="w-5 h-5 text-white" />
          <h3 className="text-base font-bold text-white uppercase tracking-tight">
            ĐỀ XUẤT KIẾN TRÚC: NÊN SỬ DỤNG THUẬT TOÁN NÀO?
          </h3>
        </div>

        <div className="space-y-5 text-xs leading-relaxed">
          {/* Case 1 */}
          <div className="p-4 border border-neutral-800 bg-neutral-950 rounded-2xl">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-white text-sm">
                1. Ứng dụng Web / Mobile App / REST API / High-throughput Microservices
              </span>
              <span className="bg-white text-black text-[10px] font-bold px-2.5 py-0.5 uppercase rounded-full shadow-sm">
                Khuyến nghị: EdDSA (Ed25519)
              </span>
            </div>
            <p className="text-neutral-300">
              <strong>Lý do:</strong> EdDSA cung cấp hiệu năng số 1 thế giới hiện nay: tốc độ ký nhanh gấp 12 lần RS256, xác minh nhanh gấp 4 lần ES256, và chữ ký chỉ 64 bytes. Token cực kỳ nhỏ gọn (~370 bytes), tiết kiệm băng thông header trong các mạng lưới microservices gọi nhau hàng triệu lần mỗi giây. Khả năng chống tấn công kênh kề tự nhiên bảo vệ an toàn cho các thiết bị di động. Nếu đối tác chưa hỗ trợ EdDSA, <strong>ES256</strong> là phương án dự phòng chuẩn mực tiếp theo.
            </p>
          </div>

          {/* Case 2 */}
          <div className="p-4 border border-neutral-800 bg-neutral-950 rounded-2xl">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-white text-sm">
                2. Hệ thống Enterprise tích hợp Legacy, Cổng SSO, Thư viện bên thứ 3 cũ
              </span>
              <span className="bg-neutral-800 text-white border border-neutral-700 text-[10px] font-bold px-2.5 py-0.5 uppercase rounded-full">
                Khuyến nghị: RS256 hoặc ES256
              </span>
            </div>
            <p className="text-neutral-300">
              <strong>Lý do:</strong> RS256 là thuật toán có độ phủ 100% trên mọi framework và nền tảng (Spring Security 4/5, Keycloak cũ, IIS, Apache OIDC). Nếu hệ sinh thái bao gồm nhiều bên thứ 3 mà bạn không kiểm soát được phiên bản thư viện JOSE của họ, RS256 là lựa chọn an toàn nhất để tránh xung đột tích hợp. Tốc độ xác minh của RS256 cũng rất nhanh (0.08ms) phù hợp cho các Gateway chỉ làm nhiệm vụ kiểm tra token.
            </p>
          </div>

          {/* Case 3 */}
          <div className="p-4 border border-neutral-800 bg-neutral-950 rounded-2xl">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-white text-sm">
                3. Ứng dụng Mã QR (Vé điện tử, Check-in sự kiện, Thẻ căn cước quét ngoại tuyến)
              </span>
              <span className="bg-white text-black text-[10px] font-bold px-2.5 py-0.5 uppercase rounded-full shadow-sm">
                Khuyến nghị: EdDSA hoặc ES256
              </span>
            </div>
            <p className="text-neutral-300">
              <strong>Lý do:</strong> Với kích thước chỉ ~370-390 bytes, mã QR chỉ cần Version 6-8 (khoảng 41x41 đến 49x49 ô). Mọi camera điện thoại giá rẻ đều có thể quét thành công trong dưới 100ms ngay cả khi bị nghiêng hoặc thiếu sáng.
              <br />
              <strong className="text-white">CẢNH BÁO QUAN TRỌNG:</strong> Tuyệt đối <em>KHÔNG</em> nhúng token <strong>ML-DSA-44</strong> trực tiếp vào mã QR in nhỏ (&lt; 10cm). Do chữ ký Dilithium-2 tới 2,420 bytes, mã QR sẽ bị ép lên Version 38-39 (165x165 ô), biến mã QR thành một ma trận đặc nghẹt mà camera thông thường không thể nhận diện được.
            </p>
          </div>

          {/* Case 4 */}
          <div className="p-4 border border-neutral-800 bg-neutral-950 rounded-2xl">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-white text-sm">
                4. Chiến lược Chuyển đổi Hậu Lượng Tử (Post-Quantum Transition 2024-2030)
              </span>
              <span className="bg-white text-black text-[10px] font-bold px-2.5 py-0.5 uppercase rounded-full shadow-sm">
                Khuyến nghị: Hybrid Composite (Ed25519 + ML-DSA-44)
              </span>
            </div>
            <p className="text-neutral-300">
              <strong>Lý do:</strong> Theo chỉ thị của NSA CNSA 2.0 và Viện Tiêu chuẩn NIST (FIPS 204 ban hành tháng 8/2024), các cơ quan tài chính, chính phủ và dữ liệu mật dài hạn cần bắt đầu lộ trình PQC. Giải pháp tốt nhất trong giai đoạn chuyển tiếp là kiến trúc <strong>Hybrid Composite Token</strong>: Ký kết hợp cả Ed25519 (để hệ thống hiện tại xác thực nhanh) và kèm theo chữ ký ML-DSA-44 (để bảo vệ chống giải mã hồi cứu "Harvest Now, Decrypt Later").
            </p>
          </div>
        </div>

        {/* Quick Decision Cheat Sheet Table */}
        <div className="mt-6 pt-4 border-t border-neutral-800">
          <div className="text-xs font-bold text-white mb-3">
            BẢNG TÓM TẮT TIÊU CHÍ RA QUYẾT ĐỊNH NHANH (DECISION CHEAT SHEET)
          </div>

          <div className="overflow-x-auto rounded-xl border border-neutral-800">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-neutral-800 bg-neutral-950 text-neutral-400">
                  <th className="py-2.5 px-3.5">Tiêu chí ưu tiên</th>
                  <th className="py-2.5 px-3.5">Lựa chọn #1</th>
                  <th className="py-2.5 px-3.5">Lựa chọn #2</th>
                  <th className="py-2.5 px-3.5">Tránh sử dụng</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-900 text-neutral-300 bg-black/60">
                <tr>
                  <td className="py-2.5 px-3.5 font-semibold text-white">Tốc độ Ký & Xác minh cao nhất</td>
                  <td className="py-2.5 px-3.5 text-white font-bold">EdDSA (Ed25519)</td>
                  <td className="py-2.5 px-3.5">RS256 (cho verify)</td>
                  <td className="py-2.5 px-3.5 text-neutral-500">RS256 (cho sign)</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3.5 font-semibold text-white">Quét mã QR mượt mà nhất</td>
                  <td className="py-2.5 px-3.5 text-white font-bold">EdDSA</td>
                  <td className="py-2.5 px-3.5">ES256</td>
                  <td className="py-2.5 px-3.5 text-neutral-500 font-bold">ML-DSA-44 (Quá dày)</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3.5 font-semibold text-white">Tương thích rộng nhất (Legacy)</td>
                  <td className="py-2.5 px-3.5 text-white font-bold">RS256</td>
                  <td className="py-2.5 px-3.5">ES256</td>
                  <td className="py-2.5 px-3.5 text-neutral-500">ML-DSA-44</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3.5 font-semibold text-white">Chống máy tính lượng tử tương lai</td>
                  <td className="py-2.5 px-3.5 text-white font-bold">ML-DSA-44 (FIPS 204)</td>
                  <td className="py-2.5 px-3.5">Hybrid (EdDSA + ML-DSA)</td>
                  <td className="py-2.5 px-3.5 text-neutral-500">RS256, ES256, EdDSA</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
