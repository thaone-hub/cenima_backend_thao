import React, { useEffect, useState } from 'react';
import { AlgorithmComparisonData, QrEccLevel } from '../types/crypto';
import { renderQrCodeForToken, QrRenderResult } from '../services/qrAnalyzer';
import { AlertTriangle, CheckCircle, Copy, Eye, QrCode, Scan, Sliders, Smartphone } from 'lucide-react';

interface QrSectionProps {
  data: AlgorithmComparisonData[];
  eccLevel: QrEccLevel;
}

export const QrSection: React.FC<QrSectionProps> = ({ data, eccLevel }) => {
  const [selectedAlgo, setSelectedAlgo] = useState<string>('EdDSA');
  const [qrRenderResults, setQrRenderResults] = useState<Record<string, QrRenderResult>>({});
  const [loading, setLoading] = useState<boolean>(true);
  const [simulatedDistance, setSimulatedDistance] = useState<number>(20); // cm
  const [simulatedLighting, setSimulatedLighting] = useState<'bright' | 'normal' | 'dim'>('normal');
  const [copiedToken, setCopiedToken] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    async function renderAll() {
      setLoading(true);
      const results: Record<string, QrRenderResult> = {};
      for (const item of data) {
        const res = await renderQrCodeForToken(item.jwt.rawToken, eccLevel);
        results[item.info.id] = res;
      }
      if (isMounted) {
        setQrRenderResults(results);
        setLoading(false);
      }
    }
    renderAll();
    return () => {
      isMounted = false;
    };
  }, [data, eccLevel]);

  const activeItem = data.find((d) => d.info.id === selectedAlgo) || data[0];
  const activeQr = qrRenderResults[selectedAlgo];

  // Dynamic simulation score calculation
  const calculateSimulatedResult = (item: AlgorithmComparisonData) => {
    let score = item.qr.readabilityScore;
    if (simulatedLighting === 'dim') score -= 18;
    if (simulatedLighting === 'bright') score += 2;

    if (item.info.id === 'ML-DSA-44') {
      if (simulatedDistance > 22 || simulatedDistance < 10) score -= 20;
    } else {
      if (simulatedDistance < 8 || simulatedDistance > 45) score -= 15;
    }

    score = Math.max(0, Math.min(100, score));
    const pass = score >= 50;
    const estTime = Math.round(item.qr.estimatedScanTimeMs * (100 / Math.max(15, score)));

    return { score, pass, estTime };
  };

  const handleCopyToken = (token: string, id: string) => {
    navigator.clipboard.writeText(token);
    setCopiedToken(id);
    setTimeout(() => setCopiedToken(null), 2000);
  };

  return (
    <div className="border border-neutral-800 bg-neutral-950/80 p-5 sm:p-6 mb-8 rounded-2xl shadow-sm">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-neutral-800">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-2">
            <QrCode className="w-5 h-5 text-white" />
            <span>TỔNG HỢP KẾT QUẢ KHẢ NĂNG QUÉT MÃ QR CỦA TỪNG THUẬT TOÁN</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Trực quan hóa mã QR thực tế, mật độ ma trận ô (Modules) và thử nghiệm tính khả thi trên camera di động
          </p>
        </div>

        {/* Algorithm Tabs */}
        <div className="flex items-center gap-1.5 bg-black/80 p-1.5 border border-neutral-800 rounded-2xl overflow-x-auto">
          {data.map((item) => (
            <button
              key={item.info.id}
              onClick={() => setSelectedAlgo(item.info.id)}
              className={`px-3.5 py-1.5 text-xs rounded-xl transition-all whitespace-nowrap ${
                selectedAlgo === item.info.id
                  ? 'bg-white text-black font-bold shadow-sm'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-900/60'
              }`}
            >
              {item.info.name}
            </button>
          ))}
        </div>
      </div>

      {/* Main interactive area: Selected QR Code vs Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-6">
        {/* Left: Rendered QR Code */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center p-6 border border-neutral-800 bg-black/90 rounded-2xl shadow-sm">
          <div className="w-full flex items-center justify-between text-xs text-neutral-400 mb-4 pb-2 border-b border-neutral-900">
            <span>
              Mã QR Thuật toán: <strong className="text-white">{activeItem.info.name}</strong>
            </span>
            <span className="tabular-nums font-semibold text-white">
              {activeQr ? `v${activeQr.version} (${activeQr.modules}x${activeQr.modules})` : '...'}
            </span>
          </div>

          {/* QR Container */}
          <div className="relative p-5 bg-white border border-neutral-300 max-w-[280px] sm:max-w-[320px] w-full aspect-square flex items-center justify-center rounded-2xl shadow-lg">
            {loading ? (
              <div className="text-black text-xs font-semibold animate-pulse">
                Đang vẽ ma trận mã QR...
              </div>
            ) : activeQr?.dataUrl ? (
              <img
                src={activeQr.dataUrl}
                alt={`Mã QR ${activeItem.info.name}`}
                className="w-full h-full object-contain rounded-lg"
                style={{ imageRendering: 'pixelated' }}
              />
            ) : (
              <div className="text-red-700 text-xs text-center p-2">
                Dữ liệu vượt quá dung lượng tối đa của chuẩn QR Code Model 2.
              </div>
            )}
          </div>

          <div className="w-full mt-4 flex items-center justify-between text-xs">
            <span className="text-neutral-400">
              Kích thước chuỗi: <strong className="text-white">{activeItem.jwt.totalTokenBytes}</strong> ký tự
            </span>
            <button
              onClick={() => handleCopyToken(activeItem.jwt.rawToken, activeItem.info.id)}
              className="inline-flex items-center gap-1.5 text-white hover:text-neutral-200 transition-colors text-xs border border-neutral-800 px-3 py-1.5 bg-neutral-900 rounded-xl hover:bg-neutral-800"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copiedToken === activeItem.info.id ? 'Đã sao chép!' : 'Copy JWT'}</span>
            </button>
          </div>

          {activeItem.info.id === 'ML-DSA-44' && (
            <div className="mt-4 p-3.5 bg-neutral-900/90 border border-neutral-700 text-[11px] text-neutral-300 flex items-start gap-2.5 rounded-xl">
              <AlertTriangle className="w-4 h-4 text-white shrink-0 mt-0.5" />
              <div>
                <strong>Cảnh báo thực địa:</strong> Do chữ ký Dilithium-2 chiếm 2,420 bytes, mã QR này có tới hơn 165x165 ô. Khi in ra kích thước nhỏ (&lt; 10cm), camera điện thoại thông thường sẽ không thể lấy nét từng module điểm ảnh.
              </div>
            </div>
          )}
        </div>

        {/* Right: Technical QR Analysis & Interactive Camera Scanner Simulator */}
        <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="border border-neutral-800 bg-black/90 p-4 rounded-2xl shadow-sm">
              <div className="text-[11px] text-neutral-400">Phiên bản QR (Version)</div>
              <div className="text-lg font-bold text-white mt-1">
                Version {activeItem.qr.qrVersion}
              </div>
              <div className="text-[10px] text-neutral-500 mt-0.5">
                {activeItem.qr.modules} x {activeItem.qr.modules} ô vuông
              </div>
            </div>

            <div className="border border-neutral-800 bg-black/90 p-4 rounded-2xl shadow-sm">
              <div className="text-[11px] text-neutral-400">Điểm khả năng quét</div>
              <div className="text-lg font-bold text-white mt-1 tabular-nums">
                {activeItem.qr.readabilityScore}/100
              </div>
              <div className="text-[10px] text-neutral-500 mt-0.5">
                {activeItem.qr.readabilityScore >= 90 ? 'Tối ưu tuyệt đối' : activeItem.qr.readabilityScore >= 70 ? 'Khá' : 'Rất khó quét'}
              </div>
            </div>

            <div className="border border-neutral-800 bg-black/90 p-4 rounded-2xl shadow-sm">
              <div className="text-[11px] text-neutral-400">Thời gian nhận diện TB</div>
              <div className="text-lg font-bold text-white mt-1 tabular-nums">
                {activeItem.qr.estimatedScanTimeMs} ms
              </div>
              <div className="text-[10px] text-neutral-500 mt-0.5">
                {activeItem.qr.estimatedScanTimeMs < 150 ? 'Tức thì (<0.15s)' : 'Cần giữ yên'}
              </div>
            </div>

            <div className="border border-neutral-800 bg-black/90 p-4 rounded-2xl shadow-sm">
              <div className="text-[11px] text-neutral-400">Kích thước in tối thiểu</div>
              <div className="text-lg font-bold text-white mt-1 tabular-nums">
                ≥ {activeItem.qr.recommendedMinPrintSizeCm} cm
              </div>
              <div className="text-[10px] text-neutral-500 mt-0.5">
                Đảm bảo module ≥ 0.5mm
              </div>
            </div>

            <div className="border border-neutral-800 bg-black/90 p-4 rounded-2xl shadow-sm">
              <div className="text-[11px] text-neutral-400">Khoảng cách quét tối ưu</div>
              <div className="text-sm font-bold text-white mt-1">
                {activeItem.qr.optimalScanDistanceCm}
              </div>
              <div className="text-[10px] text-neutral-500 mt-0.5">
                Tiêu cự camera di động
              </div>
            </div>

            <div className="border border-neutral-800 bg-black/90 p-4 rounded-2xl shadow-sm">
              <div className="text-[11px] text-neutral-400">Tương thích Camera</div>
              <div className="text-xs font-bold text-white mt-1">
                {activeItem.qr.mobileCameraCompatibility}
              </div>
              <div className="text-[10px] text-neutral-500 mt-0.5">
                Thiết bị phổ thông
              </div>
            </div>
          </div>

          {/* Camera Scanner Simulation */}
          <div className="border border-neutral-800 bg-black/90 p-5 rounded-2xl shadow-sm">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-900 mb-3">
              <div className="flex items-center gap-2">
                <Scan className="w-4 h-4 text-white" />
                <span className="text-xs font-bold text-white uppercase">
                  Mô phỏng quét thử nghiệm trên Camera di động
                </span>
              </div>
              <span className="text-[10px] text-neutral-500">
                Real-time optical evaluation
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[11px] text-neutral-400 block mb-1.5 flex justify-between">
                  <span>Khoảng cách camera tới mã QR:</span>
                  <strong className="text-white tabular-nums">{simulatedDistance} cm</strong>
                </label>
                <input
                  type="range"
                  min="5"
                  max="50"
                  value={simulatedDistance}
                  onChange={(e) => setSimulatedDistance(Number(e.target.value))}
                  className="w-full accent-white bg-neutral-800 h-2 rounded-full cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-neutral-500 mt-1.5">
                  <span>5 cm (Quá gần)</span>
                  <span>25 cm (Chuẩn)</span>
                  <span>50 cm (Xa)</span>
                </div>
              </div>

              <div>
                <label className="text-[11px] text-neutral-400 block mb-1.5 flex justify-between">
                  <span>Điều kiện ánh sáng:</span>
                  <strong className="text-white uppercase">{simulatedLighting}</strong>
                </label>
                <div className="flex items-center gap-1.5 bg-neutral-900 p-1 rounded-xl border border-neutral-800">
                  {(['bright', 'normal', 'dim'] as const).map((l) => (
                    <button
                      key={l}
                      onClick={() => setSimulatedLighting(l)}
                      className={`flex-1 py-1.5 text-xs rounded-lg transition-all ${
                        simulatedLighting === l
                          ? 'bg-white text-black font-bold shadow-sm'
                          : 'text-neutral-400 hover:text-white'
                      }`}
                    >
                      {l === 'bright' ? 'Sáng mạnh' : l === 'normal' ? 'Bình thường' : 'Ánh sáng yếu'}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Simulation verdict */}
            {(() => {
              const { score, pass, estTime } = calculateSimulatedResult(activeItem);
              return (
                <div className="mt-4 p-3.5 border border-neutral-800 bg-neutral-950 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center border font-bold text-xs ${
                        pass
                          ? 'border-white bg-white text-black'
                          : 'border-neutral-600 bg-black text-neutral-400'
                      }`}
                    >
                      {pass ? 'OK' : 'FAIL'}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">
                        {pass ? 'Quét thành công' : 'Không quét được hoặc mất nhiều thời gian'}
                      </div>
                      <div className="text-[10px] text-neutral-400 mt-0.5">
                        Độ tin cậy: {score}% · Thời gian phản hồi giả lập: {estTime} ms
                      </div>
                    </div>
                  </div>
                  <div className="text-right text-[11px] text-neutral-400 hidden sm:block">
                    {activeItem.info.id === 'ML-DSA-44'
                      ? 'Yêu cầu ống kính macro & in khổ lớn'
                      : 'Nhận diện tốt trên 99% camera di động'}
                  </div>
                </div>
              );
            })()}
          </div>

          {/* Technical Note */}
          <div className="text-xs text-neutral-400 leading-relaxed p-4 border border-neutral-850 bg-black/80 rounded-xl">
            <strong>Kết luận thực nghiệm QR:</strong>{' '}
            <span className="text-neutral-300">
              Đối với ứng dụng vé điện tử, thẻ căn cước, check-in sự kiện: <strong>EdDSA (Ed25519)</strong> và{' '}
              <strong>ES256</strong> là lựa chọn lý tưởng nhất vì mã QR chỉ ở Version 6-8, module thoáng, quét tức thì.
              Ngược lại, <strong>ML-DSA-44</strong> với &gt;3.6KB khiến mã QR đạt giới hạn kịch trần (Version 38-39). Không nên in trực tiếp token ML-DSA-44 lên thẻ giấy nhỏ; giải pháp chuẩn là ký nén CBOR-COSE hoặc lưu token trên máy chủ và mã QR chỉ mang token ID / URL tham chiếu.
            </span>
          </div>
        </div>
      </div>

      {/* Side-by-Side 4-Algorithm QR Comparison Strip */}
      <div className="mt-8 pt-6 border-t border-neutral-800">
        <h3 className="text-sm font-bold text-white mb-4">
          SO SÁNH TRỰC QUAN MẬT ĐỘ 4 MÃ QR (CÙNG KÍCH THƯỚC HIỂN THỊ)
        </h3>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {data.map((item) => {
            const qr = qrRenderResults[item.info.id];
            const isSelected = item.info.id === selectedAlgo;
            return (
              <div
                key={item.info.id}
                onClick={() => setSelectedAlgo(item.info.id)}
                className={`border p-4 rounded-2xl flex flex-col items-center justify-between cursor-pointer transition-all shadow-sm ${
                  isSelected
                    ? 'border-white bg-neutral-900/90 scale-[1.02]'
                    : 'border-neutral-800 bg-black/80 hover:border-neutral-600 hover:bg-neutral-900/40'
                }`}
              >
                <div className="w-full flex justify-between items-center text-xs mb-3">
                  <span className="font-bold text-white">{item.info.name}</span>
                  <span className="text-[10px] text-neutral-300 bg-neutral-800 px-2 py-0.5 rounded-full">v{item.qr.qrVersion}</span>
                </div>

                <div className="w-32 h-32 sm:w-36 sm:h-36 bg-white p-3 border border-neutral-300 rounded-xl flex items-center justify-center shadow-inner">
                  {qr?.dataUrl ? (
                    <img
                      src={qr.dataUrl}
                      alt={item.info.name}
                      className="w-full h-full object-contain rounded-md"
                      style={{ imageRendering: 'pixelated' }}
                    />
                  ) : (
                    <div className="text-[10px] text-black">Đang tải...</div>
                  )}
                </div>

                <div className="w-full mt-3.5 text-center">
                  <div className="text-[11px] font-semibold text-white">
                    {item.qr.modules}x{item.qr.modules} modules
                  </div>
                  <div className="text-[10px] text-neutral-400 mt-0.5">
                    {item.jwt.totalTokenBytes} Bytes · Điểm: {item.qr.readabilityScore}/100
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
