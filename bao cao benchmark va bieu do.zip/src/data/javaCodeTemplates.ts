export interface JavaCodeSnippet {
  id: string;
  title: string;
  filename: string;
  description: string;
  code: string;
}

export const JAVA_CODE_SNIPPETS: JavaCodeSnippet[] = [
  {
    id: 'pom',
    title: 'Maven pom.xml / Dependencies',
    filename: 'pom.xml',
    description: 'Thư viện Bouncy Castle 1.78+ (hỗ trợ FIPS 204 ML-DSA) và Nimbus JOSE+JWT cho Java 17/21',
    code: `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.security.benchmark</groupId>
    <artifactId>jwt-crypto-benchmark</artifactId>
    <version>1.0.0</version>

    <properties>
        <maven.compiler.source>21</maven.compiler.source>
        <maven.compiler.target>21</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <bouncycastle.version>1.78.1</bouncycastle.version>
        <nimbus.version>9.37.3</nimbus.version>
        <jmh.version>1.37</jmh.version>
    </properties>

    <dependencies>
        <!-- Nimbus JOSE + JWT: Chuẩn công nghiệp cho RS256, ES256, EdDSA -->
        <dependency>
            <groupId>com.nimbusds</groupId>
            <artifactId>nimbus-jose-jwt</artifactId>
            <version>\${nimbus.version}</version>
        </dependency>

        <!-- Bouncy Castle: Hỗ trợ mật mã hậu lượng tử PQC FIPS 204 (ML-DSA-44) -->
        <dependency>
            <groupId>org.bouncycastle</groupId>
            <artifactId>bcprov-jdk18on</artifactId>
            <version>\${bouncycastle.version}</version>
        </dependency>
        <dependency>
            <groupId>org.bouncycastle</groupId>
            <artifactId>bcpqc-jdk18on</artifactId>
            <version>\${bouncycastle.version}</version>
        </dependency>

        <!-- JMH (Java Microbenchmark Harness) đo lường chính xác nano-giây -->
        <dependency>
            <groupId>org.openjdk.jmh</groupId>
            <artifactId>jmh-core</artifactId>
            <version>\${jmh.version}</version>
        </dependency>
        <dependency>
            <groupId>org.openjdk.jmh</groupId>
            <artifactId>jmh-generator-annprocess</artifactId>
            <version>\${jmh.version}</version>
            <scope>provided</scope>
        </dependency>
    </dependencies>
</project>`
  },
  {
    id: 'rs256',
    title: '1. RS256 (RSA 2048)',
    filename: 'RS256JwtSigner.java',
    description: 'Tạo khóa RSA 2048-bit, ký token và xác thực chữ ký RS256 qua Nimbus JOSE JWT',
    code: `package com.security.benchmark.jwt;

import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.time.Instant;
import java.util.Date;
import java.util.UUID;

public class RS256JwtSigner {

    private final KeyPair keyPair;

    public RS256JwtSigner() throws Exception {
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(2048);
        this.keyPair = generator.generateKeyPair();
    }

    /**
     * Ký JWT bằng thuật toán RS256 (RSASSA-PKCS1-v1_5 với SHA-256)
     * Kích thước chữ ký: 256 bytes (2048 bits)
     */
    public String sign(String subject, String role, long ttlSeconds) throws JOSEException {
        JWSSigner signer = new RSASSASigner((RSAPrivateKey) keyPair.getPrivate());

        Instant now = Instant.now();
        JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
                .subject(subject)
                .issuer("https://auth.company.com")
                .audience("api://default")
                .claim("role", role)
                .issueTime(Date.from(now))
                .expirationTime(Date.from(now.plusSeconds(ttlSeconds)))
                .jwtID(UUID.randomUUID().toString())
                .build();

        SignedJWT signedJWT = new SignedJWT(
                new JWSHeader.Builder(JWSAlgorithm.RS256).type(JOSEObjectType.JWT).build(),
                claimsSet
        );

        signedJWT.sign(signer);
        return signedJWT.serialize();
    }

    /**
     * Xác minh chữ ký RS256 của JWT bằng Public Key (270 bytes DER)
     */
    public boolean verify(String token) {
        try {
            SignedJWT signedJWT = SignedJWT.parse(token);
            JWSVerifier verifier = new RSASSAVerifier((RSAPublicKey) keyPair.getPublic());
            return signedJWT.verify(verifier) && 
                   new Date().before(signedJWT.getJWTClaimsSet().getExpirationTime());
        } catch (Exception e) {
            return false;
        }
    }
}`
  },
  {
    id: 'es256',
    title: '2. ES256 (ECDSA P-256)',
    filename: 'ES256JwtSigner.java',
    description: 'Đường cong Elliptic NIST P-256 (secp256r1), kích thước chữ ký nhỏ gọn 64 bytes (IEEE P1363)',
    code: `package com.security.benchmark.jwt;

import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.ECDSASigner;
import com.nimbusds.jose.crypto.ECDSAVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECGenParameterSpec;
import java.time.Instant;
import java.util.Date;
import java.util.UUID;

public class ES256JwtSigner {

    private final KeyPair keyPair;

    public ES256JwtSigner() throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC");
        kpg.initialize(new ECGenParameterSpec("secp256r1"));
        this.keyPair = kpg.generateKeyPair();
    }

    /**
     * Ký JWT bằng thuật toán ES256 (ECDSA qua P-256 + SHA-256)
     * Kích thước chữ ký: 64 bytes (R: 32 bytes + S: 32 bytes)
     */
    public String sign(String subject, String role, long ttlSeconds) throws JOSEException {
        JWSSigner signer = new ECDSASigner((ECPrivateKey) keyPair.getPrivate());

        Instant now = Instant.now();
        JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
                .subject(subject)
                .issuer("https://auth.company.com")
                .audience("api://default")
                .claim("role", role)
                .issueTime(Date.from(now))
                .expirationTime(Date.from(now.plusSeconds(ttlSeconds)))
                .jwtID(UUID.randomUUID().toString())
                .build();

        SignedJWT signedJWT = new SignedJWT(
                new JWSHeader.Builder(JWSAlgorithm.ES256).type(JOSEObjectType.JWT).build(),
                claimsSet
        );

        signedJWT.sign(signer);
        return signedJWT.serialize();
    }

    /**
     * Xác minh chữ ký ES256 bằng Public Key (65 bytes uncompressed)
     */
    public boolean verify(String token) {
        try {
            SignedJWT signedJWT = SignedJWT.parse(token);
            JWSVerifier verifier = new ECDSAVerifier((ECPublicKey) keyPair.getPublic());
            return signedJWT.verify(verifier) && 
                   new Date().before(signedJWT.getJWTClaimsSet().getExpirationTime());
        } catch (Exception e) {
            return false;
        }
    }
}`
  },
  {
    id: 'eddsa',
    title: '3. EdDSA (Ed25519 - RFC 8037)',
    filename: 'EdDSAJwtSigner.java',
    description: 'Edwards-curve Digital Signature (Ed25519) - tốc độ ký & xác minh cao nhất, chữ ký 64 bytes',
    code: `package com.security.benchmark.jwt;

import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.Ed25519Signer;
import com.nimbusds.jose.crypto.Ed25519Verifier;
import com.nimbusds.jose.jwk.Curve;
import com.nimbusds.jose.jwk.OctetKeyPair;
import com.nimbusds.jose.jwk.gen.OctetKeyPairGenerator;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

import java.time.Instant;
import java.util.Date;
import java.util.UUID;

public class EdDSAJwtSigner {

    private final OctetKeyPair jwk;

    public EdDSAJwtSigner() throws Exception {
        // Sinh cặp khóa Ed25519 chuẩn RFC 8037
        this.jwk = new OctetKeyPairGenerator(Curve.Ed25519)
                .keyID(UUID.randomUUID().toString())
                .generate();
    }

    /**
     * Ký JWT bằng thuật toán EdDSA (Ed25519)
     * Chữ ký: 64 bytes, Khóa công khai: 32 bytes (nhỏ nhất)
     */
    public String sign(String subject, String role, long ttlSeconds) throws JOSEException {
        JWSSigner signer = new Ed25519Signer(jwk);

        Instant now = Instant.now();
        JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
                .subject(subject)
                .issuer("https://auth.company.com")
                .audience("api://default")
                .claim("role", role)
                .issueTime(Date.from(now))
                .expirationTime(Date.from(now.plusSeconds(ttlSeconds)))
                .jwtID(UUID.randomUUID().toString())
                .build();

        SignedJWT signedJWT = new SignedJWT(
                new JWSHeader.Builder(JWSAlgorithm.EdDSA).keyID(jwk.getKeyID()).type(JOSEObjectType.JWT).build(),
                claimsSet
        );

        signedJWT.sign(signer);
        return signedJWT.serialize();
    }

    /**
     * Xác minh EdDSA với tốc độ cao, khả năng chống tấn công kênh kề (side-channel safe)
     */
    public boolean verify(String token) {
        try {
            SignedJWT signedJWT = SignedJWT.parse(token);
            JWSVerifier verifier = new Ed25519Verifier(jwk.toPublicJWK());
            return signedJWT.verify(verifier) && 
                   new Date().before(signedJWT.getJWTClaimsSet().getExpirationTime());
        } catch (Exception e) {
            return false;
        }
    }
}`
  },
  {
    id: 'mldsa44',
    title: '4. ML-DSA-44 (FIPS 204 Dilithium-2)',
    filename: 'MLDSA44JwtSigner.java',
    description: 'Chữ ký hậu lượng tử NIST FIPS 204 (Lattice-based). Chữ ký: 2,420 bytes, Public Key: 1,312 bytes',
    code: `package com.security.benchmark.jwt;

import org.bouncycastle.pqc.crypto.mldsa.MLDSAKeyGenerationParameters;
import org.bouncycastle.pqc.crypto.mldsa.MLDSAKeyPairGenerator;
import org.bouncycastle.pqc.crypto.mldsa.MLDSAParameters;
import org.bouncycastle.pqc.crypto.mldsa.MLDSAPrivateKeyParameters;
import org.bouncycastle.pqc.crypto.mldsa.MLDSAPublicKeyParameters;
import org.bouncycastle.pqc.crypto.mldsa.MLDSASigner;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Triển khai JWT hậu lượng tử (Post-Quantum Cryptography - PQC)
 * Tuân theo chuẩn NIST FIPS 204 (ML-DSA-44 / Dilithium-2)
 * Cung cấp cấp độ bảo mật NIST Level 2 (~128-bit quantum security)
 */
public class MLDSA44JwtSigner {

    private final MLDSAPrivateKeyParameters privateKey;
    private final MLDSAPublicKeyParameters publicKey;
    private static final Base64.Encoder B64_URL_ENC = Base64.getUrlEncoder().withoutPadding();
    private static final Base64.Decoder B64_URL_DEC = Base64.getUrlDecoder();

    public MLDSA44JwtSigner() {
        // Sinh cặp khóa ML-DSA-44 qua Bouncy Castle PQC
        MLDSAKeyPairGenerator keyGen = new MLDSAKeyPairGenerator();
        keyGen.init(new MLDSAKeyGenerationParameters(new SecureRandom(), MLDSAParameters.ml_dsa_44));
        AsymmetricCipherKeyPair keyPair = keyGen.generateKeyPair();
        
        this.privateKey = (MLDSAPrivateKeyParameters) keyPair.getPrivate();
        this.publicKey = (MLDSAPublicKeyParameters) keyPair.getPublic();
    }

    /**
     * Ký JWT định dạng JWS: {header}.{payload}.{signature}
     * - Header: {"alg":"ML-DSA-44","typ":"JWT"}
     * - Kích thước Public Key: 1,312 bytes
     * - Kích thước Chữ ký: 2,420 bytes (mã hóa Base64URL ~3,228 ký tự)
     */
    public String sign(String payloadJson) {
        String headerJson = "{\\"alg\\":\\"ML-DSA-44\\",\\"typ\\":\\"JWT\\"}";
        String encodedHeader = B64_URL_ENC.encodeToString(headerJson.getBytes(StandardCharsets.UTF_8));
        String encodedPayload = B64_URL_ENC.encodeToString(payloadJson.getBytes(StandardCharsets.UTF_8));
        
        String signingInput = encodedHeader + "." + encodedPayload;
        byte[] inputBytes = signingInput.getBytes(StandardCharsets.US_ASCII);

        // Ký số mạng tinh thể (Module-Lattice)
        MLDSASigner signer = new MLDSASigner();
        signer.init(true, this.privateKey);
        byte[] signatureBytes = signer.generateSignature(inputBytes); // Exactly 2,420 bytes

        String encodedSignature = B64_URL_ENC.encodeToString(signatureBytes);
        return signingInput + "." + encodedSignature;
    }

    /**
     * Xác minh JWT hậu lượng tử
     */
    public boolean verify(String token) {
        try {
            int firstDot = token.indexOf('.');
            int secondDot = token.indexOf('.', firstDot + 1);
            if (firstDot <= 0 || secondDot <= firstDot) return false;

            String signingInput = token.substring(0, secondDot);
            String encodedSignature = token.substring(secondDot + 1);

            byte[] inputBytes = signingInput.getBytes(StandardCharsets.US_ASCII);
            byte[] signatureBytes = B64_URL_DEC.decode(encodedSignature);

            MLDSASigner verifier = new MLDSASigner();
            verifier.init(false, this.publicKey);
            return verifier.verifySignature(inputBytes, signatureBytes);
        } catch (Exception e) {
            return false;
        }
    }

    public byte[] getPublicKeyEncoded() {
        return publicKey.getEncoded(); // 1,312 bytes
    }
}`
  },
  {
    id: 'jmh',
    title: '5. JMH Microbenchmark Runner',
    filename: 'JwtBenchmarkJmhSuite.java',
    description: 'Harness đo đạc hiệu năng signing & verification chính xác theo chu kỳ CPU (Ops/sec, Latency)',
    code: `package com.security.benchmark;

import com.security.benchmark.jwt.*;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;

import java.util.concurrent.TimeUnit;

@BenchmarkMode(Mode.Throughput)
@OutputTimeUnit(TimeUnit.SECONDS)
@Warmup(iterations = 3, time = 1)
@Measurement(iterations = 5, time = 2)
@Fork(1)
@State(Scope.Benchmark)
public class JwtBenchmarkJmhSuite {

    private RS256JwtSigner rs256;
    private ES256JwtSigner es256;
    private EdDSAJwtSigner eddsa;
    private MLDSA44JwtSigner mldsa44;

    private String rs256Token;
    private String es256Token;
    private String eddsaToken;
    private String mldsa44Token;

    private static final String PAYLOAD = "{\\"sub\\":\\"usr_9921\\",\\"role\\":\\"admin\\",\\"exp\\":1798368000}";

    @Setup
    public void setup() throws Exception {
        rs256 = new RS256JwtSigner();
        es256 = new ES256JwtSigner();
        eddsa = new EdDSAJwtSigner();
        mldsa44 = new MLDSA44JwtSigner();

        rs256Token = rs256.sign("usr_9921", "admin", 3600);
        es256Token = es256.sign("usr_9921", "admin", 3600);
        eddsaToken = eddsa.sign("usr_9921", "admin", 3600);
        mldsa44Token = mldsa44.sign(PAYLOAD);
    }

    @Benchmark
    public String benchmarkSignRS256() throws Exception {
        return rs256.sign("usr_9921", "admin", 3600);
    }

    @Benchmark
    public boolean benchmarkVerifyRS256() {
        return rs256.verify(rs256Token);
    }

    @Benchmark
    public String benchmarkSignES256() throws Exception {
        return es256.sign("usr_9921", "admin", 3600);
    }

    @Benchmark
    public boolean benchmarkVerifyES256() {
        return es256.verify(es256Token);
    }

    @Benchmark
    public String benchmarkSignEdDSA() throws Exception {
        return eddsa.sign("usr_9921", "admin", 3600);
    }

    @Benchmark
    public boolean benchmarkVerifyEdDSA() {
        return eddsa.verify(eddsaToken);
    }

    @Benchmark
    public String benchmarkSignMLDSA44() {
        return mldsa44.sign(PAYLOAD);
    }

    @Benchmark
    public boolean benchmarkVerifyMLDSA44() {
        return mldsa44.verify(mldsa44Token);
    }

    public static void main(String[] args) throws Exception {
        Options opt = new OptionsBuilder()
                .include(JwtBenchmarkJmhSuite.class.getSimpleName())
                .addProfiler("gc") // Đo đạc tỷ lệ cấp phát bộ nhớ RAM và áp lực Garbage Collector
                .build();
        new Runner(opt).run();
    }
}`
  },
  {
    id: 'cpu-ram-runner',
    title: '6. CPU / RAM & KeyGen Profiler',
    filename: 'CpuRamProfilerRunner.java',
    description: 'Chương trình đo đạc tải CPU (%), bộ nhớ RAM heap (KB/op) và thời gian sinh khóa KeyGen (ms) cho 4 thuật toán',
    code: `package com.security.benchmark;

import com.security.benchmark.jwt.*;
import com.sun.management.OperatingSystemMXBean;

import java.lang.management.ManagementFactory;
import java.security.KeyPairGenerator;
import java.security.spec.ECGenParameterSpec;
import java.util.concurrent.TimeUnit;
import org.bouncycastle.pqc.crypto.mldsa.*;
import java.security.SecureRandom;

/**
 * Đo lường chuyên sâu:
 * 1. Thời gian tạo khóa (KeyGen Time in ms)
 * 2. Tiêu thụ bộ nhớ RAM Heap (KB / 1000 ops)
 * 3. Tải CPU trung bình (%)
 */
public class CpuRamProfilerRunner {

    private static final OperatingSystemMXBean osBean = 
            (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();

    public static void main(String[] args) throws Exception {
        System.out.println("==========================================================================");
        System.out.println("JWT CRYPTOGRAPHIC BENCHMARK: KEYGEN, CPU LOAD, & RAM ALLOCATION (JAVA 21)");
        System.out.println("==========================================================================");

        benchmarkKeyGenRS256();
        benchmarkKeyGenES256();
        benchmarkKeyGenEdDSA();
        benchmarkKeyGenMLDSA44();

        benchmarkCpuRamUsage();
    }

    private static void benchmarkKeyGenRS256() throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048);
        
        // Warmup
        for (int i = 0; i < 20; i++) kpg.generateKeyPair();

        long start = System.nanoTime();
        int runs = 100;
        for (int i = 0; i < runs; i++) {
            kpg.generateKeyPair();
        }
        double avgMs = (System.nanoTime() - start) / (runs * 1_000_000.0);
        System.out.printf("[RS256]    KeyGen Time: %7.3f ms | Key Size: Public 270B, Private 1190B%n", avgMs);
    }

    private static void benchmarkKeyGenES256() throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC");
        kpg.initialize(new ECGenParameterSpec("secp256r1"));
        
        for (int i = 0; i < 100; i++) kpg.generateKeyPair();

        long start = System.nanoTime();
        int runs = 1000;
        for (int i = 0; i < runs; i++) {
            kpg.generateKeyPair();
        }
        double avgMs = (System.nanoTime() - start) / (runs * 1_000_000.0);
        System.out.printf("[ES256]    KeyGen Time: %7.3f ms | Key Size: Public 65B,  Private 32B%n", avgMs);
    }

    private static void benchmarkKeyGenEdDSA() throws Exception {
        // Curve25519 KeyGen in Java 15+ native or Nimbus OctetKeyPairGenerator
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("Ed25519");
        for (int i = 0; i < 100; i++) kpg.generateKeyPair();

        long start = System.nanoTime();
        int runs = 2000;
        for (int i = 0; i < runs; i++) {
            kpg.generateKeyPair();
        }
        double avgMs = (System.nanoTime() - start) / (runs * 1_000_000.0);
        System.out.printf("[EdDSA]    KeyGen Time: %7.3f ms | Key Size: Public 32B,  Private 32B%n", avgMs);
    }

    private static void benchmarkKeyGenMLDSA44() {
        MLDSAKeyPairGenerator keyGen = new MLDSAKeyPairGenerator();
        keyGen.init(new MLDSAKeyGenerationParameters(new SecureRandom(), MLDSAParameters.ml_dsa_44));
        for (int i = 0; i < 50; i++) keyGen.generateKeyPair();

        long start = System.nanoTime();
        int runs = 500;
        for (int i = 0; i < runs; i++) {
            keyGen.generateKeyPair();
        }
        double avgMs = (System.nanoTime() - start) / (runs * 1_000_000.0);
        System.out.printf("[ML-DSA-44] KeyGen Time: %7.3f ms | Key Size: Public 1312B, Private 2560B%n", avgMs);
    }

    private static void benchmarkCpuRamUsage() throws Exception {
        System.out.println("--------------------------------------------------------------------------");
        System.out.println("ĐO ĐẠC TẢI CPU (%) VÀ BỘ NHỚ HEAP TRONG QUÁ TRÌNH KÝ 10,000 TOKENS:");

        EdDSAJwtSigner eddsa = new EdDSAJwtSigner();
        MLDSA44JwtSigner mldsa = new MLDSA44JwtSigner();

        measureAlgorithmResource("EdDSA (Ed25519)", () -> {
            try { eddsa.sign("usr_bench", "user", 3600); } catch (Exception e) {}
        });

        measureAlgorithmResource("ML-DSA-44 (FIPS 204)", () -> {
            mldsa.sign("{\\"sub\\":\\"usr_bench\\",\\"role\\":\\"user\\"}");
        });
    }

    private static void measureAlgorithmResource(String name, Runnable task) {
        System.gc();
        long memBefore = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        double initialCpu = osBean.getCpuLoad();

        long start = System.currentTimeMillis();
        int ops = 10_000;
        for (int i = 0; i < ops; i++) {
            task.run();
        }
        long duration = System.currentTimeMillis() - start;
        long memAfter = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        double finalCpu = osBean.getProcessCpuLoad() * 100.0;

        long allocatedKb = Math.max(0, (memAfter - memBefore) / 1024);
        System.out.printf("-> %-20s: %d ops in %d ms | CPU: ~%.1f%% | Heap Delta: %d KB%n",
                name, ops, duration, finalCpu, allocatedKb);
    }
}`
  }
];
