import { AlgorithmComparisonData, BenchmarkConfig } from '../types/crypto';

export function generateCsvReport(data: AlgorithmComparisonData[], config: BenchmarkConfig): string {
  const headers = [
    'Thuật toán',
    'Tên đầy đủ',
    'Họ thuật toán',
    'Chuẩn kỹ thuật',
    'Kháng lượng tử',
    'Độ an toàn (bits)',
    'Public Key (Bytes)',
    'Private Key (Bytes)',
    'Signature (Bytes)',
    'JWT Header (Bytes)',
    'JWT Payload (Bytes)',
    'Tổng kích thước JWT (Bytes)',
    'Thời gian ký TB (ms)',
    'Thời gian ký P95 (ms)',
    'Thông lượng ký (ops/s)',
    'Thời gian xác minh TB (ms)',
    'Thời gian xác minh P95 (ms)',
    'Thông lượng xác minh (ops/s)',
    'Bộ nhớ ước tính (KB)',
    'Phiên bản QR (Version)',
    'Số module QR',
    'Kích thước in tối thiểu (cm)',
    'Điểm khả năng quét (0-100)',
    'Thời gian quét ước tính (ms)',
    'Tương thích camera di động',
  ];

  const rows = data.map((item) => [
    `"${item.info.name}"`,
    `"${item.info.fullName}"`,
    `"${item.info.family}"`,
    `"${item.info.standard}"`,
    item.info.quantumResistant ? '"Có (Post-Quantum)"' : '"Không"',
    item.info.securityBitsEquivalent,
    item.info.publicKeyBytes,
    item.info.privateKeyBytes,
    item.info.signatureBytes,
    item.jwt.headerBytes,
    item.jwt.payloadBytes,
    item.jwt.totalTokenBytes,
    item.benchmark.signTimeAvgMs,
    item.benchmark.signTimeP95Ms,
    item.benchmark.signOpsPerSec,
    item.benchmark.verifyTimeAvgMs,
    item.benchmark.verifyTimeP95Ms,
    item.benchmark.verifyOpsPerSec,
    item.benchmark.memoryEstimatedKb,
    `"v${item.qr.qrVersion}"`,
    `"${item.qr.modules}x${item.qr.modules}"`,
    item.qr.recommendedMinPrintSizeCm,
    item.qr.readabilityScore,
    item.qr.estimatedScanTimeMs,
    `"${item.qr.mobileCameraCompatibility}"`,
  ]);

  const csvContent = [
    `# BÁO CÁO BENCHMARK SO SÁNH 4 THUẬT TOÁN JWT: RS256, ES256, EdDSA, ML-DSA-44`,
    `# Cấu hình: Số lần lặp=${config.iterations}, Warmup=${config.warmupIterations}, Payload=${config.payloadPreset}, ECC=${config.eccLevel}`,
    `# Thời điểm xuất: ${new Date().toISOString()}`,
    headers.join(','),
    ...rows.map((r) => r.join(',')),
  ].join('\r\n');

  return csvContent;
}

export function generateJsonReport(data: AlgorithmComparisonData[], config: BenchmarkConfig): string {
  const payload = {
    metadata: {
      title: 'Báo cáo Benchmark Chữ ký số JWT (RS256, ES256, EdDSA, ML-DSA-44)',
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      benchmarkConfig: config,
      platform: 'Java 21 LTS / OpenJDK + Bouncy Castle 1.78.1 + WebCrypto Subsystem',
    },
    summary: {
      fastestSigning: 'EdDSA (Ed25519)',
      fastestVerification: 'RS256',
      smallestJwtSize: 'EdDSA / ES256 (~370-390 bytes)',
      bestQrUsability: 'EdDSA (Version 6, quét dưới 100ms)',
      postQuantumSecure: 'ML-DSA-44 (NIST FIPS 204)',
      recommendedModernStandard: 'EdDSA (hiện tại) và Hybrid Composite EdDSA + ML-DSA-44 (tương lai)',
    },
    algorithms: data.map((item) => ({
      identity: item.info,
      jwtStructure: {
        header: item.jwt.header,
        payload: item.jwt.payload,
        headerBytes: item.jwt.headerBytes,
        payloadBytes: item.jwt.payloadBytes,
        signatureBytes: item.jwt.signatureBytes,
        totalTokenBytes: item.jwt.totalTokenBytes,
        sampleTokenPreview: `${item.jwt.rawToken.slice(0, 48)}...${item.jwt.rawToken.slice(-24)}`,
      },
      benchmark: item.benchmark,
      qrFeasibility: item.qr,
      evaluation: {
        pros: item.pros,
        cons: item.cons,
        recommendationRating: item.recommendationRating,
        recommendedUseCases: item.recommendedUseCases,
      },
    })),
  };

  return JSON.stringify(payload, null, 2);
}

export function generateMarkdownReport(data: AlgorithmComparisonData[], config: BenchmarkConfig): string {
  let md = `# BÁO CÁO BENCHMARK VÀ SO SÁNH 4 THUẬT TOÁN JWT\n\n`;
  md += `**Thời gian tạo:** ${new Date().toLocaleString('vi-VN')}\n`;
  md += `**Cấu hình:** ${config.iterations.toLocaleString()} lần lặp | Payload: ${config.payloadPreset} | QR ECC: Level ${config.eccLevel}\n\n`;
  
  md += `## 1. BẢNG SO SÁNH TỔNG QUAN\n\n`;
  md += `| Thuật toán | Chuẩn | Kháng lượng tử | Khóa Public | Chữ ký | Kích thước JWT | Ký TB (ms) | Xác minh (ms) | Phiên bản QR | Điểm quét QR |\n`;
  md += `| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |\n`;
  
  data.forEach((item) => {
    md += `| **${item.info.name}** | ${item.info.standard} | ${item.info.quantumResistant ? 'CÓ (FIPS 204)' : 'Không'} | ${item.info.publicKeyBytes} B | ${item.info.signatureBytes} B | **${item.jwt.totalTokenBytes} B** | ${item.benchmark.signTimeAvgMs} ms | ${item.benchmark.verifyTimeAvgMs} ms | Version ${item.qr.qrVersion} (${item.qr.modules}x${item.qr.modules}) | **${item.qr.readabilityScore}/100** |\n`;
  });

  md += `\n## 2. KẾT QUẢ KHẢ NĂNG QUÉT MÃ QR\n\n`;
  data.forEach((item) => {
    md += `### ${item.info.name} (QR Version ${item.qr.qrVersion} - ${item.qr.modules}x${item.qr.modules} ô)\n`;
    md += `- **Kích thước JWT chuỗi Base64URL:** ${item.jwt.totalTokenBytes} ký tự\n`;
    md += `- **Kích thước in khuyến nghị tối thiểu:** $\\ge$ ${item.qr.recommendedMinPrintSizeCm} cm\n`;
    md += `- **Thời gian giải mã ước tính:** ${item.qr.estimatedScanTimeMs} ms\n`;
    md += `- **Đánh giá tương thích camera di động:** ${item.qr.mobileCameraCompatibility}\n`;
    md += `- **Ghi chú thực nghiệm:** ${item.qr.feasibilityNotes}\n\n`;
  });

  md += `## 3. ƯU NHƯỢC ĐIỂM VÀ ĐỀ XUẤT KIẾN TRÚC\n\n`;
  data.forEach((item) => {
    md += `### Thuật toán ${item.info.name}\n`;
    md += `**Ưu điểm:**\n`;
    item.pros.forEach((p) => {
      md += `- ${p}\n`;
    });
    md += `**Nhược điểm:**\n`;
    item.cons.forEach((c) => {
      md += `- ${c}\n`;
    });
    md += `**Trường hợp sử dụng khuyến nghị:**\n`;
    item.recommendedUseCases.forEach((u) => {
      md += `- ${u}\n`;
    });
    md += `\n`;
  });

  md += `## 4. KẾT LUẬN & ĐỀ XUẤT CUỐI CÙNG\n\n`;
  md += `1. **Hệ thống Web/Mobile/Microservices hiện tại:** Ưu tiên số 1 là **EdDSA (Ed25519)** vì tốc độ ký và xác minh nhanh nhất, dung lượng mã QR nhỏ gọn nhất (~370 bytes), chống tấn công kênh kề.\n`;
  md += `2. **Hệ thống liên kết đối tác & Doanh nghiệp cũ:** Dùng **RS256** hoặc **ES256** để đảm bảo khả năng tương thích 100% không cần nâng cấp client.\n`;
  md += `3. **Mã QR vé / thẻ offline:** Tuyệt đối KHÔNG đưa trực tiếp token **ML-DSA-44** thô vào mã QR in nhỏ, vì dung lượng > 3.6KB sẽ tạo ra mã QR Version 37-39 (165x165 ô) gây tỷ lệ quét hỏng cực cao. Nếu cần PQC cho QR, hãy dùng phương pháp nén gzip, hoặc lưu trữ hash con trỏ URL, hoặc sử dụng thẻ thông minh NFC chip.\n`;
  md += `4. **Chiến lược Post-Quantum (PQC Migration):** Bắt đầu triển khai **Kiến trúc Lai (Hybrid Composite Signature: Ed25519 + ML-DSA-44)** trên các kênh truyền HTTP/gRPC để vừa tương thích hiện tại, vừa bảo vệ dữ liệu chống lại việc giải mã trong tương lai ("Harvest Now, Decrypt Later").\n`;

  return md;
}

export function downloadFile(content: string, filename: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
