import QRCode from 'qrcode';
import { QrEccLevel } from '../types/crypto';

export interface QrRenderResult {
  dataUrl: string;
  svgString: string;
  version: number;
  modules: number;
  densityPercent: number; // relative to max v40
  isTooDenseForCamera: boolean;
}

export async function renderQrCodeForToken(
  token: string,
  eccLevel: QrEccLevel = 'M'
): Promise<QrRenderResult> {
  try {
    const errorCorrectionLevel = eccLevel;

    // Generate high-resolution data URL
    const dataUrl = await QRCode.toDataURL(token, {
      errorCorrectionLevel,
      margin: 2,
      scale: 6,
      color: {
        dark: '#000000',
        light: '#FFFFFF',
      },
    });

    const svgString = await QRCode.toString(token, {
      type: 'svg',
      errorCorrectionLevel,
      margin: 2,
      color: {
        dark: '#000000',
        light: '#FFFFFF',
      },
    });

    // Approximate version from length or parse SVG viewbox
    // Match viewBox="0 0 N N"
    const match = svgString.match(/viewBox="0 0 (\d+) (\d+)"/);
    let modulesWithMargin = 0;
    if (match && match[1]) {
      modulesWithMargin = parseInt(match[1], 10);
    }
    const modules = modulesWithMargin > 4 ? modulesWithMargin - 4 : 21;
    const version = Math.max(1, Math.min(40, Math.round((modules - 21) / 4) + 1));
    const densityPercent = Math.min(100, Math.round((modules / 177) * 100));
    const isTooDenseForCamera = version > 25;

    return {
      dataUrl,
      svgString,
      version,
      modules,
      densityPercent,
      isTooDenseForCamera,
    };
  } catch (error) {
    console.error('Error rendering QR code:', error);
    // Fallback if token is exceedingly large for the requested ECC level:
    // Try with 'L' (Low 7% ECC) which has maximum capacity (up to 2,953 bytes)
    try {
      const dataUrl = await QRCode.toDataURL(token, {
        errorCorrectionLevel: 'L',
        margin: 2,
        scale: 4,
        color: { dark: '#000000', light: '#FFFFFF' },
      });
      const svgString = await QRCode.toString(token, {
        type: 'svg',
        errorCorrectionLevel: 'L',
        margin: 2,
        color: { dark: '#000000', light: '#FFFFFF' },
      });
      return {
        dataUrl,
        svgString,
        version: 40,
        modules: 177,
        densityPercent: 100,
        isTooDenseForCamera: true,
      };
    } catch {
      return {
        dataUrl: '',
        svgString: '',
        version: 40,
        modules: 177,
        densityPercent: 100,
        isTooDenseForCamera: true,
      };
    }
  }
}
