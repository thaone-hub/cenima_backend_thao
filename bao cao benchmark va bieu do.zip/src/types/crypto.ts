export type AlgorithmId = 'RS256' | 'ES256' | 'EdDSA' | 'ML-DSA-44';

export type QrEccLevel = 'L' | 'M' | 'Q' | 'H';

export interface CryptoAlgorithmInfo {
  id: AlgorithmId;
  name: string;
  fullName: string;
  family: string;
  standard: string;
  standardLabel: string;
  algorithmType: 'Truyền thống' | 'Hậu lượng tử';
  quantumResistant: boolean;
  securityBitsEquivalent: number;
  publicKeyBytes: number;
  privateKeyBytes: number;
  signatureBytes: number;
  description: string;
}

export interface DetailedCryptoMetrics {
  // Exact values as requested and verified in benchmark images
  signingUs: number;          // e.g. 832.39 µs (or 849.74 µs)
  verificationUs: number;     // e.g. 44.14 µs (or 45.06 µs / 286.49 µs)
  keyGenMs: number;           // e.g. 12.5 ms (or 12.76 ms)
  throughputOps: number;      // e.g. 1,201 ops/s
  signatureBytes: number;     // e.g. 256 bytes
  jwtChars: number;           // e.g. 716 chars
  qrDensityLabel: 'Thoáng' | 'Cực thoáng' | 'Rất thoáng' | 'Rất dày (High Density)';
  
  // CPU & RAM metrics requested
  cpuPercent: number;         // Average CPU load during signing %
  ramAllocatedKb: number;     // Heap memory allocated per 1000 ops (KB)
  gcPressure: 'Rất thấp' | 'Thấp' | 'Trung bình' | 'Cao';
}

export interface JwtTokenBreakdown {
  header: Record<string, unknown>;
  payload: Record<string, unknown>;
  encodedHeader: string;
  encodedPayload: string;
  encodedSignature: string;
  rawToken: string;
  headerBytes: number;
  payloadBytes: number;
  signatureBytes: number;
  totalTokenBytes: number;
}

export interface BenchmarkMetrics {
  iterations: number;
  warmupIterations: number;
  signTimeAvgMs: number;
  signTimeMinMs: number;
  signTimeMaxMs: number;
  signTimeP95Ms: number;
  signOpsPerSec: number;
  verifyTimeAvgMs: number;
  verifyTimeMinMs: number;
  verifyTimeMaxMs: number;
  verifyTimeP95Ms: number;
  verifyOpsPerSec: number;
  memoryEstimatedKb: number;
  cpuOverheadRating: 'Rất thấp' | 'Thấp' | 'Trung bình' | 'Cao';
}

export interface QrScanMetrics {
  qrVersion: number;
  modules: number;
  moduleDensity: number;
  eccLevel: QrEccLevel;
  totalCharacters: number;
  readabilityScore: number;
  estimatedScanTimeMs: number;
  recommendedMinPrintSizeCm: number;
  optimalScanDistanceCm: string;
  mobileCameraCompatibility: 'Hoàn hảo' | 'Tốt' | 'Khá' | 'Rất khó / Cần ống kính chuyên dụng';
  feasibilityNotes: string;
}

export interface AlgorithmComparisonData {
  info: CryptoAlgorithmInfo;
  metrics: DetailedCryptoMetrics;
  jwt: JwtTokenBreakdown;
  benchmark: BenchmarkMetrics;
  qr: QrScanMetrics;
  pros: string[];
  cons: string[];
  recommendationRating: number;
  recommendedUseCases: string[];
}

export type PayloadSizePreset = 'compact' | 'standard' | 'enterprise';

export interface BenchmarkConfig {
  iterations: number;
  warmupIterations: number;
  payloadPreset: PayloadSizePreset;
  eccLevel: QrEccLevel;
}

export type VisualizationTab =
  | 'signing'
  | 'verification'
  | 'throughput'
  | 'signatureSize'
  | 'keyGen'
  | 'jwtSize'
  | 'cpuRam';
