import React, { useState } from 'react';
import { Header } from './components/Header';
import { OverviewCards } from './components/OverviewCards';
import { Task4Visualization } from './components/Task4Visualization';
import { TestEnvironment } from './components/TestEnvironment';
import { DetailedTable } from './components/DetailedTable';
import { JavaCodeViewer } from './components/JavaCodeViewer';
import { QrDensityViewer } from './components/QrDensityViewer';
import { LiveSimulator } from './components/LiveSimulator';
import { BarChart3, Cpu, Terminal, QrCode, Play, Layers } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');

  return (
    <div className="min-h-screen bg-[#050505] text-zinc-100 selection:bg-white selection:text-black">
      {/* Sticky Monochrome Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenSimulator={() => setActiveTab('simulator')}
      />

      {/* Main Container */}
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
        {/* Editorial Subheader */}
        <section className="border-b border-zinc-800/80 pb-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-5">
            <div>
              <div className="flex items-center gap-2 text-xs text-zinc-400 mb-1.5 font-medium">
                <span>NIST FIPS 204</span>
                <span aria-hidden="true">·</span>
                <span>RFC 7518</span>
                <span aria-hidden="true">·</span>
                <span>RFC 8037</span>
                <span aria-hidden="true">·</span>
                <span>JMH Microbenchmark Suite</span>
              </div>
              <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl lg:text-4xl">
                Khảo sát &amp; Đo đạc Hiệu năng Chữ ký số JWT
              </h1>
              <p className="mt-2 text-sm text-zinc-400 max-w-3xl leading-relaxed">
                Đánh giá toàn diện 4 thuật toán: <strong className="text-white">RS256</strong> (RSA-2048), <strong className="text-white">ES256</strong> (NIST P-256), <strong className="text-white">EdDSA</strong> (Ed25519) và <strong className="text-white">ML-DSA-44</strong> (Chuẩn Hậu lượng tử NIST FIPS 204 / Dilithium2).
              </p>
            </div>

            {/* Metric pill bar for quick tab switching - Soft rounded full pills */}
            <div className="flex items-center gap-1.5 p-1.5 rounded-full border border-zinc-800/90 bg-zinc-950 overflow-x-auto text-xs shrink-0 shadow-sm">
              <button
                onClick={() => setActiveTab('overview')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-full transition cursor-pointer whitespace-nowrap font-medium ${
                  activeTab === 'overview'
                    ? 'bg-white text-black font-bold shadow-sm'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                }`}
              >
                <Layers className="h-3.5 w-3.5" />
                <span>Tổng quan Thẻ</span>
              </button>
              <button
                onClick={() => setActiveTab('visualization')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-full transition cursor-pointer whitespace-nowrap font-medium ${
                  activeTab === 'visualization'
                    ? 'bg-white text-black font-bold shadow-sm'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                }`}
              >
                <BarChart3 className="h-3.5 w-3.5" />
                <span>Biểu đồ Task 4</span>
              </button>
              <button
                onClick={() => setActiveTab('environment')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-full transition cursor-pointer whitespace-nowrap font-medium ${
                  activeTab === 'environment'
                    ? 'bg-white text-black font-bold shadow-sm'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                }`}
              >
                <Cpu className="h-3.5 w-3.5" />
                <span>Môi trường Đo</span>
              </button>
              <button
                onClick={() => setActiveTab('javacode')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-full transition cursor-pointer whitespace-nowrap font-medium ${
                  activeTab === 'javacode'
                    ? 'bg-white text-black font-bold shadow-sm'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                }`}
              >
                <Terminal className="h-3.5 w-3.5" />
                <span>Mã nguồn Java</span>
              </button>
              <button
                onClick={() => setActiveTab('qrsim')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-full transition cursor-pointer whitespace-nowrap font-medium ${
                  activeTab === 'qrsim'
                    ? 'bg-white text-black font-bold shadow-sm'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                }`}
              >
                <QrCode className="h-3.5 w-3.5" />
                <span>Mật độ QR</span>
              </button>
              <button
                onClick={() => setActiveTab('simulator')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-full transition cursor-pointer whitespace-nowrap font-medium ${
                  activeTab === 'simulator'
                    ? 'bg-white text-black font-bold shadow-sm'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                }`}
              >
                <Play className="h-3.5 w-3.5" />
                <span>Mô phỏng Chạy</span>
              </button>
            </div>
          </div>
        </section>

        {/* Tab Content Display */}
        <div className="space-y-8">
          {activeTab === 'overview' && (
            <div className="space-y-8">
              <OverviewCards
                onViewTask4Visualization={() => setActiveTab('visualization')}
              />
              <div className="pt-2">
                <Task4Visualization />
              </div>
            </div>
          )}

          {activeTab === 'visualization' && (
            <div className="space-y-6">
              <Task4Visualization />
            </div>
          )}

          {activeTab === 'environment' && (
            <div className="space-y-6">
              <TestEnvironment />
            </div>
          )}

          {activeTab === 'analysis' && (
            <div className="space-y-6">
              <DetailedTable />
            </div>
          )}

          {activeTab === 'javacode' && (
            <div className="space-y-6">
              <JavaCodeViewer />
            </div>
          )}

          {activeTab === 'qrsim' && (
            <div className="space-y-6">
              <QrDensityViewer />
            </div>
          )}

          {activeTab === 'simulator' && (
            <div className="space-y-6">
              <LiveSimulator />
            </div>
          )}
        </div>
      </main>

      {/* Monochrome Footer */}
      <footer className="mt-16 border-t border-zinc-800/80 bg-black py-8 text-xs text-zinc-500">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <span>JWT Cryptographic Benchmark Suite</span>
            <span className="mx-2">·</span>
            <span>Tone màu Monochrome Đen &amp; Trắng</span>
          </div>
          <div className="text-zinc-400">
            Adoptium OpenJDK 21 LTS · JMH 1.37 · Bouncy Castle PQC 1.78.1 (NIST FIPS 204)
          </div>
        </div>
      </footer>
    </div>
  );
}
