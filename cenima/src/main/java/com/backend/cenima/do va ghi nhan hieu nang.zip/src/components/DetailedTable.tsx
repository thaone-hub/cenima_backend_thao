import React, { useState } from 'react';
import { ALGORITHMS } from '../data/benchmarkData';
import { ArrowUpDown, Shield, QrCode } from 'lucide-react';

export const DetailedTable: React.FC = () => {
  const [sortField, setSortField] = useState<string>('throughputOps');
  const [sortAsc, setSortAsc] = useState<boolean>(false);

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  const sortedAlgorithms = [...ALGORITHMS].sort((a, b) => {
    let aVal: any = (a as any)[sortField];
    let bVal: any = (b as any)[sortField];
    if (typeof aVal === 'string') {
      return sortAsc ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
    }
    return sortAsc ? aVal - bVal : bVal - aVal;
  });

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="border-b border-zinc-800/80 pb-4">
        <h2 className="text-xl font-bold tracking-tight text-white sm:text-2xl">
          Bảng Dữ liệu Đầy đủ &amp; Phân tích Kỹ thuật
        </h2>
        <p className="mt-1 text-sm text-zinc-400">
          Tổng hợp tất cả các chỉ số hiệu năng (Latency, Throughput, Memory, JWT Size, QR) thu thập được từ JMH
        </p>
      </div>

      {/* Full Metric Table - Soft rounded-3xl container */}
      <div className="rounded-3xl border border-zinc-800/80 bg-zinc-950 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-zinc-800 bg-black text-zinc-400 uppercase tracking-wider font-semibold">
              <tr>
                <th className="py-3.5 px-5">Thuật toán</th>
                <th className="py-3.5 px-3">Loại / Kháng Lượng tử</th>
                <th className="py-3.5 px-3 cursor-pointer hover:text-white" onClick={() => handleSort('signingTimeUs')}>
                  <div className="flex items-center gap-1">
                    <span>Ký (µs)</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </th>
                <th className="py-3.5 px-3 cursor-pointer hover:text-white" onClick={() => handleSort('verificationTimeUs')}>
                  <div className="flex items-center gap-1">
                    <span>Xác thực (µs)</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </th>
                <th className="py-3.5 px-3 cursor-pointer hover:text-white" onClick={() => handleSort('throughputOps')}>
                  <div className="flex items-center gap-1">
                    <span>Throughput (ops/s)</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </th>
                <th className="py-3.5 px-3 cursor-pointer hover:text-white" onClick={() => handleSort('keyGenTimeMs')}>
                  <div className="flex items-center gap-1">
                    <span>KeyGen (ms)</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </th>
                <th className="py-3.5 px-3 cursor-pointer hover:text-white" onClick={() => handleSort('signatureSizeBytes')}>
                  <div className="flex items-center gap-1">
                    <span>Chữ ký (Bytes)</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </th>
                <th className="py-3.5 px-3 cursor-pointer hover:text-white" onClick={() => handleSort('totalJwtChars')}>
                  <div className="flex items-center gap-1">
                    <span>JWT (chars)</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </th>
                <th className="py-3.5 px-3">RAM/Op (KB)</th>
                <th className="py-3.5 px-5">Mật độ quét QR</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-900 text-zinc-300">
              {sortedAlgorithms.map((alg) => {
                const isPQC = alg.category === 'Hậu lượng tử';
                return (
                  <tr key={alg.id} className="hover:bg-zinc-900/60 transition-colors">
                    <td className="py-4 px-5">
                      <div className="font-bold text-white text-sm">{alg.name}</div>
                      <div className="text-[11px] text-zinc-400 mt-0.5">{alg.standard}</div>
                    </td>
                    <td className="py-4 px-3">
                      <span className={`inline-block px-3 py-1 rounded-full text-[10px] font-bold uppercase ${
                        isPQC ? 'border border-white bg-white text-black shadow-xs' : 'border border-zinc-700 bg-zinc-900 text-zinc-400'
                      }`}>
                        {isPQC ? 'Kháng Quantum' : 'Cổ điển'}
                      </span>
                    </td>
                    <td className="py-4 px-3 tabular-nums font-bold text-white">
                      {alg.signingTimeUs.toFixed(2)}
                    </td>
                    <td className="py-4 px-3 tabular-nums text-zinc-200">
                      {alg.verificationTimeUs.toFixed(2)}
                    </td>
                    <td className="py-4 px-3 tabular-nums font-bold text-white">
                      {alg.throughputOps.toLocaleString()}
                    </td>
                    <td className="py-4 px-3 tabular-nums text-zinc-400">
                      {alg.keyGenTimeMs.toFixed(3)}
                    </td>
                    <td className="py-4 px-3 tabular-nums font-bold text-zinc-200">
                      {alg.signatureSizeBytes.toLocaleString()}
                    </td>
                    <td className="py-4 px-3 tabular-nums text-zinc-300">
                      ~{alg.totalJwtChars.toLocaleString()}
                    </td>
                    <td className="py-4 px-3 tabular-nums text-zinc-400">
                      {alg.ramAllocPerSignKb.toFixed(2)}
                    </td>
                    <td className="py-4 px-5 font-semibold text-zinc-200">
                      {alg.qrDensity}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Deep Cryptographic Architectural Insights - Soft rounded-3xl cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card 1: PQC Trade-off Analysis */}
        <div className="rounded-3xl border border-zinc-800/80 bg-zinc-950 p-6 space-y-3.5 shadow-lg">
          <div className="flex items-center gap-2.5 text-white">
            <Shield className="h-5 w-5 text-zinc-300" />
            <h3 className="font-bold text-sm">Đánh đổi Hiệu năng khi chuyển sang ML-DSA-44 (FIPS 204)</h3>
          </div>
          <p className="text-xs text-zinc-400 leading-relaxed">
            ML-DSA-44 (dựa trên thuật toán Dilithium2) cho thấy tốc độ ký <strong className="text-white">144.42 µs</strong> và xác thực <strong className="text-white">120.44 µs</strong> rất cân bằng, nhanh hơn phép ký của RS256 tới gần 6 lần. Điều này chứng minh rằng việc áp dụng mật mã hậu lượng tử <strong className="text-white">không làm sụt giảm nghiêm trọng độ trễ tính toán</strong> trên CPU máy chủ.
          </p>
          <div className="rounded-2xl border border-zinc-800/80 bg-black/70 p-4 text-xs text-zinc-300 space-y-1.5 shadow-inner">
            <div className="text-zinc-500 font-semibold mb-1">// Trade-off chính nằm ở dung lượng dữ liệu:</div>
            <div>• Kích thước chữ ký: <span className="text-white font-bold">2,420 bytes</span> (so với 64B của EdDSA/ES256)</div>
            <div>• Khóa công khai đính kèm: <span className="text-white font-bold">1,312 bytes</span></div>
            <div>• Cấp phát bộ nhớ: <span className="text-white font-bold">46.20 KB/op</span> do lưu các ma trận đa thức M-LWE</div>
          </div>
        </div>

        {/* Card 2: HTTP Headers & QR Code Constraints */}
        <div className="rounded-3xl border border-zinc-800/80 bg-zinc-950 p-6 space-y-3.5 shadow-lg">
          <div className="flex items-center gap-2.5 text-white">
            <QrCode className="h-5 w-5 text-zinc-300" />
            <h3 className="font-bold text-sm">Ảnh hưởng tới Giao thức HTTP và Mã QR Offline</h3>
          </div>
          <p className="text-xs text-zinc-400 leading-relaxed">
            Chuỗi JWT của ML-DSA-44 dài xấp xỉ <strong className="text-white">3,807 ký tự</strong>. Khi truyền qua HTTP Header <code className="text-white">Authorization: Bearer &lt;token&gt;</code>, token này chiếm gần một nửa hạn ngạch header mặc định của một số Reverse Proxy (Nginx mặc định giới hạn 4KB–8KB cho <code className="text-white">large_client_header_buffers</code>).
          </p>
          <div className="rounded-2xl border border-zinc-800/80 bg-black/70 p-4 text-xs text-zinc-300 space-y-1.5 shadow-inner">
            <div className="text-zinc-500 font-semibold mb-1">// Khả năng ứng dụng Mã QR (Mobile Scanner):</div>
            <div>• ES256 / EdDSA (694 chars): QR Version 5 (37x37 modules), quét cực nhanh dưới 100ms.</div>
            <div>• ML-DSA-44 (3,807 chars): Đòi hỏi QR Version 14+ (73x73 modules) mật độ rất dày, yêu cầu camera độ nét cao và căn chỉnh thẳng góc.</div>
          </div>
        </div>
      </div>
    </div>
  );
};
