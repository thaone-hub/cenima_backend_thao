import React from 'react';
import { Play } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenSimulator: () => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, onOpenSimulator }) => {
  const navItems = [
    { id: 'overview', label: 'Tổng quan Thẻ' },
    { id: 'visualization', label: 'Biểu đồ Task 4' },
    { id: 'environment', label: 'Môi trường & Đo' },
    { id: 'analysis', label: 'Bảng phân tích' },
    { id: 'javacode', label: 'Mã nguồn Java' },
    { id: 'qrsim', label: 'Mật độ QR Code' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-zinc-800/80 bg-black/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-8 px-4 py-3 sm:px-6">
        {/* Zone 1: Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex h-9 w-9 items-center justify-center rounded-2xl border border-white bg-white text-black font-bold text-xs shadow-sm">
            JWT
          </div>
          <button 
            onClick={() => setActiveTab('overview')}
            className="text-left cursor-pointer"
          >
            <span className="text-base font-bold tracking-tight text-white whitespace-nowrap block">
              JWT Crypto Benchmark
            </span>
          </button>
        </div>

        {/* Zone 2: Navigation Links - Rounded full pills */}
        <nav className="hidden lg:flex items-center gap-1.5 p-1 rounded-full border border-zinc-800 bg-zinc-950/80">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-4 py-1.5 text-xs font-medium rounded-full transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-white text-black font-bold shadow'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 Primary Action - Soft rounded full button */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onOpenSimulator}
            className="flex items-center gap-2 rounded-full border border-white bg-white px-4 py-1.5 text-xs font-bold text-black transition-all hover:bg-zinc-200 shadow-sm whitespace-nowrap cursor-pointer"
          >
            <Play className="h-3.5 w-3.5 fill-black" />
            <span>Chạy Thử nghiệm</span>
          </button>
        </div>
      </div>

      {/* Mobile navigation row */}
      <div className="flex lg:hidden overflow-x-auto border-t border-zinc-800/80 px-4 py-2 gap-1.5 text-xs">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`px-3 py-1 rounded-full text-xs whitespace-nowrap shrink-0 transition-colors ${
              activeTab === item.id
                ? 'bg-white text-black font-bold shadow'
                : 'text-zinc-400 hover:text-white bg-zinc-950 border border-zinc-800'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>
    </header>
  );
};
