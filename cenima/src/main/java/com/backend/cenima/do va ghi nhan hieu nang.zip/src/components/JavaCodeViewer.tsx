import React, { useState } from 'react';
import { JAVA_SNIPPETS } from '../data/javaCodeSnippets';
import { Copy, Check, Download, Terminal, Code2 } from 'lucide-react';

export const JavaCodeViewer: React.FC = () => {
  const [selectedSnippetId, setSelectedSnippetId] = useState<string>('benchmark');
  const [copied, setCopied] = useState<boolean>(false);

  const currentSnippet = JAVA_SNIPPETS.find((s) => s.id === selectedSnippetId) || JAVA_SNIPPETS[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(currentSnippet.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([currentSnippet.code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = currentSnippet.filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  const lines = currentSnippet.code.split('\n');

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="border-b border-zinc-800/80 pb-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white sm:text-2xl">
            Mã Nguồn Java &amp; Bộ công cụ JMH Benchmark
          </h2>
          <p className="mt-1 text-sm text-zinc-400">
            Mã nguồn hoàn chỉnh sẵn sàng chạy thử trên Java 21, tích hợp Bouncy Castle FIPS 204 và Nimbus JOSE
          </p>
        </div>

        {/* Action buttons - Soft rounded-full buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 rounded-full border border-zinc-700 bg-zinc-900 px-4 py-2 text-xs font-semibold text-white transition hover:bg-zinc-800 cursor-pointer shadow-sm"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-white" /> : <Copy className="h-3.5 w-3.5" />}
            <span>{copied ? 'Đã sao chép' : 'Sao chép mã'}</span>
          </button>
          <button
            onClick={handleDownload}
            className="flex items-center gap-1.5 rounded-full border border-zinc-700 bg-zinc-900 px-4 py-2 text-xs font-semibold text-white transition hover:bg-zinc-800 cursor-pointer shadow-sm"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Tải file</span>
          </button>
        </div>
      </div>

      {/* File Selector Tabs - Soft rounded-full container and buttons */}
      <div className="flex flex-wrap items-center gap-2 border-b border-zinc-800/80 pb-3">
        {JAVA_SNIPPETS.map((snippet) => {
          const isActive = snippet.id === selectedSnippetId;
          return (
            <button
              key={snippet.id}
              onClick={() => setSelectedSnippetId(snippet.id)}
              className={`flex items-center gap-2 rounded-full px-4 py-2 text-xs transition-all cursor-pointer font-medium ${
                isActive
                  ? 'border border-white bg-white text-black font-bold shadow-md'
                  : 'border border-zinc-800 bg-zinc-950 text-zinc-400 hover:bg-zinc-900 hover:text-white'
              }`}
            >
              <Code2 className="h-3.5 w-3.5" />
              <span>{snippet.filename}</span>
            </button>
          );
        })}
      </div>

      {/* Snippet Description - Soft rounded-2xl */}
      <div className="rounded-2xl border border-zinc-800/80 bg-zinc-950 px-5 py-3.5 text-xs text-zinc-300 shadow-sm leading-relaxed">
        <span className="font-bold text-white">{currentSnippet.title}: </span>
        {currentSnippet.description}
      </div>

      {/* Code Box with Line Numbers - Soft rounded-3xl container */}
      <div className="rounded-3xl border border-zinc-800/80 bg-black overflow-hidden text-xs shadow-2xl">
        <div className="flex items-center justify-between border-b border-zinc-800/80 bg-zinc-950 px-5 py-3 text-zinc-400">
          <span className="text-xs font-semibold text-zinc-300">{currentSnippet.filename} ({lines.length} dòng)</span>
          <span className="text-[11px] uppercase text-zinc-500 font-bold">{currentSnippet.language}</span>
        </div>

        <div className="max-h-[560px] overflow-auto p-5 leading-relaxed text-zinc-200">
          <pre className="flex">
            {/* Line numbers */}
            <div className="select-none pr-5 text-right text-zinc-600 text-xs border-r border-zinc-900 shrink-0">
              {lines.map((_, i) => (
                <div key={i}>{i + 1}</div>
              ))}
            </div>
            {/* Code content */}
            <code className="pl-5 text-xs text-zinc-200 block overflow-x-auto whitespace-pre">
              {currentSnippet.code}
            </code>
          </pre>
        </div>
      </div>

      {/* Terminal Compilation Instructions - Soft rounded-3xl */}
      <div className="rounded-3xl border border-zinc-800/80 bg-zinc-950 p-6 space-y-3.5 text-xs shadow-xl">
        <div className="flex items-center gap-2.5 text-white font-bold text-sm">
          <Terminal className="h-4.5 w-4.5 text-zinc-300" />
          <span>Hướng dẫn Biên dịch &amp; Chạy thử nghiệm trên Terminal</span>
        </div>
        <div className="space-y-2.5 text-zinc-300">
          <div className="rounded-2xl bg-black p-4 border border-zinc-800 text-zinc-200 space-y-2 shadow-inner">
            <p className="text-zinc-500 font-semibold"># 1. Đóng gói mã nguồn và tạo file jar JMH tự chứa (Uber-jar)</p>
            <p className="text-white font-bold">$ mvn clean package</p>
            <p className="text-zinc-500 font-semibold pt-2"># 2. Khởi chạy thử nghiệm đo đạc Signing, Verification Time &amp; GC Profile</p>
            <p className="text-white font-bold">$ java -jar target/benchmarks.jar JwtCryptoBenchmark -prof gc -f 2 -wi 5 -i 10</p>
            <p className="text-zinc-500 font-semibold pt-2"># 3. Xuất kết quả sang định dạng JSON để vẽ biểu đồ</p>
            <p className="text-white font-bold">$ java -jar target/benchmarks.jar JwtCryptoBenchmark -rf json -rff benchmark-result.json</p>
          </div>
          <p className="text-[11px] text-zinc-500">
            * Yêu cầu: Đã cài đặt JDK 21 trở lên (Eclipse Adoptium Temurin hoặc OpenJDK 21) và Apache Maven 3.9+.
          </p>
        </div>
      </div>
    </div>
  );
};
