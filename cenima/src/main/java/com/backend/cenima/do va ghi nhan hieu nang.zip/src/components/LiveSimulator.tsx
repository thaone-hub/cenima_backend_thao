import React, { useState, useEffect, useRef } from 'react';
import { ALGORITHMS } from '../data/benchmarkData';
import { Play, RotateCcw, Terminal, CheckCircle2 } from 'lucide-react';

interface SimulatedResult {
  algId: string;
  name: string;
  signingUs: number;
  verifyUs: number;
  throughputOps: number;
  completedOps: number;
}

export const LiveSimulator: React.FC = () => {
  const [iterations, setIterations] = useState<number>(500);
  const [threads, setThreads] = useState<number>(4);
  const [mode, setMode] = useState<'both' | 'signing' | 'verify'>('both');
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [results, setResults] = useState<SimulatedResult[] | null>(null);

  const logsEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const runBenchmark = () => {
    if (isRunning) return;
    setIsRunning(true);
    setProgress(0);
    setResults(null);
    setLogs([
      `# JMH version: 1.37`,
      `# VM version: JDK 21.0.3, OpenJDK 64-Bit Server VM`,
      `# VM invoker: /usr/lib/jvm/java-21-openjdk/bin/java`,
      `# Benchmark: com.crypto.benchmark.JwtCryptoBenchmark`,
      `# Parameters: ${threads} threads, ${iterations} iterations per warm/meas cycle`,
      `# Warmup: 3 iterations, 500 ms each`,
      `# Measurement: 5 iterations, 1000 ms each`,
      `# Threads: ${threads} thread${threads > 1 ? 's' : ''}, will synchronize iterations`,
      `# Benchmark mode: Average time, Throughput`,
      `# Output time_unit: µs/op`,
      `----------------------------------------------------------------------`
    ]);

    const algList = ['rs256', 'es256', 'eddsa', 'mldsa44'];
    let step = 0;
    const totalSteps = algList.length * 4;

    const timer = setInterval(() => {
      step++;
      const currentAlgId = algList[Math.min(Math.floor(step / 4), algList.length - 1)];
      const currentAlg = ALGORITHMS.find((a) => a.id === currentAlgId)!;
      const subStep = step % 4;

      if (subStep === 1) {
        setLogs((prev) => [
          ...prev,
          `\n# Run progress: ${Math.round((step / totalSteps) * 100)}% | Benchmarking ${currentAlg.name}...`,
          `# Fork: 1 of 1, Warmup Iteration 1: JIT C2 compiler optimizing ${currentAlg.name} bytecode...`
        ]);
      } else if (subStep === 2) {
        setLogs((prev) => [
          ...prev,
          `# Warmup complete. Measurement Iteration 1 (${iterations} ops): GC churn: ~${currentAlg.ramAllocPerSignKb} KB/op`
        ]);
      } else if (subStep === 3) {
        setLogs((prev) => [
          ...prev,
          `# Iteration 2: Executing concurrent signing/verify with ${threads} thread(s)...`
        ]);
      }

      setProgress(Math.min(100, Math.round((step / totalSteps) * 100)));

      if (step >= totalSteps) {
        clearInterval(timer);
        setIsRunning(false);
        setProgress(100);

        const threadFactor = Math.sqrt(threads);
        const finalResults: SimulatedResult[] = ALGORITHMS.map((alg) => {
          const signVariance = (Math.random() * 0.04 - 0.02) * alg.signingTimeUs;
          const verifyVariance = (Math.random() * 0.04 - 0.02) * alg.verificationTimeUs;
          const baseThroughput = alg.throughputOps * threadFactor * (0.92 + Math.random() * 0.1);

          return {
            algId: alg.id,
            name: alg.name,
            signingUs: Number((alg.signingTimeUs + signVariance).toFixed(2)),
            verifyUs: Number((alg.verificationTimeUs + verifyVariance).toFixed(2)),
            throughputOps: Math.round(baseThroughput),
            completedOps: iterations * threads
          };
        });

        setResults(finalResults);
        setLogs((prev) => [
          ...prev,
          `\n----------------------------------------------------------------------`,
          `# Benchmark run completed successfully across all 4 algorithms!`,
          `# System status: GC Pauses 0.0ms, Alloc Rate: Stable`,
          `# Kết quả đã được tổng hợp chi tiết bên dưới.`
        ]);
      }
    }, 450);
  };

  const resetBenchmark = () => {
    setIsRunning(false);
    setProgress(0);
    setResults(null);
    setLogs([]);
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="border-b border-zinc-800/80 pb-4">
        <h2 className="text-xl font-bold tracking-tight text-white sm:text-2xl">
          Trình Mô phỏng Thực nghiệm JMH Trực tiếp (Live Benchmark Simulator)
        </h2>
        <p className="mt-1 text-sm text-zinc-400">
          Chạy mô phỏng vòng lặp đo lường hiệu năng 4 thuật toán với tham số số luồng (Threads) và chu kỳ lặp tùy chỉnh
        </p>
      </div>

      {/* Control panel - Soft rounded-3xl container */}
      <div className="rounded-3xl border border-zinc-800/80 bg-zinc-950 p-6 space-y-5 shadow-xl">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 text-xs">
          {/* Threads selector - Soft rounded-full buttons */}
          <div className="space-y-2">
            <label className="text-zinc-400 block font-semibold">Số luồng thực thi (Threads):</label>
            <div className="grid grid-cols-4 gap-1.5 p-1 rounded-full border border-zinc-800 bg-black">
              {[1, 4, 8, 16].map((th) => (
                <button
                  key={th}
                  disabled={isRunning}
                  onClick={() => setThreads(th)}
                  className={`py-1.5 text-center rounded-full transition-all cursor-pointer font-bold ${
                    threads === th
                      ? 'bg-white text-black shadow-sm'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {th}T
                </button>
              ))}
            </div>
          </div>

          {/* Iterations selector - Soft rounded-full buttons */}
          <div className="space-y-2">
            <label className="text-zinc-400 block font-semibold">Số phép thử (Iterations):</label>
            <div className="grid grid-cols-4 gap-1.5 p-1 rounded-full border border-zinc-800 bg-black">
              {[100, 500, 1000, 2000].map((it) => (
                <button
                  key={it}
                  disabled={isRunning}
                  onClick={() => setIterations(it)}
                  className={`py-1.5 text-center rounded-full transition-all cursor-pointer font-bold ${
                    iterations === it
                      ? 'bg-white text-black shadow-sm'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {it}
                </button>
              ))}
            </div>
          </div>

          {/* Measurement Mode - Soft rounded-full buttons */}
          <div className="space-y-2">
            <label className="text-zinc-400 block font-semibold">Chế độ kiểm thử:</label>
            <div className="grid grid-cols-3 gap-1.5 p-1 rounded-full border border-zinc-800 bg-black">
              {[
                { id: 'both', label: 'Cả hai' },
                { id: 'signing', label: 'Chỉ Ký' },
                { id: 'verify', label: 'Chỉ Xác minh' },
              ].map((m) => (
                <button
                  key={m.id}
                  disabled={isRunning}
                  onClick={() => setMode(m.id as any)}
                  className={`py-1.5 text-center rounded-full transition-all cursor-pointer font-bold text-xs ${
                    mode === m.id
                      ? 'bg-white text-black shadow-sm'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Action Button & Progress */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-3.5 border-t border-zinc-900/80">
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={runBenchmark}
              disabled={isRunning}
              className={`flex items-center justify-center gap-2 rounded-full px-6 py-2.5 text-xs font-bold transition-all w-full sm:w-auto cursor-pointer shadow-md ${
                isRunning
                  ? 'border border-zinc-700 bg-zinc-800 text-zinc-500 cursor-not-allowed'
                  : 'border border-white bg-white text-black hover:bg-zinc-200'
              }`}
            >
              <Play className="h-3.5 w-3.5 fill-current" />
              <span>{isRunning ? `Đang đo... (${progress}%)` : 'Bắt đầu Đo lường'}</span>
            </button>
            <button
              onClick={resetBenchmark}
              disabled={isRunning || (!results && logs.length === 0)}
              className="flex items-center justify-center gap-1.5 rounded-full border border-zinc-800 bg-black px-4 py-2.5 text-xs font-semibold text-zinc-400 hover:text-white disabled:opacity-40 cursor-pointer"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Đặt lại</span>
            </button>
          </div>

          {/* Progress bar - ALL WHITE FILL AS REQUESTED */}
          <div className="w-full sm:w-64 space-y-1.5">
            <div className="flex justify-between text-xs text-zinc-400 font-semibold">
              <span>Tiến độ thực nghiệm</span>
              <span className="text-white font-bold">{progress}%</span>
            </div>
            <div className="h-3 w-full rounded-full bg-zinc-950 border border-zinc-800/80 overflow-hidden shadow-inner">
              <div
                className="h-full bg-white rounded-full transition-all duration-300 ease-out shadow-[0_0_8px_rgba(255,255,255,0.3)]"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Terminal Output logs - Soft rounded-3xl container */}
      <div className="rounded-3xl border border-zinc-800/80 bg-black overflow-hidden text-xs shadow-2xl">
        <div className="flex items-center justify-between border-b border-zinc-800/80 bg-zinc-950 px-5 py-3 text-zinc-400">
          <div className="flex items-center gap-2.5">
            <Terminal className="h-4 w-4 text-zinc-300" />
            <span className="font-semibold text-zinc-300">JMH Output Console (STDOUT / JIT / GC logs)</span>
          </div>
          <span className="text-[11px] text-zinc-500 font-semibold">OpenJDK 21 mixed mode</span>
        </div>
        <div className="h-48 overflow-y-auto p-5 text-xs text-zinc-300 leading-relaxed bg-[#050505]">
          {logs.length === 0 ? (
            <div className="text-zinc-500 italic">
              Bấm "Bắt đầu Đo lường" ở trên để khởi chạy chu trình đo lường mô phỏng...
            </div>
          ) : (
            logs.map((log, i) => (
              <div key={i} className="whitespace-pre-wrap">
                {log}
              </div>
            ))
          )}
          <div ref={logsEndRef} />
        </div>
      </div>

      {/* Results Cards if finished - Soft rounded-2xl cards */}
      {results && (
        <div className="rounded-3xl border border-zinc-800/80 bg-zinc-950 p-6 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-zinc-900/80 pb-3">
            <div className="flex items-center gap-2 text-white font-bold text-sm">
              <CheckCircle2 className="h-4.5 w-4.5 text-white" />
              <span>Kết quả Tổng hợp từ đợt chạy ({threads} Threads, {iterations} Iterations)</span>
            </div>
            <span className="text-xs text-zinc-400 font-medium">
              Đo tại: {new Date().toLocaleTimeString()}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {results.map((res) => (
              <div key={res.algId} className="rounded-2xl border border-zinc-800/80 bg-black p-4 space-y-2.5 text-xs shadow-sm">
                <div className="flex items-center justify-between border-b border-zinc-900 pb-2">
                  <span className="font-bold text-white text-sm">{res.name}</span>
                  <span className="text-[11px] text-zinc-500">{res.completedOps} ops</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Ký (Sign):</span>
                  <span className="text-white font-bold">{res.signingUs} µs</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Xác thực:</span>
                  <span className="text-zinc-200 font-medium">{res.verifyUs} µs</span>
                </div>
                <div className="flex justify-between pt-1.5 border-t border-zinc-900">
                  <span className="text-zinc-400">Throughput:</span>
                  <span className="text-white font-bold">{res.throughputOps.toLocaleString()} ops/s</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
