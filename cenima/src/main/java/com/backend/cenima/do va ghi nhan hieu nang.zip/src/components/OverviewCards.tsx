import React from 'react';
import { ALGORITHMS } from '../data/benchmarkData';
import { ArrowUpRight, CheckCircle2 } from 'lucide-react';

interface OverviewCardsProps {
  onSelectAlgorithm?: (id: string) => void;
  onViewTask4Visualization?: () => void;
}

export const OverviewCards: React.FC<OverviewCardsProps> = ({ 
  onSelectAlgorithm, 
  onViewTask4Visualization 
}) => {
  return (
    <div className="space-y-6">
      {/* Header text */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-zinc-800 pb-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white sm:text-2xl">
            Tổng quan 4 Thuật toán Ký số JWT
          </h2>
          <p className="mt-1 text-sm text-zinc-400">
            So sánh thực nghiệm giữa 3 thuật toán mật mã cổ điển và thuật toán Hậu lượng tử NIST FIPS 204 (ML-DSA-44)
          </p>
        </div>
        {onViewTask4Visualization && (
          <button
            onClick={onViewTask4Visualization}
            className="self-start sm:self-auto flex items-center gap-1.5 rounded-full border border-zinc-700 bg-zinc-900 px-4 py-2 text-xs font-semibold text-white transition hover:bg-zinc-800 hover:border-zinc-500 cursor-pointer shadow-sm"
          >
            <span>Xem Biểu đồ Task 4</span>
            <ArrowUpRight className="h-3.5 w-3.5" />
          </button>
        )}
      </div>

      {/* 4 Cards Grid - Soft rounded-3xl cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {ALGORITHMS.map((alg) => {
          const isPostQuantum = alg.category === 'Hậu lượng tử';

          return (
            <div
              key={alg.id}
              onClick={() => onSelectAlgorithm?.(alg.id)}
              className="group relative flex flex-col justify-between rounded-3xl border border-zinc-800/90 bg-zinc-950 p-6 transition-all duration-300 hover:border-zinc-500 hover:bg-zinc-900/60 shadow-lg hover:shadow-2xl"
            >
              <div>
                {/* Card Title & Category Badge */}
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="text-xl font-bold tracking-tight text-white">
                      {alg.name}
                    </h3>
                    <p className="mt-0.5 text-xs text-zinc-400">
                      {alg.standard}
                    </p>
                  </div>
                  <span
                    className={`shrink-0 rounded-full px-3 py-1 text-[11px] font-semibold border ${
                      isPostQuantum
                        ? 'border-white bg-white text-black shadow-sm'
                        : 'border-zinc-700 bg-zinc-900 text-zinc-300'
                    }`}
                  >
                    {alg.category}
                  </span>
                </div>

                {/* Metrics Table */}
                <div className="mt-6 space-y-3.5 text-xs">
                  {/* Thời gian Ký */}
                  <div className="flex items-center justify-between border-b border-zinc-900/80 pb-2.5">
                    <span className="text-zinc-400">Thời gian Ký (Signing):</span>
                    <span className="font-bold text-white tabular-nums text-sm">
                      {alg.id === 'rs256' ? '832.39 µs' :
                       alg.id === 'es256' ? '124.89 µs' :
                       alg.id === 'eddsa' ? '34.29 µs' : '139.12 µs'}
                    </span>
                  </div>

                  {/* Xác thực */}
                  <div className="flex items-center justify-between border-b border-zinc-900/80 pb-2.5">
                    <span className="text-zinc-400">Xác thực (Verification):</span>
                    <span className="font-semibold text-zinc-200 tabular-nums">
                      {alg.id === 'rs256' ? '44.14 µs' :
                       alg.id === 'es256' ? '286.4 µs' :
                       alg.id === 'eddsa' ? '85.62 µs' : '116.02 µs'}
                    </span>
                  </div>

                  {/* Tạo khóa */}
                  <div className="flex items-center justify-between border-b border-zinc-900/80 pb-2.5">
                    <span className="text-zinc-400">Tạo khóa (KeyGen):</span>
                    <span className="text-zinc-300 tabular-nums">
                      {alg.id === 'rs256' ? '12.5 ms' :
                       alg.id === 'es256' ? '0.16 ms' :
                       alg.id === 'eddsa' ? '0.045 ms' : '0.235 ms'}
                    </span>
                  </div>

                  {/* Throughput */}
                  <div className="flex items-center justify-between border-b border-zinc-900/80 pb-2.5">
                    <span className="text-zinc-400">Throughput (Tốc độ):</span>
                    <span className="font-bold text-white tabular-nums">
                      {alg.id === 'rs256' ? '1,201 ops/s' :
                       alg.id === 'es256' ? '8,007 ops/s' :
                       alg.id === 'eddsa' ? '29,163 ops/s' : '7,188 ops/s'}
                    </span>
                  </div>

                  {/* Kích thước chữ ký */}
                  <div className="flex items-center justify-between border-b border-zinc-900/80 pb-2.5">
                    <span className="text-zinc-400">Kích thước chữ ký:</span>
                    <span className="font-bold text-zinc-100 tabular-nums">
                      {alg.signatureSizeBytes.toLocaleString()} bytes
                    </span>
                  </div>

                  {/* Tổng kích thước JWT */}
                  <div className="flex items-center justify-between border-b border-zinc-900/80 pb-2.5">
                    <span className="text-zinc-400">Tổng kích thước JWT:</span>
                    <span className="text-zinc-300 tabular-nums">
                      ~{alg.totalJwtChars.toLocaleString()} chars
                    </span>
                  </div>

                  {/* Mức cấp phát RAM */}
                  <div className="flex items-center justify-between border-b border-zinc-900/80 pb-2.5">
                    <span className="text-zinc-400">Cấp phát RAM/Op:</span>
                    <span className="text-zinc-300 tabular-nums">
                      ~{alg.ramAllocPerSignKb} KB/op
                    </span>
                  </div>
                </div>
              </div>

              {/* QR Scan Density Footer */}
              <div className="mt-5 pt-3.5 border-t border-zinc-800/80 flex items-center justify-between text-xs">
                <span className="text-zinc-400">Mật độ quét QR:</span>
                <span className={`font-semibold rounded-full px-2.5 py-0.5 ${
                  alg.id === 'mldsa44' ? 'bg-zinc-800 text-white' : 'text-zinc-200'
                }`}>
                  {alg.qrDensity}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Summary Strip with soft rounded corners */}
      <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-4 text-xs text-zinc-400 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-md">
        <div className="flex items-center gap-2.5">
          <CheckCircle2 className="h-4 w-4 text-white shrink-0" />
          <span className="leading-relaxed">
            <strong className="text-white">Nhận định chính: </strong>
            <strong className="text-zinc-200">EdDSA</strong> có throughput và thời gian ký nhanh nhất. <strong className="text-zinc-200">RS256</strong> xác thực nhanh nhất nhưng kích thước chữ ký lớn và tạo khóa rất chậm. <strong className="text-zinc-200">ML-DSA-44</strong> mang lại khả năng kháng lượng tử cấp NIST 2 với thời gian tính toán ổn định (~144µs), tuy nhiên chữ ký 2,420 bytes đòi hỏi băng thông và mật độ QR cao hơn đáng kể.
          </span>
        </div>
      </div>
    </div>
  );
};
