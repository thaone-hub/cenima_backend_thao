import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { ALGORITHMS } from '../data/benchmarkData';
import { Copy, Check } from 'lucide-react';

export const QrDensityViewer: React.FC = () => {
  const [selectedAlgId, setSelectedAlgId] = useState<string>('mldsa44');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copiedToken, setCopiedToken] = useState<boolean>(false);

  // Generate realistic tokens for each algorithm
  const generateMockJwt = (algId: string) => {
    const header = btoa(JSON.stringify({ alg: algId.toUpperCase(), typ: 'JWT' })).replace(/=/g, '');
    const payload = btoa(JSON.stringify({
      sub: '1234567890',
      name: 'Nguyen Van A',
      iss: 'auth.domain.vn',
      aud: 'api.domain.vn',
      roles: ['ADMIN', 'CRYPTO_AUDITOR'],
      iat: 1729000000,
      exp: 1729086400
    })).replace(/=/g, '');

    // Signatures with appropriate length
    let sigLength = 64; // ES256 & EdDSA
    if (algId === 'rs256') sigLength = 256;
    if (algId === 'mldsa44') sigLength = 2420;

    // Simulated pseudo-random base64url signature string of exact length
    const b64chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
    let sig = '';
    const encodedLength = Math.ceil((sigLength * 4) / 3);
    for (let i = 0; i < encodedLength; i++) {
      sig += b64chars[(i * 17 + 23) % b64chars.length];
    }

    return `${header}.${payload}.${sig}`;
  };

  const selectedAlg = ALGORITHMS.find((a) => a.id === selectedAlgId) || ALGORITHMS[3];
  const token = generateMockJwt(selectedAlg.id);

  useEffect(() => {
    QRCode.toDataURL(token, {
      errorCorrectionLevel: 'M',
      margin: 2,
      scale: 6,
      color: {
        dark: '#ffffff',
        light: '#09090b',
      },
    })
      .then((url) => setQrDataUrl(url))
      .catch((err) => {
        console.error('QR Gen error:', err);
      });
  }, [selectedAlgId, token]);

  const handleCopy = () => {
    navigator.clipboard.writeText(token);
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="border-b border-zinc-800/80 pb-4">
        <h2 className="text-xl font-bold tracking-tight text-white sm:text-2xl">
          Mô phỏng Mật độ quét Mã QR (QR Density &amp; Token Size)
        </h2>
        <p className="mt-1 text-sm text-zinc-400">
          Trực quan hóa sự khác biệt giữa mã QR của JWT cổ điển (ES256/EdDSA/RS256) và JWT Hậu lượng tử ML-DSA-44 (~3,807 ký tự)
        </p>
      </div>

      {/* Algorithm selector pills - Soft rounded-full pills */}
      <div className="flex flex-wrap items-center gap-2">
        {ALGORITHMS.map((alg) => {
          const isActive = alg.id === selectedAlgId;
          return (
            <button
              key={alg.id}
              onClick={() => setSelectedAlgId(alg.id)}
              className={`px-5 py-2 text-xs rounded-full border transition-all cursor-pointer font-medium ${
                isActive
                  ? 'border-white bg-white text-black font-bold shadow-md'
                  : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:text-white hover:border-zinc-700 hover:bg-zinc-900'
              }`}
            >
              <div className="flex items-center gap-2">
                <span>{alg.name}</span>
                <span className="text-[11px] opacity-80">({alg.qrDensity})</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Comparative View - Soft rounded-3xl cards */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: QR Code Display */}
        <div className="lg:col-span-5 rounded-3xl border border-zinc-800/80 bg-zinc-950 p-7 flex flex-col items-center justify-center text-center shadow-xl">
          <div className="relative rounded-2xl border border-zinc-800 bg-black p-5 shadow-inner">
            {qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt={`Mã QR cho ${selectedAlg.name}`}
                className="w-64 h-64 sm:w-72 sm:h-72 object-contain rounded-xl"
              />
            ) : (
              <div className="w-64 h-64 flex items-center justify-center text-zinc-600 text-xs">
                Đang tạo mã QR...
              </div>
            )}
          </div>

          <div className="mt-5 text-xs">
            <span className="text-zinc-400">Mật độ hiển thị: </span>
            <span className="text-white font-bold">{selectedAlg.qrDensity}</span>
          </div>
          <div className="text-xs text-zinc-400 mt-1">
            Tổng độ dài Token: <span className="text-white font-bold">~{selectedAlg.totalJwtChars} ký tự</span> | Chữ ký: <span className="text-white font-bold">{selectedAlg.signatureSizeBytes} Bytes</span>
          </div>
        </div>

        {/* Right: Technical Explanation & Token Inspector */}
        <div className="lg:col-span-7 space-y-4">
          <div className="rounded-3xl border border-zinc-800/80 bg-zinc-950 p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-white">Đánh giá Khả năng Quét thực tế trên Thiết bị Di động</h3>
              <span className={`text-[11px] px-3 py-1 rounded-full border font-semibold ${
                selectedAlg.id === 'mldsa44' ? 'border-white bg-white text-black shadow-xs' : 'border-zinc-700 bg-zinc-900 text-zinc-300'
              }`}>
                {selectedAlg.category}
              </span>
            </div>

            <div className="space-y-2.5 text-xs text-zinc-300 leading-relaxed">
              {selectedAlg.id === 'mldsa44' ? (
                <>
                  <p>
                    <strong className="text-white">Thách thức lớn của ML-DSA-44:</strong> Với tổng chiều dài lên tới <strong>~3,807 ký tự</strong>, bộ mã hóa QR bắt buộc phải nâng cấp lên <strong>Version 14 trở lên (73 × 73 ô ma trận module)</strong>.
                  </p>
                  <p className="text-zinc-400">
                    Mỗi điểm chấm đen trên màn hình điện thoại hoặc vé in sẽ có kích thước vật lý rất nhỏ (chỉ ~0.4mm nếu in kích thước 3x3 cm). Điều này khiến các dòng camera điện thoại phổ thông hoặc góc quét nghiêng, rung lắc gặp khó khăn trong việc nhận diện mã.
                  </p>
                </>
              ) : selectedAlg.id === 'rs256' ? (
                <>
                  <p>
                    <strong className="text-white">Đặc tính quét của RS256:</strong> Token ~716 ký tự, tương ứng QR Code Version 5. Các điểm module tương đối thoáng, camera di động quét được trong khoảng 150ms–250ms với độ tin cậy cao.
                  </p>
                  <p className="text-zinc-400">
                    Tuy nhiên nhược điểm chính của RS256 là thời gian ký tại server rất lâu (849.74 µs) chứ không nằm ở mật độ QR.
                  </p>
                </>
              ) : (
                <>
                  <p>
                    <strong className="text-white">Tiêu chuẩn vàng cho QR Code:</strong> Với chỉ ~694 ký tự và chữ ký siêu gọn 64 bytes, {selectedAlg.name} tạo ra mã QR cực kỳ thưa và thoáng (Version 4/5).
                  </p>
                  <p className="text-zinc-400">
                    Camera điện thoại quét được gần như tức thì (&lt; 50ms) ngay cả ở cự ly xa hoặc trong điều kiện ánh sáng yếu, góc nghiêng 45 độ.
                  </p>
                </>
              )}
            </div>

            {/* Token raw viewer - Soft rounded-2xl */}
            <div className="pt-3 border-t border-zinc-900/80">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] text-zinc-400 font-semibold uppercase">Chuỗi Token JWT Base64URL thực tế:</span>
                <button
                  onClick={handleCopy}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs text-zinc-300 hover:text-white bg-zinc-900 border border-zinc-800 transition-colors cursor-pointer"
                >
                  {copiedToken ? <Check className="h-3 w-3 text-white" /> : <Copy className="h-3 w-3" />}
                  <span>{copiedToken ? 'Đã sao chép' : 'Sao chép token'}</span>
                </button>
              </div>
              <div className="rounded-2xl bg-black p-4 border border-zinc-800 text-[11px] text-zinc-400 max-h-36 overflow-y-auto break-all select-all shadow-inner leading-relaxed">
                {token}
              </div>
            </div>
          </div>

          {/* Comparative matrix summary - Soft rounded-3xl container */}
          <div className="rounded-3xl border border-zinc-800/80 bg-zinc-950 p-4.5 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center text-xs shadow-lg">
            <div className="border-r border-zinc-900 last:border-none p-1.5">
              <span className="text-zinc-500 block text-[11px]">RS256</span>
              <span className="text-zinc-200 font-bold text-sm">~716 chars</span>
              <span className="text-[11px] text-zinc-400 block mt-0.5">Thoáng</span>
            </div>
            <div className="border-r border-zinc-900 last:border-none p-1.5">
              <span className="text-zinc-500 block text-[11px]">ES256</span>
              <span className="text-zinc-200 font-bold text-sm">~694 chars</span>
              <span className="text-[11px] text-zinc-400 block mt-0.5">Cực thoáng</span>
            </div>
            <div className="border-r border-zinc-900 last:border-none p-1.5">
              <span className="text-zinc-500 block text-[11px]">EdDSA</span>
              <span className="text-white font-bold text-sm">~694 chars</span>
              <span className="text-[11px] text-zinc-300 block mt-0.5">Rất thoáng</span>
            </div>
            <div className="p-1.5">
              <span className="text-zinc-500 block text-[11px]">ML-DSA-44</span>
              <span className="text-white font-bold text-sm">~3,807 chars</span>
              <span className="text-[11px] text-white font-semibold block mt-0.5">Rất dày</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
