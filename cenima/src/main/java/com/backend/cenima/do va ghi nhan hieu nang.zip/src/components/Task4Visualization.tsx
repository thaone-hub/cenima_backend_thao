import React, { useState } from 'react';
import { ALGORITHMS, METRIC_DEFINITIONS } from '../data/benchmarkData';
import { MetricKey } from '../types/benchmark';
import { Clock, Info } from 'lucide-react';

interface Task4VisualizationProps {
  initialMetric?: MetricKey;
}

export const Task4Visualization: React.FC<Task4VisualizationProps> = ({ 
  initialMetric = 'verification' 
}) => {
  const [selectedMetricKey, setSelectedMetricKey] = useState<MetricKey>(initialMetric);

  const currentMetricDef = METRIC_DEFINITIONS.find((m) => m.key === selectedMetricKey) || METRIC_DEFINITIONS[0];

  // Compute maximum value for scaling the bars cleanly
  const rawValues = ALGORITHMS.map((alg) => currentMetricDef.getValue(alg));
  const maxValue = Math.max(...rawValues);

  return (
    <div className="rounded-3xl border border-zinc-800/80 bg-[#09090b] p-7 text-white shadow-2xl">
      {/* Header & Metric Navigation Pills */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 border-b border-zinc-800/80 pb-6">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-zinc-800 text-zinc-300">
              <Clock className="h-4 w-4" />
            </span>
            <h2 className="text-xl font-bold tracking-tight text-white sm:text-2xl">
              Biểu đồ So sánh Trực quan (Task 4 Visualization)
            </h2>
          </div>
          <p className="mt-1 text-xs text-zinc-400">
            So sánh chỉ số thực tế giữa các thuật toán
          </p>
        </div>

        {/* Metric Selection Pills - Soft rounded-full container & pills */}
        <div className="flex flex-wrap items-center gap-1.5 rounded-full border border-zinc-800/90 bg-black p-1.5">
          {METRIC_DEFINITIONS.map((def) => {
            const isActive = def.key === selectedMetricKey;
            return (
              <button
                key={def.key}
                onClick={() => setSelectedMetricKey(def.key)}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-full transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-white text-black shadow-md'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                }`}
              >
                {def.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Metric Context Info banner - Soft rounded-2xl */}
      <div className="mt-5 flex items-center justify-between rounded-2xl border border-zinc-800/60 bg-black/60 px-4 py-2.5 text-xs text-zinc-300">
        <div className="flex items-center gap-2.5">
          <Info className="h-4 w-4 text-zinc-300 shrink-0" />
          <span>{currentMetricDef.description}</span>
        </div>
        <span className="text-zinc-300 font-semibold shrink-0 hidden sm:inline">
          {currentMetricDef.higherIsBetter ? '▲ Càng cao càng tốt' : '▼ Càng thấp càng tốt'}
        </span>
      </div>

      {/* Horizontal Bar Chart List - ALL BARS ARE PURE WHITE AS REQUESTED */}
      <div className="mt-7 space-y-6">
        {ALGORITHMS.map((alg) => {
          const val = currentMetricDef.getValue(alg);
          // Scale bar percentage between min 3% and max 96%
          const pct = Math.max(3, Math.min(96, (val / maxValue) * 95));

          return (
            <div key={alg.id} className="space-y-2">
              {/* Algorithm Name, RFC standard and Right Metric Value */}
              <div className="flex items-baseline justify-between">
                <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                  <span className="text-base font-bold text-white tracking-tight">
                    {alg.name}
                  </span>
                  <span className="text-xs text-zinc-400">
                    {alg.standard}
                  </span>
                  {alg.category === 'Hậu lượng tử' && (
                    <span className="rounded-full border border-white bg-white px-2 py-0.5 text-[10px] font-bold text-black uppercase shadow-xs">
                      PQC FIPS 204
                    </span>
                  )}
                </div>

                {/* Right numeric value */}
                <div className="text-right">
                  <span className="text-base font-bold text-white tabular-nums">
                    {currentMetricDef.format(val)}
                  </span>
                </div>
              </div>

              {/* Progress Track and Bar - Smooth rounded-full, solid WHITE fill */}
              <div className="relative h-4.5 w-full overflow-hidden rounded-full bg-zinc-950 border border-zinc-800/80 shadow-inner">
                <div
                  className="h-full rounded-full bg-white transition-all duration-500 ease-out shadow-[0_0_8px_rgba(255,255,255,0.25)]"
                  style={{ width: `${pct}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Comparative Ratios & Key Insight Footer - Soft rounded-2xl cards */}
      <div className="mt-9 pt-6 border-t border-zinc-800/80 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
        <div className="rounded-2xl border border-zinc-800/80 bg-black/60 p-4 shadow-sm">
          <span className="text-zinc-500 block mb-1 font-semibold">So sánh Ký (Signing)</span>
          <p className="text-zinc-200 leading-relaxed">
            EdDSA nhanh hơn <span className="text-white font-bold">24.1 lần</span> RS256 và <span className="text-white font-bold">4.1 lần</span> ML-DSA-44.
          </p>
        </div>
        <div className="rounded-2xl border border-zinc-800/80 bg-black/60 p-4 shadow-sm">
          <span className="text-zinc-500 block mb-1 font-semibold">So sánh Xác thực (Verify)</span>
          <p className="text-zinc-200 leading-relaxed">
            RS256 xác thực nhanh nhất (<span className="text-white font-bold">45.06 µs</span>), tiếp đến EdDSA (<span className="text-white font-bold">88.01 µs</span>).
          </p>
        </div>
        <div className="rounded-2xl border border-zinc-800/80 bg-black/60 p-4 shadow-sm">
          <span className="text-zinc-500 block mb-1 font-semibold">Kích thước Chữ ký (PQC Tradeoff)</span>
          <p className="text-zinc-200 leading-relaxed">
            ML-DSA-44 (<span className="text-white font-bold">2,420B</span>) lớn gấp <span className="text-white font-bold">37.8 lần</span> so với EdDSA/ES256 (64B).
          </p>
        </div>
      </div>
    </div>
  );
};
