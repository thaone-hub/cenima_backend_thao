import React from 'react';
import { TEST_ENVIRONMENT } from '../data/benchmarkData';
import { Cpu, HardDrive, Server, FileCode, Sliders } from 'lucide-react';

export const TestEnvironment: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="border-b border-zinc-800/80 pb-4">
        <h2 className="text-xl font-bold tracking-tight text-white sm:text-2xl">
          Môi trường Thử nghiệm &amp; Phương pháp Đo lường
        </h2>
        <p className="mt-1 text-sm text-zinc-400">
          Đặc tả phần cứng, cấu hình hệ điều hành Linux, tham số máy ảo JVM và quy trình thực nghiệm JMH tiêu chuẩn
        </p>
      </div>

      {/* Grid of Spec Cards - Soft rounded-3xl containers */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Hardware Specs */}
        <div className="rounded-3xl border border-zinc-800/80 bg-zinc-950 p-6 space-y-4 shadow-lg">
          <div className="flex items-center gap-2.5 text-white">
            <Cpu className="h-5 w-5 text-zinc-300" />
            <h3 className="font-bold text-sm tracking-wide uppercase">1. Cấu hình Phần cứng (Hardware Testbed)</h3>
          </div>
          <div className="space-y-3.5 text-xs">
            <div className="flex flex-col border-b border-zinc-900/80 pb-2.5">
              <span className="text-zinc-500 font-semibold">Bộ vi xử lý (CPU):</span>
              <span className="text-zinc-200 mt-1">{TEST_ENVIRONMENT.hardware.cpu}</span>
            </div>
            <div className="flex flex-col border-b border-zinc-900/80 pb-2.5">
              <span className="text-zinc-500 font-semibold">Bộ nhớ RAM:</span>
              <span className="text-zinc-200 mt-1">{TEST_ENVIRONMENT.hardware.ram}</span>
            </div>
            <div className="flex flex-col border-b border-zinc-900/80 pb-2.5">
              <span className="text-zinc-500 font-semibold">Kiến trúc tập lệnh:</span>
              <span className="text-zinc-200 mt-1">{TEST_ENVIRONMENT.hardware.architecture}</span>
            </div>
            <div className="flex flex-col">
              <span className="text-zinc-500 font-semibold">Lưu trữ:</span>
              <span className="text-zinc-200 mt-1">{TEST_ENVIRONMENT.hardware.storage}</span>
            </div>
          </div>
        </div>

        {/* Operating System */}
        <div className="rounded-3xl border border-zinc-800/80 bg-zinc-950 p-6 space-y-4 shadow-lg">
          <div className="flex items-center gap-2.5 text-white">
            <Server className="h-5 w-5 text-zinc-300" />
            <h3 className="font-bold text-sm tracking-wide uppercase">2. Hệ điều hành &amp; Tối ưu Hạt nhân</h3>
          </div>
          <div className="space-y-3.5 text-xs">
            <div className="flex flex-col border-b border-zinc-900/80 pb-2.5">
              <span className="text-zinc-500 font-semibold">Hệ điều hành:</span>
              <span className="text-zinc-200 mt-1">{TEST_ENVIRONMENT.operatingSystem.os}</span>
            </div>
            <div className="flex flex-col border-b border-zinc-900/80 pb-2.5">
              <span className="text-zinc-500 font-semibold">CPU Scaling Governor:</span>
              <span className="text-white font-semibold mt-1 bg-zinc-900 px-3 py-1 rounded-full border border-zinc-800 inline-block w-fit">
                {TEST_ENVIRONMENT.operatingSystem.cpuGovernor}
              </span>
            </div>
            <div className="flex flex-col border-b border-zinc-900/80 pb-2.5">
              <span className="text-zinc-500 font-semibold">Cách ly luồng CPU:</span>
              <span className="text-zinc-200 mt-1">{TEST_ENVIRONMENT.operatingSystem.isolation}</span>
            </div>
            <div className="flex flex-col">
              <span className="text-zinc-500 font-semibold">Bộ sinh số ngẫu nhiên:</span>
              <span className="text-zinc-200 mt-1">/dev/urandom phần cứng qua TRNG (True Random Generator)</span>
            </div>
          </div>
        </div>

        {/* Java Virtual Machine */}
        <div className="rounded-3xl border border-zinc-800/80 bg-zinc-950 p-6 space-y-4 shadow-lg">
          <div className="flex items-center gap-2.5 text-white">
            <HardDrive className="h-5 w-5 text-zinc-300" />
            <h3 className="font-bold text-sm tracking-wide uppercase">3. Môi trường Thực thi JVM (Java 21 LTS)</h3>
          </div>
          <div className="space-y-3.5 text-xs">
            <div>
              <span className="text-zinc-500 font-semibold">Bản phân phối:</span>
              <p className="text-zinc-200 mt-1">{TEST_ENVIRONMENT.runtimeJvm.vendor} ({TEST_ENVIRONMENT.runtimeJvm.version})</p>
            </div>
            <div>
              <span className="text-zinc-500 font-semibold">Cờ khởi chạy JVM (JVM Flags):</span>
              <div className="mt-2 rounded-2xl bg-black p-3.5 border border-zinc-800 text-zinc-300 space-y-1.5 shadow-inner">
                {TEST_ENVIRONMENT.runtimeJvm.jvmFlags.map((flag, idx) => (
                  <div key={idx} className="text-xs text-zinc-300">
                    <span className="text-zinc-500">$</span> {flag}
                  </div>
                ))}
              </div>
            </div>
            <p className="text-[11px] text-zinc-400 leading-relaxed">
              * G1GC được cố định dung lượng Heap 4GB ngay khi khởi động (-XX:+AlwaysPreTouch) nhằm ngăn ngừa tình trạng cấp phát trang ảo (page fault) làm sai lệch kết quả microbenchmark.
            </p>
          </div>
        </div>

        {/* Methodology & Measurement Protocol */}
        <div className="rounded-3xl border border-zinc-800/80 bg-zinc-950 p-6 space-y-4 shadow-lg">
          <div className="flex items-center gap-2.5 text-white">
            <Sliders className="h-5 w-5 text-zinc-300" />
            <h3 className="font-bold text-sm tracking-wide uppercase">4. Phương pháp Đo lường JMH Tiêu chuẩn</h3>
          </div>
          <div className="space-y-3 text-xs">
            <div className="flex justify-between border-b border-zinc-900/80 pb-2">
              <span className="text-zinc-500 font-semibold">Giai đoạn Làm nóng (Warmup):</span>
              <span className="text-zinc-200 text-right">{TEST_ENVIRONMENT.methodology.warmup}</span>
            </div>
            <div className="flex justify-between border-b border-zinc-900/80 pb-2">
              <span className="text-zinc-500 font-semibold">Giai đoạn Đo (Measurement):</span>
              <span className="text-zinc-200 text-right">{TEST_ENVIRONMENT.methodology.measurement}</span>
            </div>
            <div className="flex justify-between border-b border-zinc-900/80 pb-2">
              <span className="text-zinc-500 font-semibold">Tách tiến trình (Forks):</span>
              <span className="text-zinc-200 text-right">{TEST_ENVIRONMENT.methodology.forks}</span>
            </div>
            <div className="flex justify-between border-b border-zinc-900/80 pb-2">
              <span className="text-zinc-500 font-semibold">Đo lường Cấp phát RAM:</span>
              <span className="text-zinc-200 text-right">{TEST_ENVIRONMENT.methodology.profiler}</span>
            </div>
            <div className="mt-2 text-[11px] text-zinc-400 leading-relaxed">
              * Dữ liệu JWT Payload kiểm thử gồm 340 bytes đầy đủ các trường chuẩn RFC 7519 (sub, iss, aud, exp, nbf, iat, jti, roles: ["ADMIN", "CRYPTO_AUDITOR"], email, scope) đại diện chính xác cho các token xác thực OAuth2 / OpenID Connect thực tế trong hệ thống microservices.
            </div>
          </div>
        </div>
      </div>

      {/* Libraries & Dependencies Table - Soft rounded-3xl container */}
      <div className="rounded-3xl border border-zinc-800/80 bg-zinc-950 p-6 space-y-4 shadow-xl">
        <div className="flex items-center gap-2.5 text-white">
          <FileCode className="h-5 w-5 text-zinc-300" />
          <h3 className="font-bold text-sm tracking-wide uppercase">5. Thư viện &amp; Provider Mật mã được sử dụng</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-zinc-800 text-zinc-400 uppercase font-semibold">
              <tr>
                <th className="py-3 px-4">Tên Thư viện</th>
                <th className="py-3 px-4">Phiên bản</th>
                <th className="py-3 px-4">Mục đích / Chức năng Cryptographic</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-900 text-zinc-300">
              {TEST_ENVIRONMENT.libraries.map((lib, i) => (
                <tr key={i} className="hover:bg-zinc-900/40">
                  <td className="py-3.5 px-4 font-bold text-white">{lib.name}</td>
                  <td className="py-3.5 px-4 text-zinc-400">{lib.version}</td>
                  <td className="py-3.5 px-4 text-zinc-300 leading-relaxed">{lib.purpose}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
