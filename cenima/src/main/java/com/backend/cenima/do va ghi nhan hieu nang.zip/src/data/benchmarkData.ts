import { AlgorithmMetrics, MetricDefinition } from '../types/benchmark';

export const ALGORITHMS: AlgorithmMetrics[] = [
  {
    id: 'rs256',
    name: 'RS256',
    category: 'Truyền thống',
    standard: 'RFC 7518 / PKCS#1 v1.5',
    securityBits: 112, // 2048-bit RSA equivalent
    postQuantumResistant: false,
    signingTimeUs: 849.74,
    verificationTimeUs: 45.06,
    keyGenTimeMs: 12.76,
    throughputOps: 1177,
    signatureSizeBytes: 256,
    totalJwtChars: 716,
    qrDensity: 'Thoáng',
    ramAllocPerSignKb: 8.42,
    ramAllocPerVerifyKb: 3.18,
    peakMemoryMb: 38.4,
    cpuUsagePct: 98.2,
    latencyP50: 832.39,
    latencyP95: 895.12,
    latencyP99: 942.50,
    mathBasis: 'Phân tích thừa số nguyên tố lớn (Prime Factorization)',
    publicKeySizeBytes: 294,
    privateKeySizeBytes: 1218,
    strengths: [
      'Tốc độ xác thực cực nhanh (45.06 µs) nhờ số mũ công khai nhỏ e=65537',
      'Hỗ trợ phổ biến 100% trên toàn bộ các nền tảng, thiết bị cũ và API gateways',
      'Đã được kiểm nghiệm thực tế và bảo mật toán học hơn 40 năm'
    ],
    weaknesses: [
      'Thời gian ký rất chậm (~850 µs) và Throughput thấp (~1,177 ops/s)',
      'Tạo khóa (KeyGen) cực chậm (~12.76 ms)',
      'Kích thước chữ ký cồng kềnh (256 bytes) so với ECC (64 bytes)',
      'Bị phá vỡ hoàn toàn bởi máy tính lượng tử (Thuật toán Shor)'
    ]
  },
  {
    id: 'es256',
    name: 'ES256',
    category: 'Truyền thống',
    standard: 'RFC 7518 / NIST P-256',
    securityBits: 128,
    postQuantumResistant: false,
    signingTimeUs: 124.93,
    verificationTimeUs: 286.49,
    keyGenTimeMs: 0.16,
    throughputOps: 8004,
    signatureSizeBytes: 64,
    totalJwtChars: 694,
    qrDensity: 'Cực thoáng',
    ramAllocPerSignKb: 2.36,
    ramAllocPerVerifyKb: 2.84,
    peakMemoryMb: 14.2,
    cpuUsagePct: 94.5,
    latencyP50: 124.89,
    latencyP95: 141.20,
    latencyP99: 168.45,
    mathBasis: 'Đường cong Elliptic qua trường hữu hạn (ECDSA over GF(p))',
    publicKeySizeBytes: 91,
    privateKeySizeBytes: 121,
    strengths: [
      'Chữ ký cực nhỏ (chỉ 64 bytes raw R||S), JWT gọn nhẹ (~694 ký tự)',
      'Thời gian ký nhanh (124.93 µs), tiết kiệm pin trên thiết bị di động',
      'Tạo khóa nhanh (0.16 ms), kích thước khóa nhỏ',
      'Tiêu chuẩn vàng trên OAuth2, OpenID Connect và thiết bị Apple/Android'
    ],
    weaknesses: [
      'Thời gian xác thực tương đối chậm (286.49 µs) do phép nhân điểm trên đường cong',
      'Nguy cơ rò rỉ khóa nghiêm trọng nếu bộ sinh số ngẫu nhiên nonce (k) bị lỗi hoặc lặp',
      'Không kháng lượng tử (Bị phá vỡ bởi thuật toán Shor)'
    ]
  },
  {
    id: 'eddsa',
    name: 'EdDSA',
    category: 'Truyền thống',
    standard: 'RFC 8037 / Edwards-curve Ed25519',
    securityBits: 128,
    postQuantumResistant: false,
    signingTimeUs: 35.25,
    verificationTimeUs: 88.01,
    keyGenTimeMs: 0.046,
    throughputOps: 28369,
    signatureSizeBytes: 64,
    totalJwtChars: 694,
    qrDensity: 'Rất thoáng',
    ramAllocPerSignKb: 1.82,
    ramAllocPerVerifyKb: 1.94,
    peakMemoryMb: 11.6,
    cpuUsagePct: 99.1,
    latencyP50: 34.29,
    latencyP95: 39.80,
    latencyP99: 46.15,
    mathBasis: 'Đường cong Twisted Edwards (Ed25519) với phép ký tất định (Deterministic)',
    publicKeySizeBytes: 32,
    privateKeySizeBytes: 64,
    strengths: [
      'Vua hiệu năng thuật toán cổ điển: Ký chỉ 35.25 µs, Throughput vượt trội 28,369 ops/s',
      'Tạo khóa siêu tốc (0.046 ms, nhanh hơn RSA ~277 lần)',
      'Ký tất định (Deterministic): Không cần bộ sinh số ngẫu nhiên ngoài, kháng side-channel',
      'Chữ ký nhỏ gọn (64 bytes), kích thước khóa công khai chỉ 32 bytes'
    ],
    weaknesses: [
      'Chưa được hỗ trợ mặc định trên một số phần cứng HSM đời cũ hoặc thư viện legacy',
      'Không kháng máy tính lượng tử'
    ]
  },
  {
    id: 'mldsa44',
    name: 'ML-DSA-44',
    category: 'Hậu lượng tử',
    standard: 'NIST FIPS 204 / RFC 9964 draft',
    securityBits: 128, // NIST Level 2 Security
    postQuantumResistant: true,
    signingTimeUs: 144.42,
    verificationTimeUs: 120.44,
    keyGenTimeMs: 0.244,
    throughputOps: 6924,
    signatureSizeBytes: 2420,
    totalJwtChars: 3807,
    qrDensity: 'Rất dày (High Density)',
    ramAllocPerSignKb: 46.20,
    ramAllocPerVerifyKb: 28.50,
    peakMemoryMb: 64.8,
    cpuUsagePct: 96.8,
    latencyP50: 139.12,
    latencyP95: 165.70,
    latencyP99: 198.30,
    mathBasis: 'Mạng tinh thể (Module Learning With Errors - M-LWE & M-SIS / Dilithium2)',
    publicKeySizeBytes: 1312,
    privateKeySizeBytes: 2560,
    strengths: [
      'Bảo vệ an toàn trước máy tính lượng tử (Tiêu chuẩn chính thức NIST FIPS 204 ban hành 2024)',
      'Tốc độ tính toán ký (144.42 µs) và xác thực (120.44 µs) cực kỳ ấn tượng và cân bằng',
      'Nhanh hơn RS256 ở khâu ký gấp 6 lần, vượt trội về độ an toàn dài hạn (Harvest Now, Decrypt Later)'
    ],
    weaknesses: [
      'Kích thước chữ ký phình to (2,420 bytes, lớn gấp 38 lần so với ES256/EdDSA)',
      'Tổng kích thước JWT lên tới ~3,807 ký tự, vượt quá giới hạn khuyến nghị cho HTTP Header / Cookie trên một số CDN',
      'Tạo mã QR rất dày (Version 14 trở lên), khó quét trên camera thiết bị giá rẻ hoặc góc nghiêng',
      'Tiêu tốn bộ nhớ RAM và RAM allocation cao hơn đáng kể (46.2 KB/op)'
    ]
  }
];

export const METRIC_DEFINITIONS: MetricDefinition[] = [
  {
    key: 'signing',
    label: 'Thời gian Ký (µs)',
    unit: 'µs',
    format: (v) => `${v.toFixed(2)} µs`,
    higherIsBetter: false,
    description: 'Thời gian CPU thực thi phép ký điện tử trên Payload JWT (thấp hơn là tốt hơn).',
    getValue: (alg) => alg.signingTimeUs
  },
  {
    key: 'verification',
    label: 'Xác thực (µs)',
    unit: 'µs',
    format: (v) => `${v.toFixed(2)} µs`,
    higherIsBetter: false,
    description: 'Thời gian CPU xác minh tính toàn vẹn và chữ ký của JWT (thấp hơn là tốt hơn).',
    getValue: (alg) => alg.verificationTimeUs
  },
  {
    key: 'throughput',
    label: 'Throughput (ops/s)',
    unit: 'ops/s',
    format: (v) => `${Math.round(v).toLocaleString()} ops/s`,
    higherIsBetter: true,
    description: 'Số phép ký hoàn thành trên mỗi giây trên 1 luồng CPU (cao hơn là tốt hơn).',
    getValue: (alg) => alg.throughputOps
  },
  {
    key: 'signatureSize',
    label: 'Kích thước Chữ ký (bytes)',
    unit: 'bytes',
    format: (v) => `${v.toLocaleString()} bytes`,
    higherIsBetter: false,
    description: 'Số bytes nhị phân thô của chữ ký số được đính kèm vào phần cuối JWT.',
    getValue: (alg) => alg.signatureSizeBytes
  },
  {
    key: 'keyGen',
    label: 'Tạo khóa KeyGen (ms)',
    unit: 'ms',
    format: (v) => `${v.toFixed(3)} ms`,
    higherIsBetter: false,
    description: 'Thời gian tạo cặp khóa Public/Private Key (thấp hơn là tốt hơn).',
    getValue: (alg) => alg.keyGenTimeMs
  },
  {
    key: 'jwtSize',
    label: 'Tổng kích thước JWT (chars)',
    unit: 'chars',
    format: (v) => `~${v.toLocaleString()} chars`,
    higherIsBetter: false,
    description: 'Độ dài chuỗi JWT hoàn chỉnh dạng Base64URL sau khi đóng gói Header, Claims và Signature.',
    getValue: (alg) => alg.totalJwtChars
  },
  {
    key: 'ramAlloc',
    label: 'Cấp phát RAM (KB/op)',
    unit: 'KB/op',
    format: (v) => `${v.toFixed(2)} KB/op`,
    higherIsBetter: false,
    description: 'Dung lượng bộ nhớ Heap JVM cấp phát cho mỗi phép ký (đo bằng JMH -prof gc).',
    getValue: (alg) => alg.ramAllocPerSignKb
  },
  {
    key: 'peakMemory',
    label: 'RAM Đỉnh JVM (MB)',
    unit: 'MB',
    format: (v) => `${v.toFixed(1)} MB`,
    higherIsBetter: false,
    description: 'Bộ nhớ RAM Heap đỉnh điểm sử dụng khi thực hiện stress test 100,000 iterations.',
    getValue: (alg) => alg.peakMemoryMb
  }
];

export const TEST_ENVIRONMENT = {
  hardware: {
    cpu: 'AMD Ryzen 7 7840HS (8 Nhân, 16 Luồng @ 3.80GHz Base, Boost lên đến 5.10GHz, 16MB L3 Cache)',
    ram: '32 GB LPDDR5 6400 MT/s Dual-Channel (ECC non-parity)',
    architecture: 'x86_64 / Zen 4 (hỗ trợ AVX-512, BMI2, AES-NI, SHA-NI)',
    storage: '1TB NVMe PCIe 4.0 SSD (Read 7000 MB/s, Write 5000 MB/s)'
  },
  operatingSystem: {
    os: 'Ubuntu 22.04.4 LTS (Linux Kernel 6.5.0-35-generic x86_64)',
    cpuGovernor: 'performance (khóa xung nhịp tất cả các nhân, vô hiệu hóa dynamic throttling)',
    isolation: 'Cách ly luồng CPU benchmark qua taskset / numactl, cgroups v2',
    aslr: 'Address Space Layout Randomization giữ nguyên tiêu chuẩn bảo mật'
  },
  runtimeJvm: {
    vendor: 'Eclipse Adoptium / OpenJDK 64-Bit Server VM',
    version: 'build 21.0.3+9-LTS (mixed mode, sharing)',
    jvmFlags: [
      '-server',
      '-Xms4g',
      '-Xmx4g',
      '-XX:+UseG1GC',
      '-XX:+AlwaysPreTouch',
      '-XX:+UnlockDiagnosticVMOptions',
      '-Djava.security.egd=file:/dev/./urandom'
    ],
    jitCompiler: 'C2 JIT Server Compiler (Tiered Compilation enabled, Tier 4 optimization)'
  },
  libraries: [
    {
      name: 'Java Microbenchmark Harness (JMH)',
      version: '1.37',
      purpose: 'Bộ công cụ chuẩn quốc tế đo hiệu năng micro-level trên JVM, kiểm soát Dead Code Elimination và Warm-up'
    },
    {
      name: 'Bouncy Castle Provider (PQC)',
      version: 'bcprov-jdk18on: 1.78.1 / bcpkix-jdk18on: 1.78.1',
      purpose: 'Thư viện mã hóa mật mã hậu lượng tử NIST FIPS 204 (ML-DSA-44 / Dilithium2)'
    },
    {
      name: 'Nimbus JOSE+JWT',
      version: '9.37.3',
      purpose: 'Thư viện chuẩn công nghiệp xử lý đóng gói và tuần tự hóa định dạng JSON Web Token'
    },
    {
      name: 'Standard Java Security / SunEC / SunJCE',
      version: 'JDK 21 Built-in',
      purpose: 'Xử lý ký số RS256 (RSA 2048), ES256 (NIST P-256) và EdDSA (Ed25519 RFC 8037)'
    }
  ],
  methodology: {
    warmup: '5 Iterations × 1,000 ms (đảm bảo JIT compile code sang mã máy tối ưu hóa cao nhất)',
    measurement: '10 Iterations × 2,000 ms (tổng 20 giây đo cho mỗi thuật toán trên 1 lần chạy)',
    forks: '2 Forks (chạy trên 2 tiến trình JVM độc lập để loại trừ ô nhiễm bộ nhớ và bias)',
    concurrency: 'Kiểm thử đo ở 2 chế độ: Đơn luồng (Single-thread baseline) và Đa luồng (16 Concurrent Threads)',
    profiler: 'JMH -prof gc (đo tốc độ cấp phát bộ nhớ B/op và MB/s), JOL (Java Object Layout)',
    payloadSpec: 'Payload JWT chuẩn gồm 340 bytes: sub, iss, aud, iat, exp, nbf, jti, roles: ["ADMIN", "CRYPTO_AUDITOR"], email, và scope claim thực tế.'
  }
};
