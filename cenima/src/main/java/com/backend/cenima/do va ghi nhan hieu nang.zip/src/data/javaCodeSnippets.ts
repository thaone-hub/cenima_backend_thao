export interface JavaSnippet {
  id: string;
  filename: string;
  title: string;
  description: string;
  language: string;
  code: string;
}

export const JAVA_SNIPPETS: JavaSnippet[] = [
  {
    id: 'pom',
    filename: 'pom.xml',
    title: 'Cấu hình Maven (pom.xml)',
    description: 'Khai báo các thư viện JMH, Bouncy Castle PQC FIPS 204 và maven-shade-plugin đóng gói jar thực thi.',
    language: 'xml',
    code: `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.crypto.benchmark</groupId>
    <artifactId>jwt-crypto-benchmark</artifactId>
    <version>1.0.0</version>
    <packaging>jar</packaging>

    <properties>
        <maven.compiler.source>21</maven.compiler.source>
        <maven.compiler.target>21</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <jmh.version>1.37</jmh.version>
        <bouncycastle.version>1.78.1</bouncycastle.version>
        <uberjar.name>benchmarks</uberjar.name>
    </properties>

    <dependencies>
        <!-- JMH Core Framework -->
        <dependency>
            <groupId>org.openjdk.jmh</groupId>
            <artifactId>jmh-core</artifactId>
            <version>\${jmh.version}</version>
        </dependency>
        <dependency>
            <groupId>org.openjdk.jmh</groupId>
            <artifactId>jmh-generator-annprocess</artifactId>
            <version>\${jmh.version}</version>
            <scope>provided</scope>
        </dependency>

        <!-- Bouncy Castle PQC (Post-Quantum Cryptography - FIPS 204 ML-DSA) -->
        <dependency>
            <groupId>org.bouncycastle</groupId>
            <artifactId>bcprov-jdk18on</artifactId>
            <version>\${bouncycastle.version}</version>
        </dependency>
        <dependency>
            <groupId>org.bouncycastle</groupId>
            <artifactId>bcpkix-jdk18on</artifactId>
            <version>\${bouncycastle.version}</version>
        </dependency>

        <!-- Nimbus JOSE+JWT for Token Standardization -->
        <dependency>
            <groupId>com.nimbusds</groupId>
            <artifactId>nimbus-jose-jwt</artifactId>
            <version>9.37.3</version>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.13.0</version>
                <configuration>
                    <compilerVersion>21</compilerVersion>
                    <source>21</source>
                    <target>21</target>
                </configuration>
            </plugin>
            <!-- Shade Plugin to produce self-contained JMH runnable jar -->
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-shade-plugin</artifactId>
                <version>3.5.2</version>
                <executions>
                    <execution>
                        <phase>package</phase>
                        <goals>
                            <goal>shade</goal>
                        </goals>
                        <configuration>
                            <finalName>\${uberjar.name}</finalName>
                            <transformers>
                                <transformer implementation="org.apache.maven.plugins.shade.resource.ManifestResourceTransformer">
                                    <mainClass>org.openjdk.jmh.Main</mainClass>
                                </transformer>
                            </transformers>
                        </configuration>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
</project>`
  },
  {
    id: 'benchmark',
    filename: 'JwtCryptoBenchmark.java',
    title: 'Lớp Benchmark JMH chính (JwtCryptoBenchmark.java)',
    description: 'Thực thi đo đạc Signing Time, Verification Time, Throughput, Garbage Collection và RAM allocation.',
    language: 'java',
    code: `package com.crypto.benchmark;

import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.Blackhole;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;

import java.nio.charset.StandardCharsets;
import java.security.Security;
import java.util.concurrent.TimeUnit;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

@BenchmarkMode({Mode.AverageTime, Mode.Throughput})
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@Warmup(iterations = 5, time = 1000, timeUnit = TimeUnit.MILLISECONDS)
@Measurement(iterations = 10, time = 2000, timeUnit = TimeUnit.MILLISECONDS)
@Fork(value = 2, jvmArgsAppend = {"-server", "-Xms4g", "-Xmx4g", "-XX:+UseG1GC", "-XX:+AlwaysPreTouch"})
@State(Scope.Benchmark)
public class JwtCryptoBenchmark {

    static {
        // Đăng ký Bouncy Castle Provider cho thuật toán Hậu lượng tử ML-DSA-44
        Security.addProvider(new BouncyCastleProvider());
    }

    // Standard JWT claims payload (340 bytes)
    private static final String SAMPLE_PAYLOAD = 
        "{\\"sub\\":\\"1234567890\\",\\"name\\":\\"Nguyen Van A\\",\\"iss\\":\\"auth.domain.vn\\"," +
        "\\"aud\\":\\"api.domain.vn\\",\\"iat\\":1729000000,\\"exp\\":1729086400,\\"nbf\\":1729000000," +
        "\\"roles\\":[\\"ADMIN\\",\\"CRYPTO_AUDITOR\\"],\\"scope\\":\\"read write audit sign\\"," +
        "\\"fingerprint\\":\\"sha256-8a7c2b3e4f5a6b7c8d9e0f1a2b3c4d5e\\"}";

    private byte[] payloadBytes;

    // Services cho từng thuật toán
    private RS256Signer rs256Signer;
    private ES256Signer es256Signer;
    private Ed25519Signer ed25519Signer;
    private MLDSA44Signer mlDsa44Signer;

    // Pre-computed signatures dùng để benchmark Verification Time độc lập
    private byte[] rs256Signature;
    private byte[] es256Signature;
    private byte[] ed25519Signature;
    private byte[] mlDsa44Signature;

    @Setup(Level.Trial)
    public void setup() throws Exception {
        payloadBytes = SAMPLE_PAYLOAD.getBytes(StandardCharsets.UTF_8);

        // Khởi tạo các Signer & sinh cặp khóa
        rs256Signer = new RS256Signer();
        es256Signer = new ES256Signer();
        ed25519Signer = new Ed25519Signer();
        mlDsa44Signer = new MLDSA44Signer();

        // Ký trước 1 lần để có chữ ký hợp lệ phục vụ kiểm tra Verification
        rs256Signature = rs256Signer.sign(payloadBytes);
        es256Signature = es256Signer.sign(payloadBytes);
        ed25519Signature = ed25519Signer.sign(payloadBytes);
        mlDsa44Signature = mlDsa44Signer.sign(payloadBytes);
    }

    // ================= SIGNING TIME BENCHMARKS ================= //

    @Benchmark
    public byte[] testRS256Signing() throws Exception {
        return rs256Signer.sign(payloadBytes);
    }

    @Benchmark
    public byte[] testES256Signing() throws Exception {
        return es256Signer.sign(payloadBytes);
    }

    @Benchmark
    public byte[] testEdDSASigning() throws Exception {
        return ed25519Signer.sign(payloadBytes);
    }

    @Benchmark
    public byte[] testMLDSA44Signing() throws Exception {
        return mlDsa44Signer.sign(payloadBytes);
    }

    // ================= VERIFICATION TIME BENCHMARKS ================= //

    @Benchmark
    public boolean testRS256Verification() throws Exception {
        return rs256Signer.verify(payloadBytes, rs256Signature);
    }

    @Benchmark
    public boolean testES256Verification() throws Exception {
        return es256Signer.verify(payloadBytes, es256Signature);
    }

    @Benchmark
    public boolean testEdDSAVerification() throws Exception {
        return ed25519Signer.verify(payloadBytes, ed25519Signature);
    }

    @Benchmark
    public boolean testMLDSA44Verification() throws Exception {
        return mlDsa44Signer.verify(payloadBytes, mlDsa44Signature);
    }

    // Main runner method
    public static void main(String[] args) throws Exception {
        Options opt = new OptionsBuilder()
                .include(JwtCryptoBenchmark.class.getSimpleName())
                .addProfiler("org.openjdk.jmh.profile.GCProfiler")
                .forks(2)
                .build();

        new Runner(opt).run();
    }
}`
  },
  {
    id: 'mldsa',
    filename: 'MLDSA44Signer.java',
    title: 'Thuật toán Hậu lượng tử ML-DSA-44 (NIST FIPS 204)',
    description: 'Triển khai thuật toán chữ ký số dựa trên mạng tinh thể Dilithium2 bằng Bouncy Castle PQC.',
    language: 'java',
    code: `package com.crypto.benchmark;

import org.bouncycastle.pqc.crypto.mldsa.MLDSAKeyGenerationParameters;
import org.bouncycastle.pqc.crypto.mldsa.MLDSAKeyPairGenerator;
import org.bouncycastle.pqc.crypto.mldsa.MLDSAParameters;
import org.bouncycastle.pqc.crypto.mldsa.MLDSAPrivateKeyParameters;
import org.bouncycastle.pqc.crypto.mldsa.MLDSAPublicKeyParameters;
import org.bouncycastle.pqc.crypto.mldsa.MLDSASigner;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;

import java.security.SecureRandom;

/**
 * Triển khai chuẩn NIST FIPS 204: Module-Lattice-Based Digital Signature Standard (ML-DSA-44).
 * Cung cấp cấp độ bảo mật NIST Category 2 (128-bit quantum security).
 * Kích thước chữ ký: 2,420 bytes.
 * Khóa công khai: 1,312 bytes.
 */
public class MLDSA44Signer {

    private final MLDSAPrivateKeyParameters privateKey;
    private final MLDSAPublicKeyParameters publicKey;
    private final SecureRandom secureRandom;

    public MLDSA44Signer() {
        this.secureRandom = new SecureRandom();
        
        // Cấu hình tham số ML-DSA-44 (Dilithium2)
        MLDSAKeyPairGenerator keyGen = new MLDSAKeyPairGenerator();
        keyGen.init(new MLDSAKeyGenerationParameters(secureRandom, MLDSAParameters.ml_dsa_44));
        
        AsymmetricCipherKeyPair keyPair = keyGen.generateKeyPair();
        this.privateKey = (MLDSAPrivateKeyParameters) keyPair.getPrivate();
        this.publicKey = (MLDSAPublicKeyParameters) keyPair.getPublic();
    }

    /**
     * Ký điện tử trên mảng byte payload.
     * @param payload Dữ liệu Header + Payload JWT
     * @return Mảng byte chữ ký thô (chính xác 2,420 bytes)
     */
    public byte[] sign(byte[] payload) {
        MLDSASigner signer = new MLDSASigner();
        signer.init(true, privateKey);
        return signer.generateSignature(payload);
    }

    /**
     * Xác thực chữ ký số bằng Khóa công khai.
     * @param payload Dữ liệu nguyên bản
     * @param signature Chữ ký số 2,420 bytes
     * @return true nếu chữ ký hợp lệ
     */
    public boolean verify(byte[] payload, byte[] signature) {
        MLDSASigner verifier = new MLDSASigner();
        verifier.init(false, publicKey);
        return verifier.verifySignature(payload, signature);
    }

    public int getSignatureLength() {
        return 2420; // 2420 bytes chuẩn theo FIPS 204
    }

    public byte[] getPublicKeyEncoded() {
        return publicKey.getEncoded(); // 1312 bytes
    }
}`
  },
  {
    id: 'rs256',
    filename: 'RS256Signer.java',
    title: 'Thuật toán RS256 (RFC 7518 / PKCS#1 v1.5 RSA-2048)',
    description: 'Sử dụng kiến trúc chuẩn Java Security Signature API với SHA256withRSA.',
    language: 'java',
    code: `package com.crypto.benchmark;

import java.security.*;

/**
 * Chuẩn RFC 7518 RS256: RSA Signature Scheme with PKCS #1 v1.5 using SHA-256.
 * Độ dài khóa: 2048-bit RSA.
 * Kích thước chữ ký: 256 bytes (2048 bits).
 */
public class RS256Signer {

    private final PrivateKey privateKey;
    private final PublicKey publicKey;

    public RS256Signer() throws Exception {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048, new SecureRandom());
        KeyPair keyPair = keyGen.generateKeyPair();
        this.privateKey = keyPair.getPrivate();
        this.publicKey = keyPair.getPublic();
    }

    public byte[] sign(byte[] payload) throws Exception {
        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(privateKey);
        signature.update(payload);
        return signature.sign();
    }

    public boolean verify(byte[] payload, byte[] sigBytes) throws Exception {
        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initVerify(publicKey);
        signature.update(payload);
        return signature.verify(sigBytes);
    }

    public int getSignatureLength() {
        return 256; // 256 bytes (2048-bit modulus)
    }
}`
  },
  {
    id: 'es256',
    filename: 'ES256Signer.java',
    title: 'Thuật toán ES256 (RFC 7518 / NIST P-256 ECDSA)',
    description: 'Chữ ký trên đường cong elliptic secp256r1 với chuẩn raw R||S 64-byte theo chuẩn JWS.',
    language: 'java',
    code: `package com.crypto.benchmark;

import java.security.*;
import java.security.spec.ECGenParameterSpec;

/**
 * Chuẩn RFC 7518 ES256: ECDSA using P-256 and SHA-256.
 * Chuẩn JWS yêu cầu chữ ký là nối tiếp raw byte R và S (mỗi số 32 bytes -> 64 bytes).
 */
public class ES256Signer {

    private final PrivateKey privateKey;
    private final PublicKey publicKey;

    public ES256Signer() throws Exception {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("EC");
        keyGen.initialize(new ECGenParameterSpec("secp256r1"), new SecureRandom());
        KeyPair keyPair = keyGen.generateKeyPair();
        this.privateKey = keyPair.getPrivate();
        this.publicKey = keyPair.getPublic();
    }

    public byte[] sign(byte[] payload) throws Exception {
        // Sử dụng thuật toán SHA256withECDSAinP1363Format để xuất ra đúng 64 bytes raw R||S
        Signature signature = Signature.getInstance("SHA256withECDSAinP1363Format");
        signature.initSign(privateKey);
        signature.update(payload);
        return signature.sign();
    }

    public boolean verify(byte[] payload, byte[] sigBytes) throws Exception {
        Signature signature = Signature.getInstance("SHA256withECDSAinP1363Format");
        signature.initVerify(publicKey);
        signature.update(payload);
        return signature.verify(sigBytes);
    }

    public int getSignatureLength() {
        return 64; // 32 bytes R + 32 bytes S
    }
}`
  },
  {
    id: 'eddsa',
    filename: 'Ed25519Signer.java',
    title: 'Thuật toán EdDSA (RFC 8037 / Edwards-curve Ed25519)',
    description: 'Chuẩn ký Ed25519 tích hợp sẵn từ Java 15+ không phụ thuộc side-channel và cực nhanh.',
    language: 'java',
    code: `package com.crypto.benchmark;

import java.security.*;

/**
 * Chuẩn RFC 8037: CFRG Elliptic Curve Diffie-Hellman (ECDH) and Signatures in JOSE.
 * Sử dụng đường cong Twisted Edwards Ed25519.
 * Kích thước chữ ký: 64 bytes.
 * Kích thước khóa công khai: 32 bytes.
 */
public class Ed25519Signer {

    private final PrivateKey privateKey;
    private final PublicKey publicKey;

    public Ed25519Signer() throws Exception {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("Ed25519");
        KeyPair keyPair = keyGen.generateKeyPair();
        this.privateKey = keyPair.getPrivate();
        this.publicKey = keyPair.getPublic();
    }

    public byte[] sign(byte[] payload) throws Exception {
        Signature signature = Signature.getInstance("Ed25519");
        signature.initSign(privateKey);
        signature.update(payload);
        return signature.sign();
    }

    public boolean verify(byte[] payload, byte[] sigBytes) throws Exception {
        Signature signature = Signature.getInstance("Ed25519");
        signature.initVerify(publicKey);
        signature.update(payload);
        return signature.verify(sigBytes);
    }

    public int getSignatureLength() {
        return 64; // 64 bytes raw signature
    }
}`
  },
  {
    id: 'packager',
    filename: 'JwtPackager.java',
    title: 'Đóng gói JWT Base64URL (JwtPackager.java)',
    description: 'Tuần tự hóa cấu trúc Header.Payload.Signature theo RFC 7519 và đo đạc kích thước chuỗi token.',
    language: 'java',
    code: `package com.crypto.benchmark;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Tiện ích tuần tự hóa cấu trúc JWT chuẩn:
 * Token = Base64URL(Header) + "." + Base64URL(Payload) + "." + Base64URL(Signature)
 */
public class JwtPackager {

    private static final Base64.Encoder B64_URL_ENCODER = Base64.getUrlEncoder().withoutPadding();

    public static String buildJwt(String algName, String jsonPayload, byte[] rawSignature) {
        String headerJson = String.format("{\\"alg\\":\\"%s\\",\\"typ\\":\\"JWT\\"}", algName);
        
        String encodedHeader = B64_URL_ENCODER.encodeToString(headerJson.getBytes(StandardCharsets.UTF_8));
        String encodedPayload = B64_URL_ENCODER.encodeToString(jsonPayload.getBytes(StandardCharsets.UTF_8));
        String encodedSignature = B64_URL_ENCODER.encodeToString(rawSignature);

        return encodedHeader + "." + encodedPayload + "." + encodedSignature;
    }

    public static void printSummary(String alg, String token, byte[] sig) {
        System.out.printf("[%s] Raw Signature: %d bytes | Total JWT: %d chars%n",
                alg, sig.length, token.length());
    }
}`
  }
];
