export type AlgorithmId = 'rs256' | 'es256' | 'eddsa' | 'mldsa44';

export interface AlgorithmMetrics {
  id: AlgorithmId;
  name: string;
  category: 'Truyền thống' | 'Hậu lượng tử';
  standard: string;
  securityBits: number;
  postQuantumResistant: boolean;
  
  // Measured Metrics
  signingTimeUs: number;        // microseconds
  verificationTimeUs: number;   // microseconds
  keyGenTimeMs: number;         // milliseconds
  throughputOps: number;        // operations per second
  signatureSizeBytes: number;   // bytes
  totalJwtChars: number;        // characters
  qrDensity: 'Thoáng' | 'Cực thoáng' | 'Rất thoáng' | 'Rất dày (High Density)';
  
  // Hardware & Memory Metrics
  ramAllocPerSignKb: number;    // KB/op
  ramAllocPerVerifyKb: number;  // KB/op
  peakMemoryMb: number;         // MB
  cpuUsagePct: number;          // % on 1 core at peak throughput
  
  // Percentiles for latency (µs)
  latencyP50: number;
  latencyP95: number;
  latencyP99: number;

  // Description & Cryptographic notes
  mathBasis: string;
  publicKeySizeBytes: number;
  privateKeySizeBytes: number;
  strengths: string[];
  weaknesses: string[];
}

export type MetricKey = 
  | 'signing' 
  | 'verification' 
  | 'throughput' 
  | 'signatureSize' 
  | 'keyGen' 
  | 'jwtSize' 
  | 'ramAlloc' 
  | 'peakMemory';

export interface MetricDefinition {
  key: MetricKey;
  label: string;
  unit: string;
  format: (val: number) => string;
  higherIsBetter: boolean;
  description: string;
  getValue: (alg: AlgorithmMetrics) => number;
}
